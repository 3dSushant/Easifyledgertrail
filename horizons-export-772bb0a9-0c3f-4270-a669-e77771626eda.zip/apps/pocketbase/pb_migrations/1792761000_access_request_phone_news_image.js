/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // ---- access_requests: mobile number + review status ----
    const requests = app.findCollectionByNameOrId('access_requests');

    const addField = (field) => {
      if (!requests.fields.getByName(field.name)) {
        requests.fields.add(field);
      }
    };

    addField(new TextField({ name: 'phone', max: 30 }));
    addField(
      new SelectField({
        name: 'status',
        maxSelect: 1,
        values: ['pending', 'approved', 'rejected'],
      }),
    );
    addField(new TextField({ name: 'rejection_reason', max: 1000 }));
    addField(new TextField({ name: 'notes', max: 2000 }));

    app.save(requests);

    // Backfill existing requests as pending so the admin review queue is consistent.
    try {
      const existing = app.findRecordsByFilter('access_requests', 'status = null || status = ""');
      for (const r of existing) {
        if (!r.get('status')) {
          r.set('status', 'pending');
          app.save(r);
        }
      }
    } catch (_) {
      /* no existing rows or filter unsupported — ignore */
    }
    // Also backfill any rows where status is unset (covers `!= ''` misses).
    try {
      const all = app.findAllRecords(requests);
      for (const r of all) {
        if (!r.get('status')) {
          r.set('status', 'pending');
          app.save(r);
        }
      }
    } catch (_) {}

    // ---- news_articles: file-based featured image (alongside legacy URL field) ----
    const news = app.findCollectionByNameOrId('news_articles');
    if (!news.fields.getByName('image_file')) {
      news.fields.add(
        new FileField({
          name: 'image_file',
          maxSelect: 1,
          maxSize: 5242880, // 5 MB
          mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
        }),
      );
      app.save(news);
    }
  },
  (app) => {
    const requests = app.findCollectionByNameOrId('access_requests');
    ['phone', 'status', 'rejection_reason', 'notes'].forEach((name) => {
      try { requests.fields.removeByName(name); } catch (_) {}
    });
    app.save(requests);

    const news = app.findCollectionByNameOrId('news_articles');
    try { news.fields.removeByName('image_file'); } catch (_) {}
    app.save(news);
  },
);
