/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users');
    const employees = app.findCollectionByNameOrId('employees');

    const collection = new Collection({
      name: 'attendance_records',
      type: 'base',
      listRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
      viewRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
      createRule: "@request.auth.id != '' && @request.body.owner = @request.auth.id",
      updateRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin') && @request.body.owner:changed = false",
      deleteRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
      fields: [
        { name: 'owner', type: 'relation', required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
        { name: 'employee', type: 'relation', required: true, maxSelect: 1, collectionId: employees.id, cascadeDelete: true },
        { name: 'date', type: 'text', required: true, max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
        { name: 'in_time', type: 'text', max: 5, pattern: '^\\d{2}:\\d{2}$' },
        { name: 'out_time', type: 'text', max: 5, pattern: '^\\d{2}:\\d{2}$' },
        { name: 'status', type: 'select', required: true, maxSelect: 1, values: ['Present', 'Absent', 'Paid Leave', 'Sick Leave', 'Half Day', 'Weekly Off'] },
        { name: 'late', type: 'bool' },
        { name: 'late_minutes', type: 'number', min: 0 },
        { name: 'early_leaving', type: 'bool' },
        { name: 'working_hours', type: 'number', min: 0 },
        { name: 'overtime_hours', type: 'number', min: 0 },
        { name: 'remarks', type: 'text', max: 500 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_attendance_owner ON attendance_records (owner)',
        'CREATE INDEX idx_attendance_employee ON attendance_records (employee)',
      ],
    });
    app.save(collection);
  },
  (app) => {
    try { app.delete(app.findCollectionByNameOrId('attendance_records')); } catch (_) {}
  },
);
