/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const adminRule = "@request.auth.role = 'admin'";

    // ---- Services (public service pages, admin-editable) ----
    let services;
    try {
      services = app.findCollectionByNameOrId('services');
    } catch (_) {
      services = new Collection({
        type: 'base',
        name: 'services',
        listRule: '',
        viewRule: '',
        createRule: adminRule,
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          {
            name: 'category',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: [
              'tax-compliance',
              'accounting-services',
              'payroll-services',
              'government-registration',
            ],
          },
          { name: 'slug', type: 'text', required: true, max: 120 },
          { name: 'title', type: 'text', required: true, max: 200 },
          { name: 'tagline', type: 'text', max: 300 },
          { name: 'content', type: 'text', max: 8000 },
          { name: 'image', type: 'text', max: 500 },
          { name: 'price', type: 'text', max: 120 },
          { name: 'features', type: 'json', maxSize: 8000 },
          { name: 'sort', type: 'number' },
          { name: 'published', type: 'bool' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_services_category ON services (category)'],
      });
      app.save(services);
    }

    // ---- Site settings (about, contact info) ----
    let settings;
    try {
      settings = app.findCollectionByNameOrId('site_settings');
    } catch (_) {
      settings = new Collection({
        type: 'base',
        name: 'site_settings',
        listRule: '',
        viewRule: '',
        createRule: adminRule,
        updateRule: adminRule,
        deleteRule: null,
        fields: [
          { name: 'about_title', type: 'text', max: 200 },
          { name: 'about_content', type: 'text', max: 8000 },
          { name: 'whatsapp', type: 'text', max: 30 },
          { name: 'email', type: 'text', max: 120 },
          { name: 'phone', type: 'text', max: 30 },
          { name: 'location', type: 'text', max: 200 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
      });
      app.save(settings);
    }

    // ---- Contact messages (public form, admin reads) ----
    let messages;
    try {
      messages = app.findCollectionByNameOrId('contact_messages');
    } catch (_) {
      messages = new Collection({
        type: 'base',
        name: 'contact_messages',
        listRule: adminRule,
        viewRule: adminRule,
        createRule: '',
        updateRule: null,
        deleteRule: adminRule,
        fields: [
          { name: 'name', type: 'text', required: true, max: 200 },
          { name: 'email', type: 'email', required: true },
          { name: 'phone', type: 'text', max: 30 },
          { name: 'subject', type: 'text', max: 200 },
          { name: 'message', type: 'text', required: true, max: 4000 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
      });
      app.save(messages);
    }

    // ---- Seed default site settings ----
    let settingsRows = [];
    try {
      settingsRows = app.findRecordsByFilter('site_settings', '1=1');
    } catch (_) {
      settingsRows = [];
    }
    if (settingsRows.length === 0) {
      const rec = new Record(settings);
      rec.set('about_title', 'About Easify Ledger');
      rec.set(
        'about_content',
        'Easify Ledger is a Pune-based business services practice helping small and growing businesses across India manage their accounting, payroll and statutory compliance with clarity and care.\n\nWe bring together bookkeeping, salary processing and GST, TDS, PF, PT and ESIC filings into one organised workflow so founders can spend less time on paperwork and more time running their business. From your first transaction to your annual returns, we keep your records accurate, timely and private.\n\nBased in Pune, we work with clients all over India.',
      );
      rec.set('whatsapp', '7620233934');
      rec.set('email', 'info@EasifyLedger.com');
      rec.set('phone', '7620233934');
      rec.set('location', 'Pune, India — serving clients across India');
      app.save(rec);
    }

    // ---- Seed default services ----
    const taxImg =
      'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/e7e8e836-c2be-49c7-aafc-8c764a4e7e78.png';
    const accImg =
      'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/7f8b44af-6bee-4da3-9768-bfb662b83e7e.png';
    const payImg =
      'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/d0d93d84-5ab0-4929-86a1-f06a6c8f1deb.png';
    const govImg =
      'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/3ef7e211-1c4e-4d52-a60e-ccf6222bf054.png';

    const seed = [
      {
        category: 'tax-compliance',
        slug: 'gst',
        title: 'GST Registration & Return Filing',
        tagline: 'Goods & Services Tax — registered, filed and on time.',
        content:
          'We handle your GST registration and monthly, quarterly and annual return filing end to end. From reconciling your purchase and sales data to claiming input tax credit and filing GSTR-1, GSTR-3B and annual returns, we keep your GST compliance accurate and timely so you avoid penalties and interest.',
        image: taxImg,
        price: 'From ₹1,499 / month',
        features: [
          'GST registration & amendments',
          'GSTR-1 & GSTR-3B filing',
          'Input tax credit reconciliation',
          'Annual return & GSTR-9',
          'Notices & reply support',
        ],
        sort: 1,
      },
      {
        category: 'tax-compliance',
        slug: 'tds',
        title: 'TDS Payment & Return Filing',
        tagline: 'Tax Deducted at Source — deducted, paid and filed.',
        content:
          'We manage your TDS deductions, challan payments and quarterly TDS returns. We identify the correct section and rate for every payment, deposit the tax on time and file Form 24Q, 26Q, 27Q and 27EQ, then issue Form 16 and Form 16A to your deductees.',
        image: taxImg,
        price: 'From ₹1,999 / month',
        features: [
          'TDS deduction & challan payment',
          'Quarterly return filing (24Q/26Q)',
          'Form 16 & Form 16A issuance',
          'TRACES correction & defaults',
          'Lower deduction certificate support',
        ],
        sort: 2,
      },
      {
        category: 'tax-compliance',
        slug: 'pf',
        title: 'Provident Fund (PF) Compliance',
        tagline: 'Employee PF — contributed and filed every month.',
        content:
          'We set up and maintain your Provident Fund compliance: monthly PF challan generation and payment, ECR filing, member onboarding and exits, and KYC updates through the EPFO portal, keeping your employee provident fund contributions accurate and on time.',
        image: taxImg,
        price: 'From ₹999 / month',
        features: [
          'PF registration & UAN setup',
          'Monthly ECR filing & challan',
          'Member onboarding & exit',
          'KYC & nominee updates',
          'PF withdrawal & transfer support',
        ],
        sort: 3,
      },
      {
        category: 'tax-compliance',
        slug: 'esic',
        title: 'ESIC Compliance',
        tagline: 'Employees’ State Insurance — covered and current.',
        content:
          'We handle your ESIC registration, monthly contribution challan and return filing, employee onboarding and IP details through the ESIC portal, ensuring your employee state insurance obligations are met on time and accurately.',
        image: taxImg,
        price: 'From ₹999 / month',
        features: [
          'ESIC registration',
          'Monthly contribution & challan',
          'Employee onboarding & exits',
          'Return filing on ESIC portal',
          'Compliance & inspection support',
        ],
        sort: 4,
      },
      {
        category: 'tax-compliance',
        slug: 'pt',
        title: 'Professional Tax (PT) Compliance',
        tagline: 'Professional Tax — registered and filed for your state.',
        content:
          'We manage your Professional Tax registration, monthly and annual returns, and the correct deduction of professional tax from employee salaries as per your state’s slab rates, keeping your PT compliance current wherever in India you operate.',
        image: taxImg,
        price: 'From ₹799 / month',
        features: [
          'PT registration (PEC & PTRC)',
          'Monthly & annual returns',
          'Employee slab-based deduction',
          'Challan payment',
          'Multi-state compliance support',
        ],
        sort: 5,
      },
      {
        category: 'accounting-services',
        slug: 'monthly-package',
        title: 'Monthly Accounting Package',
        tagline: 'Books maintained every single month.',
        content:
          'Our monthly accounting package keeps your books current all year. We record every transaction, reconcile your bank and cash, prepare your profit & loss and balance sheet each month, and keep you ready for GST and tax filing at any time.',
        image: accImg,
        price: 'From ₹2,999 / month',
        features: [
          'Daily transaction recording',
          'Bank & cash reconciliation',
          'Monthly P&L and balance sheet',
          'GST-ready books',
          'Dedicated accountant',
        ],
        sort: 1,
      },
      {
        category: 'accounting-services',
        slug: 'quarterly-package',
        title: 'Quarterly Accounting Package',
        tagline: 'Books reviewed every quarter.',
        content:
          'For businesses that need periodic oversight, our quarterly package records and reconciles your books every three months, prepares quarterly financial statements and keeps your GST and advance-tax obligations aligned with your numbers.',
        image: accImg,
        price: 'From ₹7,999 / quarter',
        features: [
          'Quarterly transaction recording',
          'Reconciliation & adjustments',
          'Quarterly financial statements',
          'Advance tax readiness',
          'GST reconciliation support',
        ],
        sort: 2,
      },
      {
        category: 'accounting-services',
        slug: 'yearly-package',
        title: 'Yearly Accounting Package',
        tagline: 'Annual books and financial statements.',
        content:
          'Our yearly package is ideal for businesses that need annual closure: a full year of books compiled, reconciled and finalised into audited-ready financial statements, with annual GST and income-tax return support.',
        image: accImg,
        price: 'From ₹24,999 / year',
        features: [
          'Annual bookkeeping & closure',
          'Final P&L and balance sheet',
          'Audit-ready statements',
          'Annual GST return support',
          'Income tax return filing',
        ],
        sort: 3,
      },
      {
        category: 'accounting-services',
        slug: 'weekly-package',
        title: 'Weekly Accounting Package',
        tagline: 'Books updated every week.',
        content:
          'For fast-moving businesses that need tight control, our weekly package records and reconciles your transactions every week, giving you an up-to-date view of cash flow, receivables and payables at all times.',
        image: accImg,
        price: 'From ₹1,499 / week',
        features: [
          'Weekly transaction recording',
          'Cash & bank reconciliation',
          'Receivables & payables tracking',
          'Weekly cash-flow snapshot',
          'Priority support',
        ],
        sort: 4,
      },
      {
        category: 'payroll-services',
        slug: 'salary-working-payment',
        title: 'Salary Working & Payment',
        tagline: 'Accurate salary calculation and on-time payment.',
        content:
          'We calculate your monthly salary working for every employee — basic, allowances, deductions, PF, ESIC, PT and TDS — and process the net salary payment, so payroll is accurate, compliant and paid on time, every time.',
        image: payImg,
        price: 'From ₹99 / employee / month',
        features: [
          'Monthly salary working',
          'PF, ESIC, PT & TDS calculation',
          'Net salary payment processing',
          'Statutory compliance',
          'Reimbursement handling',
        ],
        sort: 1,
      },
      {
        category: 'payroll-services',
        slug: 'salary-slip',
        title: 'Timely Salary Slip to Employees',
        tagline: 'Professional payslips, delivered on time.',
        content:
          'We generate and deliver professional, compliant salary slips to every employee each month — by email or WhatsApp — with a clear breakdown of earnings, deductions and net pay, building trust and transparency in your payroll.',
        image: payImg,
        price: 'From ₹49 / employee / month',
        features: [
          'Monthly payslip generation',
          'Email & WhatsApp delivery',
          'Earnings & deductions breakdown',
          'Year-to-date totals',
          'Branded payslip format',
        ],
        sort: 2,
      },
      {
        category: 'payroll-services',
        slug: 'employee-records',
        title: 'Employee Records Management',
        tagline: 'Every employee, organised in one place.',
        content:
          'We maintain a complete, secure employee records system — personal details, documents, joining and exit data, salary history and statutory enrolments — so your HR information is always organised, up to date and audit-ready.',
        image: payImg,
        price: 'From ₹1,999 / month',
        features: [
          'Employee master records',
          'Document & KYC storage',
          'Joining & exit management',
          'Salary history',
          'Statutory enrolment tracking',
        ],
        sort: 3,
      },
      {
        category: 'payroll-services',
        slug: 'talent-acquisition',
        title: 'Talent Acquisition at Low Cost',
        tagline: 'Hire the right people, affordably.',
        content:
          'We help you find and onboard the right talent at a low cost — from sourcing and screening candidates to coordinating interviews and completing joining formalities — so growing businesses can hire without the overhead of a full recruitment agency.',
        image: payImg,
        price: 'From ₹4,999 / hire',
        features: [
          'Candidate sourcing & screening',
          'Interview coordination',
          'Reference checks',
          'Onboarding & documentation',
          'Affordable hiring fees',
        ],
        sort: 4,
      },
      {
        category: 'government-registration',
        slug: 'shop-act',
        title: 'Shop Act License Registration',
        tagline: 'Shop & Establishment registration, done right.',
        content:
          'We handle your Shop & Establishment (Gumasta) license registration end to end — documentation, application, fees and follow-up with the local authority — so your business is legally registered to operate from day one.',
        image: govImg,
        price: 'From ₹2,499',
        features: [
          'Document preparation',
          'Application & filing',
          'Fee payment handling',
          'License follow-up',
          'Renewal support',
        ],
        sort: 1,
      },
      {
        category: 'government-registration',
        slug: 'food-license',
        title: 'Food License (FSSAI) Registration',
        tagline: 'FSSAI registration for food businesses.',
        content:
          'We get your FSSAI food license — basic, state or central — registered and renewed, handling documentation, application and follow-up so your food business meets all food safety compliance requirements.',
        image: govImg,
        price: 'From ₹1,999',
        features: [
          'Basic / State / Central FSSAI',
          'Document preparation',
          'Application & filing',
          'License follow-up',
          'Annual renewal support',
        ],
        sort: 2,
      },
      {
        category: 'government-registration',
        slug: 'firm-registration',
        title: 'Firm Registration',
        tagline: 'Register your partnership or business firm.',
        content:
          'We register your partnership firm or business entity — drafting the agreement, preparing documents and filing with the Registrar of Firms — so your business structure is legally recognised and protected.',
        image: govImg,
        price: 'From ₹4,999',
        features: [
          'Partnership deed drafting',
          'Document preparation',
          'Registrar of Firms filing',
          'PAN & TAN application',
          'Compliance setup',
        ],
        sort: 3,
      },
    ];

    seed.forEach((item) => {
      let existing = [];
      try {
        existing = app.findRecordsByFilter(
          'services',
          `slug = '${item.slug}'`,
        );
      } catch (_) {
        existing = [];
      }
      if (existing.length > 0) return;

      const rec = new Record(services);
      rec.set('category', item.category);
      rec.set('slug', item.slug);
      rec.set('title', item.title);
      rec.set('tagline', item.tagline);
      rec.set('content', item.content);
      rec.set('image', item.image);
      rec.set('price', item.price);
      rec.set('features', item.features);
      rec.set('sort', item.sort);
      rec.set('published', true);
      app.save(rec);
    });
  },
  (app) => {
    const drop = (name) => {
      try {
        const collection = app.findCollectionByNameOrId(name);
        app.delete(collection);
      } catch (e) {
        if (!e.message.includes('no rows')) throw e;
      }
    };
    drop('services');
    drop('site_settings');
    drop('contact_messages');
  },
);
