/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users');

    if (!users.fields.getByName('role')) {
      users.fields.add(
        new SelectField({
          name: 'role',
          required: true,
          maxSelect: 1,
          values: ['member', 'admin'],
        }),
      );
    }

    if (!users.fields.getByName('active')) {
      users.fields.add(new BoolField({ name: 'active' }));
    }

    // Lock the privileged fields: a member may not change their own role or
    // active status; only an admin may. `active` is also locked so a disabled
    // member cannot re-enable themselves.
    users.listRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.viewRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.createRule = "@request.auth.role = 'admin'";
    users.updateRule =
      "(id = @request.auth.id && @request.body.role:changed = false && @request.body.active:changed = false) || @request.auth.role = 'admin'";
    users.deleteRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.authRule = 'active = true'; // disabled members cannot sign in
    app.save(users);

    // Backfill every existing user as an active member so the new auth rule
    // does not lock out accounts that already exist.
    const existing = app.findRecordsByFilter('users', '1=1');
    existing.forEach((rec) => {
      if (!rec.get('role')) rec.set('role', 'member');
      rec.set('active', true);
      app.save(rec);
    });

    // Seed the admin account if it does not yet exist.
    let admins = [];
    try {
      admins = app.findRecordsByFilter('users', "email = 'admin@easifyledger.com'");
    } catch (_) {
      admins = [];
    }
    if (admins.length === 0) {
      const admin = new Record(users);
      admin.set('email', 'admin@easifyledger.com');
      admin.set('password', 'Easify@Admin2026');
      admin.set('passwordConfirm', 'Easify@Admin2026');
      admin.set('name', 'Easify Ledger Admin');
      admin.set('role', 'admin');
      admin.set('active', true);
      admin.set('verified', true);
      app.save(admin);
    }
  },
  (app) => {
    const users = app.findCollectionByNameOrId('users');
    users.listRule = 'id = @request.auth.id';
    users.viewRule = 'id = @request.auth.id';
    users.createRule = null;
    users.updateRule = 'id = @request.auth.id';
    users.deleteRule = 'id = @request.auth.id';
    users.authRule = '';
    app.save(users);
    try {
      users.fields.removeByName('role');
    } catch (_) {}
    try {
      users.fields.removeByName('active');
    } catch (_) {}
    app.save(users);
  },
);
