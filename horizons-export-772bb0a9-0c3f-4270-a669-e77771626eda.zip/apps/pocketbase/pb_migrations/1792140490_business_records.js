migrate((app) => {
  const users = app.findCollectionByNameOrId('users');
  const common = [
    { name: 'owner', type: 'relation', required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: false },
    { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
    { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true }
  ];
  const definitions = [
    ['transactions', [
      { name: 'description', type: 'text', required: true, max: 300 },
      { name: 'counterparty', type: 'text', max: 200 },
      { name: 'date', type: 'text', required: true, max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
      { name: 'type', type: 'select', required: true, maxSelect: 1, values: ['Income', 'Expense'] },
      { name: 'category', type: 'text', required: true, max: 100 },
      { name: 'amount', type: 'number', min: 0.01, required: true },
      { name: 'status', type: 'select', required: true, maxSelect: 1, values: ['Paid', 'Pending'] },
      { name: 'reference', type: 'text', max: 100 }
    ]],
    ['employees', [
      { name: 'name', type: 'text', required: true, max: 200 },
      { name: 'email', type: 'email' },
      { name: 'designation', type: 'text', max: 200 },
      { name: 'department', type: 'text', max: 100 },
      { name: 'basic', type: 'number', min: 0 },
      { name: 'allowances', type: 'number', min: 0 },
      { name: 'deductions', type: 'number', min: 0 },
      { name: 'status', type: 'select', required: true, maxSelect: 1, values: ['Active', 'Inactive'] }
    ]],
    ['compliance_items', [
      { name: 'title', type: 'text', required: true, max: 300 },
      { name: 'type', type: 'select', required: true, maxSelect: 1, values: ['GST', 'TDS', 'PF', 'PT', 'ESIC'] },
      { name: 'period', type: 'text', required: true, max: 100 },
      { name: 'due_date', type: 'text', required: true, max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
      { name: 'amount', type: 'number', min: 0 },
      { name: 'status', type: 'select', required: true, maxSelect: 1, values: ['Pending', 'In progress', 'Filed'] },
      { name: 'reference', type: 'text', max: 200 },
      { name: 'notes', type: 'text', max: 2000 }
    ]],
    ['payroll_runs', [
      { name: 'period', type: 'text', required: true, max: 7, pattern: '^\\d{4}-\\d{2}$' },
      { name: 'gross', type: 'number', min: 0 },
      { name: 'deductions', type: 'number', min: 0 },
      { name: 'net', type: 'number', min: 0 },
      { name: 'employee_count', type: 'number', min: 0 },
      { name: 'status', type: 'select', required: true, maxSelect: 1, values: ['Draft', 'Paid'] },
      { name: 'snapshot', type: 'json', maxSize: 2000000 }
    ]]
  ];
  definitions.forEach(([name, fields]) => {
    const collection = new Collection({ name, type: 'base',
      listRule: "@request.auth.id != '' && owner = @request.auth.id",
      viewRule: "@request.auth.id != '' && owner = @request.auth.id",
      createRule: "@request.auth.id != '' && @request.body.owner = @request.auth.id",
      updateRule: "@request.auth.id != '' && owner = @request.auth.id && @request.body.owner:changed = false",
      deleteRule: "@request.auth.id != '' && owner = @request.auth.id",
      fields: common.concat(fields),
      indexes: name === 'payroll_runs' ? ['CREATE UNIQUE INDEX idx_payroll_owner_period ON payroll_runs (owner, period)'] : []
    });
    app.save(collection);
  });
  app.save(new Collection({ name: 'access_requests', type: 'base', listRule: null, viewRule: null, createRule: '', updateRule: null, deleteRule: null, fields: [
    { name: 'name', type: 'text', required: true, max: 200 },
    { name: 'business', type: 'text', required: true, max: 200 },
    { name: 'email', type: 'email', required: true },
    { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
    { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true }
  ] }));
});
