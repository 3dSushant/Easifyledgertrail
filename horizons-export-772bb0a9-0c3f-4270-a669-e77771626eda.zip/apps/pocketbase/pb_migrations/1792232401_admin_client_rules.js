/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const readRule =
      "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')";
    const writeRule =
      "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin') && @request.body.owner:changed = false";

    ['transactions', 'employees', 'compliance_items', 'payroll_runs'].forEach((name) => {
      const collection = app.findCollectionByNameOrId(name);
      collection.listRule = readRule;
      collection.viewRule = readRule;
      collection.updateRule = writeRule;
      collection.deleteRule = readRule;
      app.save(collection);
    });

    // Access requests: admin can review and manage them.
    const requests = app.findCollectionByNameOrId('access_requests');
    requests.listRule = "@request.auth.role = 'admin'";
    requests.viewRule = "@request.auth.role = 'admin'";
    requests.updateRule = "@request.auth.role = 'admin'";
    requests.deleteRule = "@request.auth.role = 'admin'";
    app.save(requests);
  },
  (app) => {
    const readRule = "@request.auth.id != '' && owner = @request.auth.id";
    const writeRule =
      "@request.auth.id != '' && owner = @request.auth.id && @request.body.owner:changed = false";
    ['transactions', 'employees', 'compliance_items', 'payroll_runs'].forEach((name) => {
      const collection = app.findCollectionByNameOrId(name);
      collection.listRule = readRule;
      collection.viewRule = readRule;
      collection.updateRule = writeRule;
      collection.deleteRule = readRule;
      app.save(collection);
    });
    const requests = app.findCollectionByNameOrId('access_requests');
    requests.listRule = null;
    requests.viewRule = null;
    requests.updateRule = null;
    requests.deleteRule = null;
    app.save(requests);
  },
);
