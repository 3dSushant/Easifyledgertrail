/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users');

    // ---- Job descriptions posted by clients ----
    let jds;
    try {
      jds = app.findCollectionByNameOrId('hire_jds');
    } catch (_) {
      jds = new Collection({
        type: 'base',
        name: 'hire_jds',
        listRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
        viewRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
        createRule: "@request.auth.id != '' && @request.body.owner = @request.auth.id",
        updateRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin') && @request.body.owner:changed = false",
        deleteRule: "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')",
        fields: [
          { name: 'owner', type: 'relation', required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
          { name: 'job_title', type: 'text', required: true, max: 200 },
          { name: 'department', type: 'text', max: 200 },
          { name: 'positions', type: 'number', min: 1 },
          { name: 'skills', type: 'text', max: 2000 },
          { name: 'experience', type: 'text', max: 200 },
          { name: 'qualification', type: 'text', max: 500 },
          { name: 'salary', type: 'text', max: 200 },
          { name: 'location', type: 'text', max: 200 },
          {
            name: 'employment_type',
            type: 'select',
            maxSelect: 1,
            values: ['Full-time', 'Part-time', 'Contract', 'Internship'],
          },
          { name: 'description', type: 'text', max: 5000 },
          { name: 'requirements', type: 'text', max: 5000 },
          {
            name: 'status',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Open', 'Closed'],
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_hire_jds_owner ON hire_jds (owner)'],
      });
      app.save(jds);
    }

    // ---- Candidates assigned to a JD by admins ----
    let candidates;
    try {
      candidates = app.findCollectionByNameOrId('hire_candidates');
    } catch (_) {
      candidates = new Collection({
        type: 'base',
        name: 'hire_candidates',
        listRule: "@request.auth.id != '' && (jd.owner = @request.auth.id || @request.auth.role = 'admin')",
        viewRule: "@request.auth.id != '' && (jd.owner = @request.auth.id || @request.auth.role = 'admin')",
        createRule: "@request.auth.role = 'admin'",
        updateRule: "@request.auth.id != '' && (jd.owner = @request.auth.id || @request.auth.role = 'admin')",
        deleteRule: "@request.auth.role = 'admin'",
        fields: [
          { name: 'jd', type: 'relation', required: true, maxSelect: 1, collectionId: jds.id, cascadeDelete: true },
          { name: 'name', type: 'text', required: true, max: 200 },
          { name: 'email', type: 'email' },
          { name: 'phone', type: 'text', max: 30 },
          {
            name: 'resume',
            type: 'file',
            maxSelect: 1,
            maxSize: 5242880,
            mimeTypes: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            protected: true,
          },
          { name: 'experience', type: 'text', max: 200 },
          { name: 'skills', type: 'text', max: 2000 },
          {
            name: 'status',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Shortlisted', 'Rejected', 'Pending Interview', 'Selected', 'Hired'],
          },
          { name: 'interview_notes', type: 'text', max: 5000 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_hire_candidates_jd ON hire_candidates (jd)'],
      });
      app.save(candidates);
    }
  },
  (app) => {
    try { app.delete(app.findCollectionByNameOrId('hire_candidates')); } catch (_) {}
    try { app.delete(app.findCollectionByNameOrId('hire_jds')); } catch (_) {}
  },
);
