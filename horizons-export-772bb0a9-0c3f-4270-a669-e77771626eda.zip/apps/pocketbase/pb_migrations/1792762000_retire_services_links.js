/// <reference path="../pb_data/types.d.ts" />

// Retire the public Services section: rewrite any /services/* links stored in
// published Home page CMS content so they point to /packages instead. The
// services collection itself is kept (data is not deleted); only the public
// routes, admin screen and nav were removed. No-op when no home_settings
// records exist or when none reference /services.

function fixLinks(value) {
  if (Array.isArray(value)) {
    for (const item of value) fixLinks(item);
  } else if (value && typeof value === 'object') {
    for (const key of Object.keys(value)) {
      const v = value[key];
      if (key === 'link' && typeof v === 'string' && v.startsWith('/services')) {
        value[key] = '/packages';
      } else {
        fixLinks(v);
      }
    }
  }
}

migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId('home_settings');
    } catch (_) {
      return; // home_settings not present — nothing to do
    }

    const records = app.findAllRecords(collection);
    for (const r of records) {
      let changed = false;
      for (const field of ['content', 'draft']) {
        const raw = r.get(field);
        if (raw == null) continue;
        let parsed = raw;
        if (typeof raw === 'string') {
          try {
            parsed = JSON.parse(raw);
          } catch (_) {
            continue; // not JSON — leave untouched
          }
        }
        if (parsed == null || typeof parsed !== 'object') continue;
        const before = JSON.stringify(parsed);
        fixLinks(parsed);
        const after = JSON.stringify(parsed);
        if (after !== before) {
          r.set(field, parsed);
          changed = true;
        }
      }
      if (changed) app.save(r);
    }
  },
  (app) => {
    // Reverting would restore /services links to pages that no longer exist;
    // leave the /packages links in place.
  },
);
