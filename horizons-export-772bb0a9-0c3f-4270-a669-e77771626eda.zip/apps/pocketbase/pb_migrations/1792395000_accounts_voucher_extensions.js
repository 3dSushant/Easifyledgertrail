/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users');

    // ---- ledgers: subgroup select -> text (preserve existing values) ----
    const ledgers = app.findCollectionByNameOrId('ledgers');

    // Capture existing subgroup values before the type change drops the column.
    const existing = app.findAllRecords(ledgers).map((r) => ({
      id: r.id,
      subgroup: r.get('subgroup') || '',
    }));

    ledgers.fields.removeByName('subgroup');
    ledgers.fields.add(new TextField({ name: 'subgroup', max: 200 }));
    app.save(ledgers);

    // Restore the captured subgroup values into the new text column.
    for (const e of existing) {
      try {
        const rec = app.findRecordById('ledgers', e.id);
        rec.set('subgroup', e.subgroup);
        app.save(rec);
      } catch (_) {
        /* skip — leave empty rather than abort */
      }
    }

    // ---- ledgers: item code + opening balance fields ----
    const addLedgerField = (field) => {
      if (!ledgers.fields.getByName(field.name)) {
        ledgers.fields.add(field);
      }
    };
    addLedgerField(new TextField({ name: 'item_code', max: 100 }));
    addLedgerField(
      new TextField({ name: 'opening_balance_date', max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' }),
    );
    addLedgerField(
      new SelectField({ name: 'opening_balance_nature', maxSelect: 1, values: ['debit', 'credit'] }),
    );
    addLedgerField(new JSONField({ name: 'bill_wise_opening', maxSize: 2000000 }));
    app.save(ledgers);

    // ---- vouchers: bank/cash + purchase type fields ----
    const vouchers = app.findCollectionByNameOrId('vouchers');
    const ledgersId = ledgers.id;

    const addVoucherField = (field) => {
      if (!vouchers.fields.getByName(field.name)) {
        vouchers.fields.add(field);
      }
    };
    addVoucherField(
      new SelectField({ name: 'entry_kind', maxSelect: 1, values: ['payment', 'receipt'] }),
    );
    addVoucherField(new SelectField({ name: 'purchase_type', maxSelect: 1, values: ['goods'] }));
    addVoucherField(
      new RelationField({
        name: 'bank_cash_ledger',
        maxSelect: 1,
        collectionId: ledgersId,
        cascadeDelete: false,
      }),
    );
    app.save(vouchers);

    // ---- custom_subgroups: user-defined subgroups under a parent group ----
    let customSubgroups;
    try {
      customSubgroups = app.findCollectionByNameOrId('custom_subgroups');
    } catch (_) {
      customSubgroups = new Collection({
        name: 'custom_subgroups',
        type: 'base',
        listRule: "@request.auth.id != '' && owner = @request.auth.id",
        viewRule: "@request.auth.id != '' && owner = @request.auth.id",
        createRule: "@request.auth.id != '' && @request.body.owner = @request.auth.id",
        updateRule: "@request.auth.id != '' && owner = @request.auth.id && @request.body.owner:changed = false",
        deleteRule: "@request.auth.id != '' && owner = @request.auth.id",
        fields: [
          {
            name: 'owner',
            type: 'relation',
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          {
            name: 'group',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Assets', 'Liabilities', 'Income', 'Expenses', 'Equity'],
          },
          { name: 'name', type: 'text', required: true, max: 200 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE UNIQUE INDEX idx_custom_subgroups_owner_group_name ON custom_subgroups (owner, `group`, name)',
        ],
      });
      app.save(customSubgroups);
    }
  },
  (app) => {
    // ledgers: remove new fields, restore subgroup as select
    const ledgers = app.findCollectionByNameOrId('ledgers');
    ['item_code', 'opening_balance_date', 'opening_balance_nature', 'bill_wise_opening'].forEach(
      (name) => {
        try {
          ledgers.fields.removeByName(name);
        } catch (_) {}
      },
    );
    ledgers.fields.removeByName('subgroup');
    ledgers.fields.add(
      new SelectField({
        name: 'subgroup',
        required: true,
        maxSelect: 1,
        values: [
          'Fixed Assets', 'Investments', 'Inventory', 'Bank & Cash', 'Receivables',
          'Advances Given', 'Other Current Assets', 'Capital Introduced', 'Loans',
          'Supplier Outstanding', 'Other Current Liabilities', 'Sales', 'Other Income',
          'Direct Expenses', 'Indirect Expenses',
        ],
      }),
    );
    app.save(ledgers);

    // vouchers: remove new fields
    const vouchers = app.findCollectionByNameOrId('vouchers');
    ['entry_kind', 'purchase_type', 'bank_cash_ledger'].forEach((name) => {
      try {
        vouchers.fields.removeByName(name);
      } catch (_) {}
    });
    app.save(vouchers);

    // custom_subgroups: drop
    try {
      app.delete(app.findCollectionByNameOrId('custom_subgroups'));
    } catch (_) {}
  },
);
