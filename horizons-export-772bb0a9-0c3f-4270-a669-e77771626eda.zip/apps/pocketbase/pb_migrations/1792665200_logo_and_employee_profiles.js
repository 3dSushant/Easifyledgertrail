/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // ---- users: company logo (shown on invoices, salary slips, PDFs) ----
    const users = app.findCollectionByNameOrId('users');
    if (!users.fields.getByName('logo')) {
      users.fields.add(
        new FileField({
          name: 'logo',
          maxSelect: 1,
          maxSize: 2097152, // 2 MB
          mimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'],
        }),
      );
      app.save(users);
    }

    // ---- employees: expanded profile fields ----
    const employees = app.findCollectionByNameOrId('employees');

    const addField = (field) => {
      if (!employees.fields.getByName(field.name)) {
        employees.fields.add(field);
      }
    };

    // Employment & attendance configuration
    addField(new TextField({ name: 'joining_date', max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' }));
    addField(new TextField({ name: 'employee_code', max: 50 }));
    addField(new NumberField({ name: 'paid_leave_entitlement', min: 0 }));
    addField(new NumberField({ name: 'sick_leave_entitlement', min: 0 }));
    addField(new TextField({ name: 'office_start_time', max: 5, pattern: '^\\d{2}:\\d{2}$' }));
    addField(new TextField({ name: 'office_end_time', max: 5, pattern: '^\\d{2}:\\d{2}$' }));
    addField(new NumberField({ name: 'grace_period', min: 0 })); // minutes
    addField(
      new SelectField({
        name: 'weekly_off',
        maxSelect: 1,
        values: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
      }),
    );
    addField(new NumberField({ name: 'late_marks_per_halfday', min: 0 }));
    addField(new TextField({ name: 'late_mark_rule', max: 500 }));
    addField(new TextField({ name: 'early_leaving_rule', max: 500 }));
    addField(new TextField({ name: 'half_day_rule', max: 500 }));

    // Bank & tax details
    addField(new TextField({ name: 'bank_name', max: 200 }));
    addField(new TextField({ name: 'account_number', max: 40 }));
    addField(new TextField({ name: 'ifsc', max: 11 }));
    addField(new TextField({ name: 'account_holder_name', max: 200 }));
    addField(new TextField({ name: 'pan', max: 10 }));
    addField(new TextField({ name: 'aadhaar', max: 12, pattern: '^[0-9]{12}$' }));

    // Document uploads (KYC, salary slips, appointment/relieving letters, etc.)
    addField(
      new FileField({
        name: 'documents',
        maxSelect: 20,
        maxSize: 5242880, // 5 MB each
        mimeTypes: [
          'image/jpeg',
          'image/png',
          'image/webp',
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ],
      }),
    );

    app.save(employees);
  },
  (app) => {
    const users = app.findCollectionByNameOrId('users');
    try { users.fields.removeByName('logo'); } catch (_) {}
    app.save(users);

    const employees = app.findCollectionByNameOrId('employees');
    [
      'joining_date',
      'employee_code',
      'paid_leave_entitlement',
      'sick_leave_entitlement',
      'office_start_time',
      'office_end_time',
      'grace_period',
      'weekly_off',
      'late_marks_per_halfday',
      'late_mark_rule',
      'early_leaving_rule',
      'half_day_rule',
      'bank_name',
      'account_number',
      'ifsc',
      'account_holder_name',
      'pan',
      'aadhaar',
      'documents',
    ].forEach((name) => {
      try { employees.fields.removeByName(name); } catch (_) {}
    });
    app.save(employees);
  },
);
