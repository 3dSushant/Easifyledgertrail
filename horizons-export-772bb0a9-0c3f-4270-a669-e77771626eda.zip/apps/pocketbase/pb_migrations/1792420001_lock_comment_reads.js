/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const adminRule = "@request.auth.role = 'admin'";
    try {
      const comments = app.findCollectionByNameOrId('article_comments');
      // Comments are public content shown on article pages, but the submitter's
      // email must never be exposed. Lock reads to admin; the server loader
      // (superuser) fetches and strips email before rendering.
      comments.listRule = adminRule;
      comments.viewRule = adminRule;
      app.save(comments);
    } catch (e) {
      if (!e.message.includes('no rows')) throw e;
    }
  },
  (app) => {
    try {
      const comments = app.findCollectionByNameOrId('article_comments');
      comments.listRule = '';
      comments.viewRule = '';
      app.save(comments);
    } catch (e) {
      if (!e.message.includes('no rows')) throw e;
    }
  },
);
