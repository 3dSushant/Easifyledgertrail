/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users');

    const readRule =
      "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin')";
    const createRule =
      "@request.auth.id != '' && @request.body.owner = @request.auth.id";
    const updateRule =
      "@request.auth.id != '' && (owner = @request.auth.id || @request.auth.role = 'admin') && @request.body.owner:changed = false";

    // Chart of accounts — each ledger is an account (asset, liability, income, expense).
    const ledgers = new Collection({
      name: 'ledgers',
      type: 'base',
      listRule: readRule,
      viewRule: readRule,
      createRule: createRule,
      updateRule: updateRule,
      deleteRule: readRule,
      fields: [
        { name: 'owner', type: 'relation', required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
        { name: 'name', type: 'text', required: true, max: 200 },
        {
          name: 'group',
          type: 'select',
          required: true,
          maxSelect: 1,
          values: ['Assets', 'Liabilities', 'Income', 'Expenses', 'Equity'],
        },
        {
          name: 'subgroup',
          type: 'select',
          required: true,
          maxSelect: 1,
          values: [
            'Fixed Assets',
            'Investments',
            'Inventory',
            'Bank & Cash',
            'Receivables',
            'Advances Given',
            'Other Current Assets',
            'Capital Introduced',
            'Loans',
            'Supplier Outstanding',
            'Other Current Liabilities',
            'Sales',
            'Other Income',
            'Direct Expenses',
            'Indirect Expenses',
          ],
        },
        { name: 'opening_balance', type: 'number' },
        { name: 'project', type: 'text', max: 200 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_ledgers_owner ON ledgers (owner)',
        'CREATE INDEX idx_ledgers_group ON ledgers (group)',
      ],
    });
    app.save(ledgers);

    // Vouchers — double-entry journal entries. Each voucher carries its own
    // debit/credit lines as a JSON array so the full entry is one record.
    const vouchers = new Collection({
      name: 'vouchers',
      type: 'base',
      listRule: readRule,
      viewRule: readRule,
      createRule: createRule,
      updateRule: updateRule,
      deleteRule: readRule,
      fields: [
        { name: 'owner', type: 'relation', required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
        { name: 'date', type: 'text', required: true, max: 10, pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
        {
          name: 'type',
          type: 'select',
          required: true,
          maxSelect: 1,
          values: ['Sales', 'Purchase', 'Expense', 'Bank', 'Cash', 'Journal', 'Transfer'],
        },
        { name: 'reference', type: 'text', max: 200 },
        { name: 'counterparty', type: 'text', max: 200 },
        { name: 'notes', type: 'text', max: 2000 },
        { name: 'project', type: 'text', max: 200 },
        { name: 'entries', type: 'json', maxSize: 2000000 },
        { name: 'total', type: 'number', min: 0 },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE INDEX idx_vouchers_owner ON vouchers (owner)',
        'CREATE INDEX idx_vouchers_type ON vouchers (type)',
        'CREATE INDEX idx_vouchers_date ON vouchers (date)',
      ],
    });
    app.save(vouchers);
  },
  (app) => {
    try { app.delete(app.findCollectionByNameOrId('vouchers')); } catch (_) {}
    try { app.delete(app.findCollectionByNameOrId('ledgers')); } catch (_) {}
  },
);
