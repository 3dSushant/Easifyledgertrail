/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const adminRule = "@request.auth.role = 'admin'";

    // ---- Job applications (public create, admin only) ----
    let jobs;
    try {
      jobs = app.findCollectionByNameOrId('job_applications');
    } catch (_) {
      jobs = new Collection({
        type: 'base',
        name: 'job_applications',
        listRule: adminRule,
        viewRule: adminRule,
        createRule: '',
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          { name: 'full_name', type: 'text', required: true, max: 200 },
          { name: 'address', type: 'text', required: true, max: 1000 },
          { name: 'pin_code', type: 'text', required: true, max: 10, pattern: '^[0-9]{6}$' },
          { name: 'position', type: 'text', required: true, max: 200 },
          { name: 'phone', type: 'text', required: true, max: 30, pattern: '^[0-9+\\-\\s]{7,15}$' },
          { name: 'email', type: 'email', required: true },
          { name: 'current_ctc', type: 'text', max: 100 },
          {
            name: 'candidate_type',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Fresher', 'Experienced'],
          },
          { name: 'education', type: 'text', required: true, max: 1000 },
          { name: 'skills', type: 'text', required: true, max: 2000 },
          {
            name: 'resume',
            type: 'file',
            maxSelect: 1,
            maxSize: 5242880,
            mimeTypes: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
          },
          { name: 'experience', type: 'json', maxSize: 2000000 },
          {
            name: 'status',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['New', 'Shortlisted', 'Interview', 'Selected', 'Rejected'],
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
      });
      app.save(jobs);
    }

    // ---- News articles (public read published, admin write) ----
    let news;
    try {
      news = app.findCollectionByNameOrId('news_articles');
    } catch (_) {
      news = new Collection({
        type: 'base',
        name: 'news_articles',
        listRule: '',
        viewRule: '',
        createRule: adminRule,
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          { name: 'headline', type: 'text', required: true, max: 300 },
          { name: 'slug', type: 'text', required: true, max: 300 },
          { name: 'summary', type: 'text', required: true, max: 600 },
          { name: 'content', type: 'text', required: true, max: 50000 },
          { name: 'image', type: 'text', max: 500 },
          { name: 'author', type: 'text', max: 200 },
          {
            name: 'category',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Finance Updates', 'GST', 'Tax Compliance', 'Business News', 'Accounting', 'Payroll', 'Government Updates', 'General News'],
          },
          {
            name: 'status',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['draft', 'published'],
          },
          { name: 'likes', type: 'number', min: 0 },
          { name: 'dislikes', type: 'number', min: 0 },
          { name: 'published_at', type: 'date' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: [
          'CREATE UNIQUE INDEX idx_news_slug ON news_articles (slug)',
          'CREATE INDEX idx_news_status ON news_articles (status)',
        ],
      });
      app.save(news);
    }

    // ---- Article comments (public create, admin read/delete) ----
    let comments;
    try {
      comments = app.findCollectionByNameOrId('article_comments');
    } catch (_) {
      comments = new Collection({
        type: 'base',
        name: 'article_comments',
        listRule: '',
        viewRule: '',
        createRule: '',
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          { name: 'article', type: 'relation', required: true, maxSelect: 1, collectionId: news.id, cascadeDelete: true },
          { name: 'name', type: 'text', required: true, max: 100 },
          { name: 'email', type: 'email', required: true },
          { name: 'content', type: 'text', required: true, max: 2000 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_comments_article ON article_comments (article)'],
      });
      app.save(comments);
    }

    // ---- Article reactions (anonymous create, admin read/delete) ----
    let reactions;
    try {
      reactions = app.findCollectionByNameOrId('article_reactions');
    } catch (_) {
      reactions = new Collection({
        type: 'base',
        name: 'article_reactions',
        listRule: '',
        viewRule: '',
        createRule: '',
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          { name: 'article', type: 'relation', required: true, maxSelect: 1, collectionId: news.id, cascadeDelete: true },
          { name: 'session_id', type: 'text', required: true, max: 100 },
          {
            name: 'type',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['like', 'dislike'],
          },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE UNIQUE INDEX idx_reaction_article_session ON article_reactions (article, session_id)'],
      });
      app.save(reactions);
    }

    // ---- Packages (public read published, admin write) ----
    let packages;
    try {
      packages = app.findCollectionByNameOrId('packages');
    } catch (_) {
      packages = new Collection({
        type: 'base',
        name: 'packages',
        listRule: '',
        viewRule: '',
        createRule: adminRule,
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          {
            name: 'category',
            type: 'select',
            required: true,
            maxSelect: 1,
            values: ['Tax and Statutory Compliance', 'Accounting Services', 'Payroll and Staff Management'],
          },
          { name: 'name', type: 'text', required: true, max: 200 },
          { name: 'description', type: 'text', required: true, max: 2000 },
          { name: 'services', type: 'json', maxSize: 20000 },
          { name: 'image', type: 'text', max: 500 },
          { name: 'cta_text', type: 'text', max: 100 },
          { name: 'sort', type: 'number' },
          { name: 'published', type: 'bool' },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
        indexes: ['CREATE INDEX idx_packages_category ON packages (category)'],
      });
      app.save(packages);
    }

    // ---- Quote requests (public create, admin only) ----
    let quotes;
    try {
      quotes = app.findCollectionByNameOrId('quote_requests');
    } catch (_) {
      quotes = new Collection({
        type: 'base',
        name: 'quote_requests',
        listRule: adminRule,
        viewRule: adminRule,
        createRule: '',
        updateRule: adminRule,
        deleteRule: adminRule,
        fields: [
          { name: 'name', type: 'text', required: true, max: 200 },
          { name: 'company', type: 'text', max: 200 },
          { name: 'phone', type: 'text', required: true, max: 30, pattern: '^[0-9+\\-\\s]{7,15}$' },
          { name: 'email', type: 'email', required: true },
          { name: 'package', type: 'text', required: true, max: 300 },
          { name: 'message', type: 'text', max: 4000 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
          { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
        ],
      });
      app.save(quotes);
    }

    // ---- Seed default packages ----
    const taxImg = 'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/e7e8e836-c2be-49c7-aafc-8c764a4e7e78.png';
    const accImg = 'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/7f8b44af-6bee-4da3-9768-bfb662b83e7e.png';
    const payImg = 'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/d0d93d84-5ab0-4929-86a1-f06a6c8f1deb.png';

    const seedPackages = [
      {
        category: 'Tax and Statutory Compliance',
        name: 'Tax Compliance',
        description: 'Stay fully compliant with every statutory tax obligation — GST, TDS, PF, PT and ESIC — with timely filing, accurate records and proactive reminders so you never miss a deadline or pay a penalty.',
        services: ['GST filing & registration', 'TDS filing & registration', 'PF filing & registration', 'PT filing & registration', 'ESIC filing & registration', 'Shop Act registration', 'Firm registration', 'Food license registration'],
        image: taxImg, sort: 1,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'GST Filing and Registration',
        description: 'Complete GST registration and monthly, quarterly and annual return filing — GSTR-1, GSTR-3B, annual returns and input tax credit reconciliation handled end to end.',
        services: ['GST registration & amendments', 'GSTR-1 & 3B filing', 'Input tax credit reconciliation', 'Annual return & GSTR-9', 'Notices & reply support'],
        image: taxImg, sort: 2,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'TDS Filing and Registration',
        description: 'TDS deduction, challan payment and quarterly return filing with Form 16 and 16A issuance, keeping your Tax Deducted at Source fully compliant.',
        services: ['TDS deduction & challan payment', 'Quarterly return filing (24Q/26Q)', 'Form 16 & 16A issuance', 'TRACES correction & defaults'],
        image: taxImg, sort: 3,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'PF Filing and Registration',
        description: 'Provident Fund registration, monthly ECR filing and challan, member onboarding and exits, and KYC updates through the EPFO portal.',
        services: ['PF registration & UAN setup', 'Monthly ECR filing & challan', 'Member onboarding & exit', 'KYC & nominee updates', 'PF withdrawal & transfer support'],
        image: taxImg, sort: 4,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'PT Filing and Registration',
        description: 'Professional Tax registration, monthly and annual returns, and correct slab-based deduction from employee salaries as per your state.',
        services: ['PT registration (PEC & PTRC)', 'Monthly & annual returns', 'Employee slab-based deduction', 'Challan payment', 'Multi-state compliance support'],
        image: taxImg, sort: 5,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'ESIC Filing and Registration',
        description: 'ESIC registration, monthly contribution challan and return filing, and employee onboarding through the ESIC portal.',
        services: ['ESIC registration', 'Monthly contribution & challan', 'Employee onboarding & exits', 'Return filing on ESIC portal', 'Compliance & inspection support'],
        image: taxImg, sort: 6,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'Shop Act Registration',
        description: 'Shop & Establishment (Gumasta) license registration end to end — documentation, application, fees and follow-up with the local authority.',
        services: ['Document preparation', 'Application & filing', 'Fee payment handling', 'License follow-up', 'Renewal support'],
        image: taxImg, sort: 7,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'Firm Registration',
        description: 'Register your partnership firm or business entity — deed drafting, document preparation and filing with the Registrar of Firms.',
        services: ['Partnership deed drafting', 'Document preparation', 'Registrar of Firms filing', 'PAN & TAN application', 'Compliance setup'],
        image: taxImg, sort: 8,
      },
      {
        category: 'Tax and Statutory Compliance',
        name: 'Food License Registration',
        description: 'FSSAI food license — basic, state or central — registered and renewed, handling documentation, application and follow-up.',
        services: ['Basic / State / Central FSSAI', 'Document preparation', 'Application & filing', 'License follow-up', 'Annual renewal support'],
        image: taxImg, sort: 9,
      },
      {
        category: 'Accounting Services',
        name: 'Complete Digital Accounting',
        description: 'Easify Ledger maintains your accounting records in a computerized digital system — every transaction recorded, reconciled and ready for decisions. From profit and loss tracking to cash-flow monitoring, your books stay accurate and always accessible.',
        services: ['Profit and loss tracking', 'Expense tracking', 'Payables management', 'Receivables management', 'Inventory records management', 'Asset records management', 'Business cash-flow monitoring', 'Spending versus earnings analysis', 'Digital accounting records', 'Easy access to financial reports', 'Support for better business decisions'],
        image: accImg, sort: 10,
      },
      {
        category: 'Payroll and Staff Management',
        name: 'Complete Payroll & Staff Management',
        description: 'Easify Ledger manages your complete staff and payroll operations — from hiring support and candidate screening to salary processing and timely salary slips. Hassle-free staff management so you can focus on running your business.',
        services: ['Staff hiring support', 'Candidate screening and interviews', 'Joining and onboarding support', 'Employee documentation', 'Salary processing', 'Timely salary slips', 'Employee management', 'Payroll administration', 'Hassle-free staff management'],
        image: payImg, sort: 11,
      },
    ];

    seedPackages.forEach((item) => {
      let existing = [];
      try {
        existing = app.findRecordsByFilter('packages', `name = '${item.name.replace(/'/g, "\\'")}'`);
      } catch (_) {
        existing = [];
      }
      if (existing.length > 0) return;

      const rec = new Record(packages);
      rec.set('category', item.category);
      rec.set('name', item.name);
      rec.set('description', item.description);
      rec.set('services', item.services);
      rec.set('image', item.image);
      rec.set('cta_text', 'Get a Quote');
      rec.set('sort', item.sort);
      rec.set('published', true);
      app.save(rec);
    });
  },
  (app) => {
    const drop = (name) => {
      try {
        const collection = app.findCollectionByNameOrId(name);
        app.delete(collection);
      } catch (e) {
        if (!e.message.includes('no rows')) throw e;
      }
    };
    drop('quote_requests');
    drop('packages');
    drop('article_reactions');
    drop('article_comments');
    drop('news_articles');
    drop('job_applications');
  },
);
