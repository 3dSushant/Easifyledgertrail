/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // ---- ledgers: add master-kind + party/item/project detail fields ----
    const ledgers = app.findCollectionByNameOrId('ledgers');

    const addField = (field) => {
      if (!ledgers.fields.getByName(field.name)) {
        ledgers.fields.add(field);
      }
    };

    addField(
      new SelectField({
        name: 'kind',
        maxSelect: 1,
        values: ['account', 'party', 'project', 'item'],
      }),
    );
    addField(new TextField({ name: 'address', max: 500 }));
    addField(new TextField({ name: 'gstin', max: 15 }));
    addField(new TextField({ name: 'pan', max: 10 }));
    addField(new TextField({ name: 'bank_details', max: 500 }));
    addField(new TextField({ name: 'phone', max: 30 }));
    addField(new TextField({ name: 'email', max: 120 }));
    addField(new TextField({ name: 'hsn_code', max: 15 }));
    addField(new NumberField({ name: 'gst_rate', min: 0 }));
    addField(new TextField({ name: 'unit', max: 30 }));
    addField(new NumberField({ name: 'credit_days', min: 0 }));

    app.save(ledgers);

    // ---- vouchers: add invoice fields ----
    const vouchers = app.findCollectionByNameOrId('vouchers');
    const ledgersId = ledgers.id;

    const addVoucherField = (field) => {
      if (!vouchers.fields.getByName(field.name)) {
        vouchers.fields.add(field);
      }
    };

    addVoucherField(
      new RelationField({
        name: 'counterparty_ledger',
        maxSelect: 1,
        collectionId: ledgersId,
        cascadeDelete: false,
      }),
    );
    addVoucherField(
      new RelationField({
        name: 'project_ledger',
        maxSelect: 1,
        collectionId: ledgersId,
        cascadeDelete: false,
      }),
    );
    addVoucherField(new NumberField({ name: 'credit_days', min: 0 }));
    addVoucherField(
      new SelectField({
        name: 'sale_type',
        maxSelect: 1,
        values: ['goods', 'service'],
      }),
    );
    addVoucherField(new JSONField({ name: 'items', maxSize: 2000000 }));

    app.save(vouchers);
  },
  (app) => {
    const ledgers = app.findCollectionByNameOrId('ledgers');
    [
      'kind',
      'address',
      'gstin',
      'pan',
      'bank_details',
      'phone',
      'email',
      'hsn_code',
      'gst_rate',
      'unit',
      'credit_days',
    ].forEach((name) => {
      try {
        ledgers.fields.removeByName(name);
      } catch (_) {}
    });
    app.save(ledgers);

    const vouchers = app.findCollectionByNameOrId('vouchers');
    [
      'counterparty_ledger',
      'project_ledger',
      'credit_days',
      'sale_type',
      'items',
    ].forEach((name) => {
      try {
        vouchers.fields.removeByName(name);
      } catch (_) {}
    });
    app.save(vouchers);
  },
);
