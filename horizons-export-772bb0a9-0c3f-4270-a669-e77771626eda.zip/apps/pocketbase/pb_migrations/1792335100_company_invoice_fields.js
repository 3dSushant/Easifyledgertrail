/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // ---- users: business profile fields shown on the sales invoice PDF ----
    const users = app.findCollectionByNameOrId('users');

    const addUserField = (field) => {
      if (!users.fields.getByName(field.name)) {
        users.fields.add(field);
      }
    };

    addUserField(new TextField({ name: 'pan', max: 10 }));
    addUserField(new TextField({ name: 'bank_name', max: 200 }));
    addUserField(new TextField({ name: 'account_number', max: 40 }));
    addUserField(new TextField({ name: 'ifsc', max: 11 }));
    addUserField(new TextField({ name: 'upi_id', max: 100 }));
    addUserField(new TextField({ name: 'licenses', max: 2000 }));

    app.save(users);

    // ---- ledgers: separate party bank account number + IFSC ----
    const ledgers = app.findCollectionByNameOrId('ledgers');

    const addLedgerField = (field) => {
      if (!ledgers.fields.getByName(field.name)) {
        ledgers.fields.add(field);
      }
    };

    addLedgerField(new TextField({ name: 'account_number', max: 40 }));
    addLedgerField(new TextField({ name: 'ifsc', max: 11 }));

    app.save(ledgers);
  },
  (app) => {
    const users = app.findCollectionByNameOrId('users');
    ['pan', 'bank_name', 'account_number', 'ifsc', 'upi_id', 'licenses'].forEach((name) => {
      try {
        users.fields.removeByName(name);
      } catch (_) {}
    });
    app.save(users);

    const ledgers = app.findCollectionByNameOrId('ledgers');
    ['account_number', 'ifsc'].forEach((name) => {
      try {
        ledgers.fields.removeByName(name);
      } catch (_) {}
    });
    app.save(ledgers);
  },
);
