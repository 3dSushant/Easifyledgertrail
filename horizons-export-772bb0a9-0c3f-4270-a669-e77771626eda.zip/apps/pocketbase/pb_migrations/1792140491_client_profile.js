migrate((app) => {
  const users = app.findCollectionByNameOrId('users');
  users.createRule = null;
  users.fields.add(new TextField({ name: 'business_name', max: 200 }));
  users.fields.add(new TextField({ name: 'gstin', max: 15 }));
  users.fields.add(new TextField({ name: 'business_address', max: 1000 }));
  app.save(users);
});
