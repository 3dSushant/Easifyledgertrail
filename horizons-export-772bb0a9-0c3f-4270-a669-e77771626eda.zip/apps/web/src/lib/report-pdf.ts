import type { CompanyProfile } from '@/lib/business';

const money = (value: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value || 0);

/**
 * Generates a printable report PDF with the company logo, a title,
 * and a tabular set of headers/rows. Used for tax and payroll reports.
 */
export async function downloadReportPdf(
  title: string,
  headers: string[],
  rows: (string | number)[][],
  profile: CompanyProfile,
  filename: string,
) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 40;
  const contentW = pageW - margin * 2;
  let y = margin;

  // ---- Company logo ----
  let logoW = 0;
  if (profile.logo) {
    try {
      const resp = await fetch(profile.logo);
      if (resp.ok) {
        const blob = await resp.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const fr = new FileReader();
          fr.onload = () => resolve(String(fr.result));
          fr.onerror = reject;
          fr.readAsDataURL(blob);
        });
        const logoH = 28;
        logoW = logoH * (blob.type.includes('svg') ? 1.6 : 1.4);
        doc.addImage(dataUrl, blob.type.includes('png') ? 'PNG' : 'JPEG', margin, y, logoW, logoH);
      }
    } catch { /* skip logo */ }
  }

  // ---- Header ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(28, 30, 34);
  doc.text(profile.business_name || 'Business', margin + logoW + (logoW ? 10 : 0), y + 8);
  doc.setFontSize(11);
  doc.setTextColor(235, 73, 58);
  doc.text(title.toUpperCase(), pageW - margin, y + 8, { align: 'right' });
  y += 22;

  // ---- Company details ----
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(90, 92, 86);
  if (profile.business_address) { doc.text(profile.business_address, margin, y); y += 11; }
  if (profile.gstin) { doc.text(`GSTIN: ${profile.gstin}`, margin, y); y += 11; }
  if (profile.email) { doc.text(`Email: ${profile.email}`, margin, y); y += 11; }
  y += 10;

  // ---- Table header ----
  doc.setFillColor(245, 246, 242);
  doc.rect(margin, y, contentW, 20, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 102, 94);
  const colW = contentW / headers.length;
  headers.forEach((h, i) => {
    doc.text(h, margin + i * colW + 6, y + 13);
  });
  y += 20;

  // ---- Rows ----
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(50, 52, 46);
  for (const row of rows) {
    if (y > doc.internal.pageSize.getHeight() - 50) {
      doc.addPage();
      y = margin;
    }
    row.forEach((cell, i) => {
      const text = typeof cell === 'number' ? money(cell) : String(cell);
      doc.text(text, margin + i * colW + 6, y + 11, { maxWidth: colW - 12 });
    });
    y += 16;
  }

  // ---- Footer ----
  const footY = doc.internal.pageSize.getHeight() - 24;
  doc.setDrawColor(229, 229, 223);
  doc.line(margin, footY - 10, pageW - margin, footY - 10);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(140, 142, 134);
  doc.text('Computer-generated report — Easify Ledger.', pageW / 2, footY, { align: 'center' });

  doc.save(filename);
}
