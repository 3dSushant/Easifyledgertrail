import type { RecordModel } from 'pocketbase';

export type Service = RecordModel & {
  category: string;
  slug: string;
  title: string;
  tagline: string;
  content: string;
  image: string;
  price: string;
  features: string[];
  sort: number;
  published: boolean;
};

export type SiteSettings = RecordModel & {
  about_title: string;
  about_content: string;
  whatsapp: string;
  email: string;
  phone: string;
  location: string;
};

export type ServiceCategory = {
  slug: string;
  name: string;
  short: string;
  description: string;
};

export const serviceCategories: ServiceCategory[] = [
  {
    slug: 'tax-compliance',
    name: 'Tax Compliance',
    short: 'GST · TDS · PF · ESIC · PT',
    description:
      'Stay on top of every statutory tax obligation — GST, TDS, PF, ESIC and Professional Tax — with timely filing and accurate records.',
  },
  {
    slug: 'accounting-services',
    name: 'Accounting Services',
    short: 'Monthly · Quarterly · Yearly · Weekly',
    description:
      'Choose the accounting rhythm that fits your business — weekly, monthly, quarterly or yearly bookkeeping and financial statements.',
  },
  {
    slug: 'payroll-services',
    name: 'Payroll Services',
    short: 'Salary · Slips · Records · Hiring',
    description:
      'From salary working and payslips to employee records and affordable talent acquisition, we manage your people end to end.',
  },
  {
    slug: 'government-registration',
    name: 'Government Registration',
    short: 'Shop Act · Food License · Firm',
    description:
      'Get your business legally registered — Shop Act license, FSSAI food license and firm registration — handled end to end.',
  },
];

export function categoryBySlug(slug?: string) {
  return serviceCategories.find((c) => c.slug === slug);
}

export const defaultSettings: SiteSettings = {
  id: '',
  collectionId: '',
  collectionName: 'site_settings',
  about_title: 'About Easify Ledger',
  about_content:
    'Easify Ledger is a Pune-based business services practice helping small and growing businesses across India manage their accounting, payroll and statutory compliance with clarity and care.',
  whatsapp: '7620233934',
  email: 'info@EasifyLedger.com',
  phone: '7620233934',
  location: 'Pune, India — serving clients across India',
} as SiteSettings;

export const whatsappLink = (phone: string, text?: string) =>
  `https://wa.me/91${phone.replace(/\D/g, '').replace(/^91/, '')}${
    text ? `?text=${encodeURIComponent(text)}` : ''
  }`;
