import type { Ledger, Voucher } from '@/lib/accounts';

export type InvoiceReceivable = {
  voucher: Voucher;
  counterparty?: Ledger;
  invoiceDate: string;
  dueDate: string;
  creditDays: number;
  remainingDays: number;
  invoiced: number;
  received: number;
  outstanding: number;
  status: 'paid' | 'partial' | 'unpaid' | 'overdue' | 'due-soon';
};

export type DebtorReceivable = {
  ledger: Ledger;
  invoiced: number;
  received: number;
  outstanding: number;
  overdue: number;
  dueSoon: number;
  invoiceCount: number;
};

export type ReceivablesAnalysis = {
  invoices: InvoiceReceivable[];
  debtors: DebtorReceivable[];
  totalSales: number;
  amountReceived: number;
  outstanding: number;
  overdue: number;
  dueSoon: number;
  monthly: { month: string; label: string; total: number }[];
};

const DAY = 86400000;

function addDays(dateStr: string, days: number): string {
  const d = new Date(`${dateStr.slice(0, 10)}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Debtors = client (Receivables) party ledgers. */
export function debtorLedgers(ledgers: Ledger[]): Ledger[] {
  return ledgers.filter((l) => l.kind === 'party' && l.subgroup === 'Receivables');
}

/**
 * Receivables analysis with FIFO payment allocation per debtor.
 * Payments = bank/cash receipt entries that credit a debtor ledger.
 */
export function receivablesAnalysis(
  ledgers: Ledger[],
  vouchers: Voucher[],
  today: string,
): ReceivablesAnalysis {
  const debtors = debtorLedgers(ledgers);
  const debtorIds = new Set(debtors.map((d) => d.id));

  // Sales invoices per debtor, sorted by date.
  const invoicesByDebtor = new Map<string, Voucher[]>();
  for (const v of vouchers) {
    if (v.type !== 'Sales') continue;
    const cp = v.counterparty_ledger;
    if (!cp || !debtorIds.has(cp)) continue;
    if (!invoicesByDebtor.has(cp)) invoicesByDebtor.set(cp, []);
    invoicesByDebtor.get(cp)!.push(v);
  }
  for (const list of invoicesByDebtor.values()) {
    list.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  }

  // Payments received per debtor (receipt entries crediting a debtor), sorted by date.
  const paymentsByDebtor = new Map<string, { date: string; amount: number }[]>();
  for (const v of vouchers) {
    if (v.type !== 'Bank' && v.type !== 'Cash' && v.type !== 'Transfer') continue;
    if (v.entry_kind !== 'receipt') continue;
    for (const e of v.entries || []) {
      if (!debtorIds.has(e.ledger)) continue;
      const amt = Number(e.credit || 0);
      if (amt <= 0) continue;
      if (!paymentsByDebtor.has(e.ledger)) paymentsByDebtor.set(e.ledger, []);
      paymentsByDebtor.get(e.ledger)!.push({ date: e.date || v.date || today, amount: amt });
    }
  }
  for (const list of paymentsByDebtor.values()) {
    list.sort((a, b) => a.date.localeCompare(b.date));
  }

  const invoices: InvoiceReceivable[] = [];
  const debtorRows: DebtorReceivable[] = [];
  let totalSales = 0;
  let amountReceived = 0;
  let totalOutstanding = 0;
  let totalOverdue = 0;
  let totalDueSoon = 0;

  for (const debtor of debtors) {
    const invList = invoicesByDebtor.get(debtor.id) || [];
    const pays = [...(paymentsByDebtor.get(debtor.id) || [])];
    let payIdx = 0;
    let payPool = pays.length ? pays[0].amount : 0;

    let dInvoiced = 0;
    let dReceived = 0;
    let dOverdue = 0;
    let dDueSoon = 0;

    for (const v of invList) {
      const invoiced = Number(v.total || 0);
      totalSales += invoiced;
      dInvoiced += invoiced;
      const creditDays = Number(v.credit_days || 0);
      const invoiceDate = v.date || today;
      const dueDate = addDays(invoiceDate, creditDays);
      const remainingDays = Math.round(
        (new Date(`${dueDate}T00:00:00Z`).getTime() - new Date(`${today}T00:00:00Z`).getTime()) / DAY,
      );

      // FIFO allocate payments.
      let received = 0;
      let need = invoiced;
      while (need > 0 && payIdx < pays.length) {
        const take = Math.min(need, payPool);
        received += take;
        need -= take;
        payPool -= take;
        if (payPool <= 0) {
          payIdx += 1;
          payPool = payIdx < pays.length ? pays[payIdx].amount : 0;
        }
      }
      amountReceived += received;
      dReceived += received;
      const outstanding = invoiced - received;
      totalOutstanding += outstanding;

      let status: InvoiceReceivable['status'];
      if (outstanding <= 0) status = 'paid';
      else if (remainingDays < 0) status = 'overdue';
      else if (remainingDays <= 7) status = 'due-soon';
      else if (received > 0) status = 'partial';
      else status = 'unpaid';

      if (status === 'overdue') {
        totalOverdue += outstanding;
        dOverdue += outstanding;
      } else if (status === 'due-soon') {
        totalDueSoon += outstanding;
        dDueSoon += outstanding;
      }

      invoices.push({
        voucher: v,
        counterparty: debtor,
        invoiceDate,
        dueDate,
        creditDays,
        remainingDays,
        invoiced,
        received,
        outstanding,
        status,
      });
    }

    debtorRows.push({
      ledger: debtor,
      invoiced: dInvoiced,
      received: dReceived,
      outstanding: dInvoiced - dReceived,
      overdue: dOverdue,
      dueSoon: dDueSoon,
      invoiceCount: invList.length,
    });
  }

  // Monthly sales breakup (last 12 months with activity).
  const monthMap = new Map<string, number>();
  for (const v of vouchers) {
    if (v.type !== 'Sales') continue;
    const m = (v.date || '').slice(0, 7);
    if (!m) continue;
    monthMap.set(m, (monthMap.get(m) || 0) + Number(v.total || 0));
  }
  const monthly = Array.from(monthMap.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-12)
    .map(([month, total]) => ({
      month,
      label: new Intl.DateTimeFormat('en-IN', { month: 'short', year: '2-digit', timeZone: 'UTC' }).format(
        new Date(`${month}-01T00:00:00Z`),
      ),
      total,
    }));

  return {
    invoices,
    debtors: debtorRows,
    totalSales,
    amountReceived,
    outstanding: totalOutstanding,
    overdue: totalOverdue,
    dueSoon: totalDueSoon,
    monthly,
  };
}

export type InventoryRow = {
  ledger: Ledger;
  purchasedQty: number;
  purchasedValue: number;
  soldQty: number;
  soldValue: number;
  balanceQty: number;
  avgRate: number;
  stockValue: number;
};

export type InventoryAnalysis = {
  rows: InventoryRow[];
  totalPurchasedValue: number;
  totalSoldValue: number;
  totalStockValue: number;
  totalBalanceQty: number;
};

/**
 * Per-item stock derived from purchase (Post to Inventory) and sales vouchers.
 * Purchase items with post_to='inventory' add stock; sales items reduce it.
 */
export function inventoryAnalysis(ledgers: Ledger[], vouchers: Voucher[]): InventoryAnalysis {
  const items = ledgers.filter((l) => l.kind === 'item');
  const rows: InventoryRow[] = [];
  let totalPurchasedValue = 0;
  let totalSoldValue = 0;
  let totalStockValue = 0;
  let totalBalanceQty = 0;

  for (const item of items) {
    let purchasedQty = 0;
    let purchasedValue = 0;
    let soldQty = 0;

    for (const v of vouchers) {
      for (const it of v.items || []) {
        if (it.item_ledger !== item.id) continue;
        if (v.type === 'Purchase' && (it as { post_to?: string }).post_to === 'inventory') {
          purchasedQty += Number(it.qty || 0);
          purchasedValue += Number(it.amount || 0);
        } else if (v.type === 'Sales') {
          soldQty += Number(it.qty || 0);
        }
      }
    }

    const avgRate = purchasedQty > 0 ? purchasedValue / purchasedQty : 0;
    const balanceQty = purchasedQty - soldQty;
    const soldValue = soldQty * avgRate;
    const stockValue = balanceQty * avgRate;

    totalPurchasedValue += purchasedValue;
    totalSoldValue += soldValue;
    totalStockValue += stockValue;
    totalBalanceQty += balanceQty;

    rows.push({
      ledger: item,
      purchasedQty,
      purchasedValue,
      soldQty,
      soldValue,
      balanceQty,
      avgRate,
      stockValue,
    });
  }

  return {
    rows: rows.filter((r) => r.purchasedQty > 0 || r.soldQty > 0 || r.balanceQty !== 0),
    totalPurchasedValue,
    totalSoldValue,
    totalStockValue,
    totalBalanceQty,
  };
}
