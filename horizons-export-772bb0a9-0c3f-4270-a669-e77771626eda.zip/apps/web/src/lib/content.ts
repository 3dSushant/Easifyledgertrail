import type { RecordModel } from 'pocketbase';
import { POCKETBASE_API_URL } from '@/lib/pocketbase-client';

export type JobApplication = RecordModel & {
  full_name: string;
  address: string;
  pin_code: string;
  position: string;
  phone: string;
  email: string;
  current_ctc: string;
  candidate_type: 'Fresher' | 'Experienced';
  education: string;
  skills: string;
  resume: string;
  experience: ExperienceRecord[];
  status: 'New' | 'Shortlisted' | 'Interview' | 'Selected' | 'Rejected';
};

export type ExperienceRecord = {
  company: string;
  startDate: string;
  endDate: string;
  position: string;
  responsibilities: string;
};

export type NewsArticle = RecordModel & {
  headline: string;
  slug: string;
  summary: string;
  content: string;
  image: string;
  image_file?: string;
  author: string;
  category: string;
  status: 'draft' | 'published';
  likes: number;
  dislikes: number;
  published_at: string;
};

export type ArticleComment = RecordModel & {
  article: string;
  name: string;
  email?: string;
  content: string;
};

export type Package = RecordModel & {
  category: string;
  name: string;
  description: string;
  services: string[];
  image: string;
  cta_text: string;
  sort: number;
  published: boolean;
};

export type QuoteRequest = RecordModel & {
  name: string;
  company: string;
  phone: string;
  email: string;
  package: string;
  message: string;
};

export const jobCategories = [
  'Accounts and Finance',
  'Operations',
  'Human Resources',
  'Purchase and Stores',
  'Engineering',
  'Sales',
  'Telecaller',
  'Managers',
  'Other Positions',
];

export const newsCategories = [
  'Finance Updates',
  'GST',
  'Tax Compliance',
  'Business News',
  'Accounting',
  'Payroll',
  'Government Updates',
  'General News',
];

export const packageCategories = [
  {
    slug: 'tax-and-statutory-compliance',
    name: 'Tax and Statutory Compliance',
    short: 'GST · TDS · PF · PT · ESIC · Registrations',
    description:
      'Stay on top of every statutory tax obligation with timely filing and accurate records — GST, TDS, PF, PT, ESIC and government registrations handled end to end.',
  },
  {
    slug: 'accounting-services',
    name: 'Accounting Services',
    short: 'Digital books · P&L · Cash flow · Reports',
    description:
      'Easify Ledger maintains your accounting records in a computerized digital system — every transaction recorded, reconciled and ready for better business decisions.',
  },
  {
    slug: 'payroll-and-staff-management',
    name: 'Payroll and Staff Management',
    short: 'Hiring · Salary · Slips · Administration',
    description:
      'Easify Ledger manages your complete staff and payroll operations — from hiring support and screening to salary processing and timely salary slips.',
  },
];

export function packageCategoryBySlug(slug?: string) {
  return packageCategories.find((c) => c.slug === slug);
}

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

/** Resolves a news article's featured image: uploaded file first, then legacy URL. */
export function articleImageUrl(article: NewsArticle): string | undefined {
  if (article.image_file) {
    return `${POCKETBASE_API_URL}/api/files/${article.collectionId}/${article.id}/${article.image_file}`;
  }
  return article.image || undefined;
}

/** A stable per-browser session id used to dedupe article likes/dislikes. */
export function sessionId() {
  if (typeof window === 'undefined') return 'server';
  const key = 'el_session_id';
  let id = window.localStorage.getItem(key);
  if (!id) {
    id = `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    window.localStorage.setItem(key, id);
  }
  return id;
}
