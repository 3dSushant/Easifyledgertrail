import { pocketbaseAdmin } from '@/lib/pocketbase-client.server';
import type { NewsArticle, Package, ArticleComment } from '@/lib/content';

/** Public-safe comments for an article (email stripped). */
export async function getArticleComments(articleId: string): Promise<ArticleComment[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<ArticleComment>('article_comments', {
      filter: pocketbaseAdmin.filter('article = {:articleId}', { articleId }),
      sort: '-created',
      perPage: 500,
    });
    return result.items.map((c) => ({ id: c.id, collectionId: '', collectionName: 'article_comments', article: c.article, name: c.name, content: c.content, created: c.created } as ArticleComment));
  } catch {
    return [];
  }
}

/** All published news articles, newest first. */
export async function getPublishedArticles(): Promise<NewsArticle[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<NewsArticle>('news_articles', {
      filter: 'status = "published"',
      sort: '-published_at,-created',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}

/** All news articles (including drafts) — used by the admin CMS. */
export async function getAllArticles(): Promise<NewsArticle[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<NewsArticle>('news_articles', {
      sort: '-created',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}

/** All published packages, sorted by category then display order. */
export async function getPublishedPackages(): Promise<Package[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<Package>('packages', {
      filter: 'published = true',
      sort: 'category,sort',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}

/** All packages (including hidden) — used by the admin CMS. */
export async function getAllPackages(): Promise<Package[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<Package>('packages', {
      sort: 'category,sort',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}
