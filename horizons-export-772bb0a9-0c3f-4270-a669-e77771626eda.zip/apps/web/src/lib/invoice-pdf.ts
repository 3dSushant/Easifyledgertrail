import type { Voucher, Ledger } from '@/lib/accounts';
import type { CompanyProfile } from '@/lib/business';

const money = (value: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value || 0);

function dateLabel(value?: string) {
  if (!value) return '—';
  const date = new Date(`${value.slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date);
}

/** Builds a UPI deep-link string for the QR code on the invoice. */
export function upiPayLink(profile: CompanyProfile, amount: number, note?: string): string {
  const pa = (profile.upi_id || '').trim();
  if (!pa) return '';
  const pn = encodeURIComponent(profile.business_name || 'Business');
  const params = new URLSearchParams();
  params.set('pa', pa);
  params.set('pn', profile.business_name || 'Business');
  if (amount > 0) params.set('am', String(amount));
  params.set('cu', 'INR');
  if (note) params.set('tn', note);
  return `upi://pay?${params.toString()}`;
}

/**
 * Generates a printable sales-invoice PDF with company details, counterparty
 * details, the item table, totals, and a UPI payment QR code.
 */
export async function downloadInvoicePdf(
  voucher: Voucher,
  profile: CompanyProfile,
  counterparty?: Ledger,
  documentType: 'sales' | 'purchase' = 'sales',
) {
  const { jsPDF } = await import('jspdf');
  const QRCode = (await import('qrcode')).default;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 40;
  const contentW = pageW - margin * 2;
  let y = margin;

  // ---- Company logo (left of business name) ----
  let logoW = 0;
  if (profile.logo) {
    try {
      const resp = await fetch(profile.logo);
      if (resp.ok) {
        const blob = await resp.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const fr = new FileReader();
          fr.onload = () => resolve(String(fr.result));
          fr.onerror = reject;
          fr.readAsDataURL(blob);
        });
        const logoH = 34;
        logoW = logoH * (blob.type.includes('svg') ? 1.6 : 1.4);
        doc.addImage(dataUrl, blob.type.includes('png') ? 'PNG' : 'JPEG', margin, y, logoW, logoH);
      }
    } catch {
      /* logo load failed — skip silently */
    }
  }

  // ---- Header: business name + invoice title ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(28, 30, 34);
  doc.text(profile.business_name || 'Business', margin + logoW + (logoW ? 10 : 0), y + 8);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(235, 73, 58);
  doc.text(documentType === 'purchase' ? 'PURCHASE BILL' : 'TAX INVOICE', pageW - margin, y + 8, { align: 'right' });
  y += 22;

  // ---- Business details (left) ----
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(90, 92, 86);
  const bizLines: string[] = [];
  if (profile.business_address) bizLines.push(profile.business_address);
  if (profile.gstin) bizLines.push(`GSTIN: ${profile.gstin}`);
  if (profile.pan) bizLines.push(`PAN: ${profile.pan}`);
  if (profile.email) bizLines.push(`Email: ${profile.email}`);
  if (profile.phone) bizLines.push(`Phone: ${profile.phone}`);
  if (profile.licenses) bizLines.push(`Licences: ${profile.licenses}`);
  bizLines.forEach((line) => {
    doc.text(line, margin, y);
    y += 13;
  });

  // ---- Invoice meta (right) ----
  let metaY = margin + 22;
  doc.setFontSize(9);
  doc.setTextColor(60, 62, 56);
  const meta: [string, string][] = [
    ['Invoice no.', voucher.reference || '—'],
    ['Date', dateLabel(voucher.date)],
    ['Type', voucher.sale_type === 'service' ? 'Service sale' : 'Goods sale'],
  ];
  if (voucher.credit_days) meta.push(['Credit period', `${voucher.credit_days} days`]);
  meta.forEach(([k, v]) => {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(120, 122, 114);
    doc.text(k, pageW - margin - 160, metaY);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(40, 42, 36);
    doc.text(String(v), pageW - margin, metaY, { align: 'right' });
    metaY += 13;
  });
  y = Math.max(y, metaY) + 16;

  // ---- Bill to (counterparty) ----
  doc.setDrawColor(229, 229, 223);
  doc.line(margin, y, pageW - margin, y);
  y += 14;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 122, 114);
  doc.text('BILL TO', margin, y);
  y += 14;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(28, 30, 34);
  doc.text(voucher.counterparty || counterparty?.name || '—', margin, y);
  y += 14;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(90, 92, 86);
  const partyLines: string[] = [];
  if (counterparty?.address) partyLines.push(counterparty.address);
  if (counterparty?.gstin) partyLines.push(`GSTIN: ${counterparty.gstin}`);
  if (counterparty?.pan) partyLines.push(`PAN: ${counterparty.pan}`);
  if (counterparty?.phone) partyLines.push(`Phone: ${counterparty.phone}`);
  partyLines.forEach((line) => {
    doc.text(line, margin, y);
    y += 12;
  });
  y += 10;

  // ---- Items table ----
  const isGoods = voucher.sale_type !== 'service';
  const cols = isGoods
    ? [
        { label: 'Item', w: contentW * 0.28 },
        { label: 'Code', w: contentW * 0.1 },
        { label: 'HSN', w: contentW * 0.1 },
        { label: 'Qty', w: contentW * 0.08, align: 'right' as const },
        { label: 'Rate', w: contentW * 0.12, align: 'right' as const },
        { label: 'Disc %', w: contentW * 0.08, align: 'right' as const },
        { label: 'GST %', w: contentW * 0.1, align: 'right' as const },
        { label: 'Amount', w: contentW * 0.14, align: 'right' as const },
      ]
    : [
        { label: 'Service', w: contentW * 0.32 },
        { label: 'Code', w: contentW * 0.1 },
        { label: 'HSN', w: contentW * 0.1 },
        { label: 'Qty / Nos', w: contentW * 0.14 },
        { label: 'Rate', w: contentW * 0.12, align: 'right' as const },
        { label: 'GST %', w: contentW * 0.1, align: 'right' as const },
        { label: 'Amount', w: contentW * 0.12, align: 'right' as const },
      ];

  // table header
  doc.setFillColor(245, 246, 242);
  doc.rect(margin, y, contentW, 20, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 102, 94);
  let x = margin;
  cols.forEach((c) => {
    doc.text(c.label, c.align === 'right' ? x + c.w - 6 : x + 6, y + 13, {
      align: c.align === 'right' ? 'right' : 'left',
    });
    x += c.w;
  });
  y += 20;

  // rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(50, 52, 46);
  const items = voucher.items || [];
  items.forEach((it, idx) => {
    if (idx % 2 === 1) {
      doc.setFillColor(250, 250, 247);
      doc.rect(margin, y, contentW, 18, 'F');
    }
    x = margin;
    const cells = isGoods
      ? [
          it.itemName || '—',
          it.item_code || '—',
          it.hsn || '—',
          String(it.qty ?? '—'),
          it.rate != null ? money(it.rate) : '—',
          String(it.discount ?? 0),
          String(it.gst_rate ?? 0),
          money(it.amount),
        ]
      : [
          it.itemName || '—',
          it.item_code || '—',
          it.hsn || '—',
          it.qtyText || '—',
          it.rate != null ? money(it.rate) : '—',
          String(it.gst_rate ?? 0),
          money(it.amount),
        ];
    cells.forEach((cell, ci) => {
      const c = cols[ci];
      doc.text(String(cell), c.align === 'right' ? x + c.w - 6 : x + 6, y + 12, {
        align: c.align === 'right' ? 'right' : 'left',
        maxWidth: c.w - 12,
      });
      x += c.w;
    });
    y += 18;
  });

  // totals
  y += 8;
  const subtotal = items.reduce((s, i) => s + i.amount, 0);
  const totalGst = items.reduce((s, i) => s + i.gst_amount, 0);
  const grandTotal = subtotal + totalGst;
  const totalsX = pageW - margin - 200;
  const row = (label: string, value: string, bold = false) => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(bold ? 10 : 9);
    doc.setTextColor(bold ? 28 : 90, bold ? 30 : 92, bold ? 34 : 86);
    doc.text(label, totalsX, y);
    doc.text(value, pageW - margin, y, { align: 'right' });
    y += 15;
  };
  row('Subtotal', money(subtotal));
  row('GST', money(totalGst));
  doc.setDrawColor(229, 229, 223);
  doc.line(totalsX, y - 4, pageW - margin, y - 4);
  y += 4;
  row('Grand total', money(grandTotal), true);
  y += 10;

  // ---- Bank details + UPI QR ----
  const hasBank = profile.bank_name || profile.account_number || profile.ifsc;
  const upiLink = upiPayLink(profile, grandTotal, voucher.reference);
  const footerTop = Math.max(y + 10, doc.internal.pageSize.getHeight() - 170);

  if (hasBank) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(120, 122, 114);
    doc.text('BANK DETAILS', margin, footerTop);
    let by = footerTop + 14;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 62, 56);
    if (profile.bank_name) { doc.text(`Bank: ${profile.bank_name}`, margin, by); by += 12; }
    if (profile.account_number) { doc.text(`A/c No: ${profile.account_number}`, margin, by); by += 12; }
    if (profile.ifsc) { doc.text(`IFSC: ${profile.ifsc}`, margin, by); by += 12; }
    if (profile.upi_id) { doc.text(`UPI: ${profile.upi_id}`, margin, by); by += 12; }
  }

  if (upiLink) {
    try {
      const qrData = await QRCode.toDataURL(upiLink, { margin: 1, width: 240 });
      const qrSize = 90;
      const qrX = pageW - margin - qrSize;
      const qrY = footerTop - 6;
      doc.addImage(qrData, 'PNG', qrX, qrY, qrSize, qrSize);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(120, 122, 114);
      doc.text('Scan to pay', qrX + qrSize / 2, qrY + qrSize + 12, { align: 'center' });
    } catch {
      /* QR generation failed — skip silently */
    }
  }

  // ---- Footer ----
  const footY = doc.internal.pageSize.getHeight() - 24;
  doc.setDrawColor(229, 229, 223);
  doc.line(margin, footY - 10, pageW - margin, footY - 10);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(140, 142, 134);
  doc.text(
    'This is a computer-generated invoice and does not require a physical signature.',
    pageW / 2,
    footY,
    { align: 'center' },
  );

  const filename = `${documentType === 'purchase' ? 'purchase' : 'invoice'}-${voucher.reference || voucher.id}.pdf`;
  doc.save(filename);
}
