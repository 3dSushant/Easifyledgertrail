import type { Ledger, Voucher } from '@/lib/accounts';
import type { BusinessRecord } from '@/lib/business';
import { ledgerBalance, money } from '@/lib/accounts';

export type TaxDashboard = {
  type: string;
  full: string;
  payable: number;
  paid: number;
  outstanding: number;
  items: BusinessRecord[];
};

export type GstDashboard = {
  outputGst: number;
  inputGst: number;
  netPayable: number;
  creditBalance: number;
  rcmLiability: number;
};

/**
 * GST dashboard derived from Output GST and Input GST ledger balances.
 * Output GST (sales) is a liability; Input GST (purchases) is a credit.
 */
export function gstDashboard(ledgers: Ledger[], vouchers: Voucher[]): GstDashboard {
  const output = ledgers.find((l) => l.name.toLowerCase().includes('output gst'));
  const input = ledgers.find((l) => l.name.toLowerCase().includes('input gst'));
  const outputGst = output ? ledgerBalance(output, vouchers) : 0;
  const inputGst = input ? ledgerBalance(input, vouchers) : 0;
  const netPayable = Math.max(0, outputGst - inputGst);
  const creditBalance = Math.max(0, inputGst - outputGst);
  return { outputGst, inputGst, netPayable, creditBalance, rcmLiability: 0 };
}

/** TDS deducted on expense vouchers — the TDS Payable ledger balance. */
export function tdsLedgerBalance(ledgers: Ledger[], vouchers: Voucher[]): number {
  const tds = ledgers.find((l) => l.name.toLowerCase().includes('tds payable'));
  return tds ? ledgerBalance(tds, vouchers) : 0;
}

/**
 * Tax dashboards for TDS, PF, ESIC, PT from compliance items.
 * Payable = total amount, Paid = filed items, Outstanding = open items.
 */
export function taxDashboards(compliance: BusinessRecord[]): TaxDashboard[] {
  const types: { type: string; full: string }[] = [
    { type: 'GST', full: 'Goods & Services Tax' },
    { type: 'TDS', full: 'Tax Deducted at Source' },
    { type: 'PF', full: 'Provident Fund' },
    { type: 'PT', full: 'Professional Tax' },
    { type: 'ESIC', full: 'Employees’ State Insurance' },
  ];
  return types.map(({ type, full }) => {
    const items = compliance.filter((c) => c.type === type);
    const payable = items.reduce((s, c) => s + Number(c.amount || 0), 0);
    const paid = items.filter((c) => c.status === 'Filed').reduce((s, c) => s + Number(c.amount || 0), 0);
    const outstanding = payable - paid;
    return { type, full, payable, paid, outstanding, items };
  });
}

export { money };
