export type CapabilityContent = {
  number: string;
  title: string;
  description: string;
  items: string[];
  link: string;
  label: string;
};

export type HomeContent = {
  hero: {
    eyebrow: string;
    heading: string;
    description: string;
    ctaText: string;
    ctaLink: string;
    linkText: string;
  };
  capabilities: {
    eyebrow: string;
    title: string;
    description: string;
    items: CapabilityContent[];
  };
  howItWorks: {
    eyebrow: string;
    heading: string;
    description: string;
    ctaText: string;
    ctaLink: string;
    steps: { title: string; description: string }[];
  };
  closing: {
    eyebrow: string;
    heading: string;
    description: string;
  };
};

export const defaultHomeContent: HomeContent = {
  hero: {
    eyebrow: 'ONE WORKSPACE. YOUR WHOLE BUSINESS.',
    heading: 'Everything Your Business Needs in One Place.',
    description:
      'From automated GST, TDS, PF, and ESIC compliances to real-time P&L & Expenses tracking, inventory, and payroll—run your entire business seamlessly at a low cost.',
    ctaText: 'Enter your workspace',
    ctaLink: '/login',
    linkText: "See what's inside",
  },
  capabilities: {
    eyebrow: 'LESS ADMIN. MORE BUSINESS.',
    title: 'Everything in its place.\nYou in control.',
    description:
      'Three essential parts of your business.\nOne connected place to manage them.',
    items: [
      {
        number: '01',
        title: 'Accounting,\nmade simple.',
        description:
          'Manage all your business finances in one place. Track sales, expenses, profits, payments, stock and assets with easy-to-understand reports. Our online accounting software can also be customised to suit your business needs.',
        items: [
          'Income & expense tracking',
          'Manage stock, asset & payment',
          'Clear financial summaries',
        ],
        link: '/packages',
        label: 'Explore accounting',
      },
      {
        number: '02',
        title: 'Your people.\nOur Support.',
        description:
          'Make employee management and salary processing easier. We handle salary calculations, payslips, employee records, background checks, hiring support and payroll work at an affordable cost.',
        items: [
          'Salary Calculation and Pay Slip',
          'Employee records Management',
          'Hiring Support and Payroll Management',
        ],
        link: '/packages',
        label: 'Explore payroll',
      },
      {
        number: '03',
        title: 'Tax & compliance\nmade easy.',
        description:
          'Take the stress out of taxes and government paperwork. We help manage GST, TDS, PF, ESIC, Professional Tax, tax return filing and business registrations, so you can focus on running your business.',
        items: [
          'GST, TDS, PF, PT & ESIC',
          'Filing status & due-date tracking',
          'Acknowledgements & references',
        ],
        link: '/packages',
        label: 'Explore compliance',
      },
    ],
  },
  howItWorks: {
    eyebrow: 'A SIMPLER WORKING DAY',
    heading: 'From scattered\nto sorted.',
    description:
      'No disconnected spreadsheets. No switching between tools. Just a clear workflow for your business information.',
    ctaText: 'Request client access',
    ctaLink: '/login?mode=request',
    steps: [
      { title: 'Step into your workspace.', description: 'Sign in to a private account dedicated to your business.' },
      { title: 'Put your information to work.', description: 'Record transactions, manage employees and add your compliance obligations.' },
      { title: 'See the whole picture.', description: 'Review financial summaries, payroll runs and filing statuses in one place.' },
    ],
  },
  closing: {
    eyebrow: 'CLARITY STARTS HERE.',
    heading: 'Get back to\nyour business.',
    description: 'Your books, payroll and compliance. Together at last.',
  },
};
