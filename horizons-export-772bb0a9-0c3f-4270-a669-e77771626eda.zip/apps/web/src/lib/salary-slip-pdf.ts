import type { CompanyProfile } from '@/lib/business';

export type SalarySlipEmployee = {
  name: string;
  designation?: string;
  department?: string;
  employee_code?: string;
  basic?: number;
  allowances?: number;
  deductions?: number;
  tds?: number;
  net?: number;
  bank_name?: string;
  account_number?: string;
  ifsc?: string;
  account_holder_name?: string;
  pan?: string;
};

const money = (value: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value || 0);

/**
 * Generates a one-page printable salary slip PDF with the company logo,
 * employee details, earnings, deductions, TDS, and net pay.
 */
export async function downloadSalarySlipPdf(
  employee: SalarySlipEmployee,
  period: string,
  profile: CompanyProfile,
) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 40;
  let y = margin;

  // ---- Company logo ----
  let logoW = 0;
  if (profile.logo) {
    try {
      const resp = await fetch(profile.logo);
      if (resp.ok) {
        const blob = await resp.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const fr = new FileReader();
          fr.onload = () => resolve(String(fr.result));
          fr.onerror = reject;
          fr.readAsDataURL(blob);
        });
        const logoH = 30;
        logoW = logoH * (blob.type.includes('svg') ? 1.6 : 1.4);
        doc.addImage(dataUrl, blob.type.includes('png') ? 'PNG' : 'JPEG', margin, y, logoW, logoH);
      }
    } catch { /* skip logo */ }
  }

  // ---- Header ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(28, 30, 34);
  doc.text(profile.business_name || 'Business', margin + logoW + (logoW ? 10 : 0), y + 8);
  doc.setFontSize(11);
  doc.setTextColor(235, 73, 58);
  doc.text('SALARY SLIP', pageW - margin, y + 8, { align: 'right' });
  y += 22;

  // ---- Company details ----
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(90, 92, 86);
  const bizLines: string[] = [];
  if (profile.business_address) bizLines.push(profile.business_address);
  if (profile.gstin) bizLines.push(`GSTIN: ${profile.gstin}`);
  if (profile.email) bizLines.push(`Email: ${profile.email}`);
  if (profile.phone) bizLines.push(`Phone: ${profile.phone}`);
  bizLines.forEach((line) => { doc.text(line, margin, y); y += 11; });

  // ---- Pay period + employee details ----
  y += 8;
  doc.setDrawColor(229, 229, 223);
  doc.line(margin, y, pageW - margin, y);
  y += 14;

  const basic = Number(employee.basic || 0);
  const allowances = Number(employee.allowances || 0);
  const deductions = Number(employee.deductions || 0);
  const tds = Number(employee.tds || 0);
  const gross = basic + allowances;
  const totalDeductions = deductions + tds;
  const net = employee.net != null ? Number(employee.net) : Math.max(0, gross - totalDeductions);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(120, 122, 114);
  doc.text('PAY PERIOD', margin, y);
  doc.text('EMPLOYEE DETAILS', pageW - margin, y, { align: 'right' });
  y += 14;

  doc.setFontSize(10);
  doc.setTextColor(28, 30, 34);
  doc.text(period, margin, y);
  doc.text(employee.name || '—', pageW - margin, y, { align: 'right' });
  y += 14;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(90, 92, 86);
  const empInfo: string[] = [];
  if (employee.designation) empInfo.push(`Designation: ${employee.designation}`);
  if (employee.department) empInfo.push(`Department: ${employee.department}`);
  if (employee.employee_code) empInfo.push(`Emp ID: ${employee.employee_code}`);
  if (employee.pan) empInfo.push(`PAN: ${employee.pan}`);
  doc.text(empInfo.join('   ·   '), pageW - margin, y, { align: 'right' });
  y += 20;

  // ---- Earnings & Deductions side by side ----
  const colW = (pageW - margin * 2 - 20) / 2;
  const earningsX = margin;
  const deductionsX = margin + colW + 20;

  // Headers
  doc.setFillColor(245, 246, 242);
  doc.rect(earningsX, y, colW, 18, 'F');
  doc.rect(deductionsX, y, colW, 18, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 102, 94);
  doc.text('EARNINGS', earningsX + 8, y + 12);
  doc.text('Amount', earningsX + colW - 8, y + 12, { align: 'right' });
  doc.text('DEDUCTIONS', deductionsX + 8, y + 12);
  doc.text('Amount', deductionsX + colW - 8, y + 12, { align: 'right' });
  y += 18;

  // Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(50, 52, 46);
  const earnRows: [string, number][] = [
    ['Basic salary', basic],
    ['Allowances', allowances],
  ];
  const dedRows: [string, number][] = [
    ['Deductions', deductions],
    ['TDS', tds],
  ];

  const rowH = 16;
  earnRows.forEach(([label, amt]) => {
    doc.text(label, earningsX + 8, y + 11);
    doc.text(money(amt), earningsX + colW - 8, y + 11, { align: 'right' });
    y += rowH;
  });
  // Gross total
  doc.setDrawColor(229, 229, 223);
  doc.line(earningsX, y, earningsX + colW, y);
  y += 4;
  doc.setFont('helvetica', 'bold');
  doc.text('Gross earnings', earningsX + 8, y + 11);
  doc.text(money(gross), earningsX + colW - 8, y + 11, { align: 'right' });
  const earnEndY = y + rowH;

  // Deductions column (reset y to same start)
  let y2 = y - (earnRows.length + 1) * rowH - 4;
  dedRows.forEach(([label, amt]) => {
    doc.setFont('helvetica', 'normal');
    doc.text(label, deductionsX + 8, y2 + 11);
    doc.text(money(amt), deductionsX + colW - 8, y2 + 11, { align: 'right' });
    y2 += rowH;
  });
  doc.setDrawColor(229, 229, 223);
  doc.line(deductionsX, y2, deductionsX + colW, y2);
  y2 += 4;
  doc.setFont('helvetica', 'bold');
  doc.text('Total deductions', deductionsX + 8, y2 + 11);
  doc.text(money(totalDeductions), deductionsX + colW - 8, y2 + 11, { align: 'right' });

  y = Math.max(earnEndY, y2 + rowH) + 16;

  // ---- Net pay highlight ----
  doc.setFillColor(235, 73, 58);
  doc.rect(margin, y, pageW - margin * 2, 28, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text('NET PAY', margin + 12, y + 18);
  doc.text(money(net), pageW - margin - 12, y + 18, { align: 'right' });
  y += 44;

  // ---- Bank details ----
  if (employee.bank_name || employee.account_number) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(120, 122, 114);
    doc.text('BANK DETAILS', margin, y);
    y += 12;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 62, 56);
    if (employee.bank_name) { doc.text(`Bank: ${employee.bank_name}`, margin, y); y += 11; }
    if (employee.account_holder_name) { doc.text(`Name: ${employee.account_holder_name}`, margin, y); y += 11; }
    if (employee.account_number) { doc.text(`A/c No: ${employee.account_number}`, margin, y); y += 11; }
    if (employee.ifsc) { doc.text(`IFSC: ${employee.ifsc}`, margin, y); y += 11; }
  }

  // ---- Footer ----
  const footY = doc.internal.pageSize.getHeight() - 24;
  doc.setDrawColor(229, 229, 223);
  doc.line(margin, footY - 10, pageW - margin, footY - 10);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(140, 142, 134);
  doc.text('This is a computer-generated salary slip and does not require a physical signature.', pageW / 2, footY, { align: 'center' });

  const filename = `salary-slip-${(employee.name || 'employee').replace(/\s+/g, '-')}-${period}.pdf`;
  doc.save(filename);
}

/** Generates salary slips for multiple employees and triggers individual downloads. */
export async function downloadSalarySlipsBulk(
  employees: SalarySlipEmployee[],
  period: string,
  profile: CompanyProfile,
) {
  for (const emp of employees) {
    await downloadSalarySlipPdf(emp, period, profile);
  }
}
