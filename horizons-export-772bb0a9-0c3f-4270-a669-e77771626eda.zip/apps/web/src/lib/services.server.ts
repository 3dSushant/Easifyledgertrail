import { pocketbaseAdmin } from '@/lib/pocketbase-client.server';
import type { Service, SiteSettings } from '@/lib/services';
import { defaultSettings } from '@/lib/services';

/** All published services, sorted by category then display order. */
export async function getPublishedServices(): Promise<Service[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<Service>('services', {
      filter: 'published = true',
      sort: 'category,sort',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}

/** All services (including drafts) — used by the admin CMS. */
export async function getAllServices(): Promise<Service[]> {
  try {
    const result = await pocketbaseAdmin.listRecords<Service>('services', {
      sort: 'category,sort',
      perPage: 200,
    });
    return result.items;
  } catch {
    return [];
  }
}

export async function getSettings(): Promise<SiteSettings> {
  try {
    const result = await pocketbaseAdmin.listRecords<SiteSettings>(
      'site_settings',
      { perPage: 1 },
    );
    return result.items[0] ?? defaultSettings;
  } catch {
    return defaultSettings;
  }
}
