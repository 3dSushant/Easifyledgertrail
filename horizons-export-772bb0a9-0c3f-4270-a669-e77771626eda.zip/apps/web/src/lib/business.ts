import type { RecordModel } from 'pocketbase';

export type BusinessRecord = RecordModel & {
  description?: string; counterparty?: string; date?: string; type?: string;
  category?: string; amount?: number; status?: string; reference?: string;
  name?: string; email?: string; designation?: string; department?: string;
  basic?: number; allowances?: number; deductions?: number; title?: string;
  period?: string; due_date?: string; notes?: string; gross?: number;
  net?: number; employee_count?: number; snapshot?: EmployeeSnapshot[];
};
export type EmployeeSnapshot = { name: string; designation: string; basic: number; allowances: number; deductions: number; net: number };

/** Business profile fields shown on the exported sales invoice PDF. */
export type CompanyProfile = {
  business_name?: string;
  business_address?: string;
  gstin?: string;
  pan?: string;
  bank_name?: string;
  account_number?: string;
  ifsc?: string;
  upi_id?: string;
  licenses?: string;
  email?: string;
  phone?: string;
  logo?: string;
};
export type WorkspaceData = {
  user: RecordModel; transactions: BusinessRecord[]; employees: BusinessRecord[];
  compliance: BusinessRecord[]; runs: BusinessRecord[]; today: string; error?: string;
};
export const socialImage = 'https://images.hostinger.com/772bb0a9-0c3f-4270-a669-e77771626eda/ed0632b9-a31a-4d5f-9e33-4d24757deba9.png';
export const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value);
export function dateLabel(value?: string) {
  if (!value) return '—';
  const date = new Date(`${value.slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return 'Invalid date';
  return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(date);
}
export const netPay = (e: BusinessRecord) => Math.max(0, Number(e.basic || 0) + Number(e.allowances || 0) - Number(e.deductions || 0));
export function exportCsv(filename: string, headings: string[], rows: (string | number)[][]) {
  const escape = (value: string | number) => `"${String(value).replace(/^[=+@-]/, "'").replaceAll('"', '""')}"`;
  const csv = [headings, ...rows].map(row => row.map(escape).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8;' }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.click(); URL.revokeObjectURL(url);
}
