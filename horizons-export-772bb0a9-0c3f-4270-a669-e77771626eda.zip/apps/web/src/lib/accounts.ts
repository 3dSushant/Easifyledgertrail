import type { RecordModel } from 'pocketbase';

export type LedgerGroup = 'Assets' | 'Liabilities' | 'Income' | 'Expenses' | 'Equity';
export type LedgerKind = 'account' | 'party' | 'project' | 'item';
export type OpeningNature = 'debit' | 'credit';

export type BillWiseOpening = {
  date?: string;
  reference?: string;
  amount: number;
  nature: OpeningNature;
};

export type CustomSubgroup = RecordModel & {
  group: LedgerGroup;
  name: string;
};

export type Ledger = RecordModel & {
  name: string;
  group: LedgerGroup;
  subgroup: string;
  opening_balance?: number;
  opening_balance_date?: string;
  opening_balance_nature?: OpeningNature;
  bill_wise_opening?: BillWiseOpening[];
  item_code?: string;
  project?: string;
  kind?: LedgerKind;
  address?: string;
  gstin?: string;
  pan?: string;
  bank_details?: string;
  account_number?: string;
  ifsc?: string;
  phone?: string;
  email?: string;
  hsn_code?: string;
  gst_rate?: number;
  unit?: string;
  credit_days?: number;
};

export type VoucherEntry = {
  ledger: string;
  ledgerName: string;
  ledgerGroup?: LedgerGroup;
  debit: number;
  credit: number;
  date?: string;
};

export type InvoiceItem = {
  item_ledger: string;
  itemName: string;
  item_code?: string;
  hsn?: string;
  qty?: number;
  qtyText?: string;
  rate?: number;
  discount?: number;
  gst_rate?: number;
  amount: number;
  gst_amount: number;
  post_to?: 'inventory' | 'expense';
};

export type Voucher = RecordModel & {
  date: string;
  type: string;
  reference?: string;
  counterparty?: string;
  notes?: string;
  project?: string;
  entries: VoucherEntry[];
  total?: number;
  counterparty_ledger?: string;
  project_ledger?: string;
  credit_days?: number;
  sale_type?: 'goods' | 'service';
  purchase_type?: 'goods';
  entry_kind?: 'payment' | 'receipt';
  bank_cash_ledger?: string;
  items?: InvoiceItem[];
};

/** Accounts whose balance is naturally DEBIT (asset & expense ledgers). */
export const isDebitNature = (group?: LedgerGroup) => group === 'Assets' || group === 'Expenses';

/**
 * Opening balance split into debit and credit sides.
 * Bill-wise opening takes precedence when present; otherwise the single
 * opening_balance + opening_balance_nature is used. When no nature is set
 * (legacy ledgers) the amount is placed on the group's natural side, which
 * preserves the original behaviour.
 */
export function openingSides(ledger: Ledger): { debit: number; credit: number } {
  const bills = ledger.bill_wise_opening;
  if (Array.isArray(bills) && bills.length) {
    let debit = 0;
    let credit = 0;
    for (const b of bills) {
      const amt = Number(b.amount || 0);
      if (b.nature === 'credit') credit += amt;
      else debit += amt;
    }
    return { debit, credit };
  }
  const amt = Number(ledger.opening_balance || 0);
  if (ledger.opening_balance_nature === 'credit') return { debit: 0, credit: amt };
  if (ledger.opening_balance_nature === 'debit') return { debit: amt, credit: 0 };
  return isDebitNature(ledger.group) ? { debit: amt, credit: 0 } : { debit: 0, credit: amt };
}

/** Signed opening balance (positive = debit balance, negative = credit balance). */
export function openingSigned(ledger: Ledger): number {
  const { debit, credit } = openingSides(ledger);
  return debit - credit;
}

/** Total opening balance amount shown in the ledger-creation form. */
export function openingTotal(ledger: Partial<Ledger>): number {
  const bills = ledger.bill_wise_opening;
  if (Array.isArray(bills) && bills.length) {
    return bills.reduce((s, b) => s + Number(b.amount || 0), 0);
  }
  return Number(ledger.opening_balance || 0);
}

/**
 * Running balance of a ledger across all vouchers, including its opening balance.
 * For debit-nature accounts (assets, expenses) debits increase the balance.
 * For credit-nature accounts (liabilities, income, equity) credits increase it.
 */
export function ledgerBalance(ledger: Ledger, vouchers: Voucher[]): number {
  let debit = 0;
  let credit = 0;
  for (const v of vouchers) {
    for (const e of v.entries || []) {
      if (e.ledger === ledger.id) {
        debit += Number(e.debit || 0);
        credit += Number(e.credit || 0);
      }
    }
  }
  const op = openingSides(ledger);
  debit += op.debit;
  credit += op.credit;
  return isDebitNature(ledger.group) ? debit - credit : credit - debit;
}

/** Sum of balances for every ledger in a group. */
export function groupTotal(group: LedgerGroup, ledgers: Ledger[], vouchers: Voucher[]): number {
  return ledgers
    .filter((l) => l.group === group)
    .reduce((sum, l) => sum + ledgerBalance(l, vouchers), 0);
}

/** Sum of balances for ledgers in a subgroup. */
export function subgroupTotal(subgroup: string, ledgers: Ledger[], vouchers: Voucher[]): number {
  return ledgers
    .filter((l) => l.subgroup === subgroup)
    .reduce((sum, l) => sum + ledgerBalance(l, vouchers), 0);
}

export type PnL = {
  income: number;
  expenses: number;
  profit: number;
  isProfit: boolean;
};

export function profitAndLoss(ledgers: Ledger[], vouchers: Voucher[]): PnL {
  const income = groupTotal('Income', ledgers, vouchers);
  const expenses = groupTotal('Expenses', ledgers, vouchers);
  const profit = income - expenses;
  return { income, expenses, profit, isProfit: profit >= 0 };
}

/** Outstanding vendor (supplier) payments — supplier outstanding liability balance. */
export function vendorOutstanding(ledgers: Ledger[], vouchers: Voucher[]): number {
  return subgroupTotal('Supplier Outstanding', ledgers, vouchers);
}

/** Net worth = total assets − total liabilities. */
export function netWorth(ledgers: Ledger[], vouchers: Voucher[]): number {
  const assets = groupTotal('Assets', ledgers, vouchers);
  const liabilities = groupTotal('Liabilities', ledgers, vouchers);
  return assets - liabilities;
}

export type ProjectPnL = {
  project: string;
  income: number;
  expenses: number;
  profit: number;
  outstanding: number;
};

/** Per-project / per-section P&L derived from vouchers tagged with a project. */
export function projectBreakdown(ledgers: Ledger[], vouchers: Voucher[]): ProjectPnL[] {
  const projects = Array.from(
    new Set(vouchers.map((v) => v.project).filter(Boolean)),
  ) as string[];
  return projects.map((project) => {
    const projectVouchers = vouchers.filter((v) => v.project === project);
    let income = 0;
    let expenses = 0;
    let outstanding = 0;
    for (const v of projectVouchers) {
      for (const e of v.entries || []) {
        const ledger = ledgers.find((l) => l.id === e.ledger);
        if (!ledger) continue;
        const amount = Number(e.debit || 0) - Number(e.credit || 0);
        if (ledger.group === 'Income') income += Number(e.credit || 0) - Number(e.debit || 0);
        else if (ledger.group === 'Expenses') expenses += Number(e.debit || 0) - Number(e.credit || 0);
        else if (ledger.subgroup === 'Receivables') outstanding += amount;
      }
    }
    return {
      project,
      income,
      expenses,
      profit: income - expenses,
      outstanding,
    };
  });
}

/** Vouchers that touch a given ledger (drill-down for an account). */
export function vouchersForLedger(ledgerId: string, vouchers: Voucher[]): Voucher[] {
  return vouchers
    .filter((v) => (v.entries || []).some((e) => e.ledger === ledgerId))
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}

/** Trial-balance row for a single ledger. */
export type TrialBalanceRow = {
  ledger: Ledger;
  debit: number;
  credit: number;
};

/**
 * Tally-style trial balance from posted double-entry vouchers plus opening
 * balances. Each ledger's net position is shown on its debit or credit side.
 */
export function trialBalance(ledgers: Ledger[], vouchers: Voucher[]): {
  groups: { group: LedgerGroup; label: string; rows: TrialBalanceRow[] }[];
  totalDebit: number;
  totalCredit: number;
  balanced: boolean;
} {
  const rows = ledgers.map((ledger) => {
    let debit = 0;
    let credit = 0;
    for (const v of vouchers) {
      for (const e of v.entries || []) {
        if (e.ledger === ledger.id) {
          debit += Number(e.debit || 0);
          credit += Number(e.credit || 0);
        }
      }
    }
    const op = openingSides(ledger);
    debit += op.debit;
    credit += op.credit;
    const net = debit - credit;
    return {
      ledger,
      debit: net > 0 ? net : 0,
      credit: net < 0 ? -net : 0,
    };
  });

  const order: { group: LedgerGroup; label: string }[] = [
    { group: 'Liabilities', label: 'Liabilities' },
    { group: 'Assets', label: 'Assets' },
    { group: 'Income', label: 'Sales' },
    { group: 'Expenses', label: 'Purchases & Expenses' },
    { group: 'Equity', label: 'Capital & Reserves' },
  ];

  const groups = order
    .map(({ group, label }) => ({
      group,
      label,
      rows: rows
        .filter((r) => r.ledger.group === group && (r.debit !== 0 || r.credit !== 0))
        .sort((a, b) => a.ledger.name.localeCompare(b.ledger.name)),
    }))
    .filter((g) => g.rows.length);

  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
  return { groups, totalDebit, totalCredit, balanced: Math.abs(totalDebit - totalCredit) < 0.01 };
}

/** Net movement on a ledger within a voucher (debit − credit). */
export function movementInVoucher(ledgerId: string, v: Voucher): number {
  return (v.entries || [])
    .filter((e) => e.ledger === ledgerId)
    .reduce((s, e) => s + Number(e.debit || 0) - Number(e.credit || 0), 0);
}

export const money = (value: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value || 0);

export function dateLabel(value?: string) {
  if (!value) return '—';
  const date = new Date(`${value.slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return 'Invalid date';
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date);
}

export function exportCsv(filename: string, headings: string[], rows: (string | number)[][]) {
  const escape = (value: string | number) =>
    `"${String(value).replace(/^[=+@-]/, "'").replaceAll('"', '""')}"`;
  const csv = [headings, ...rows]
    .map((row) => row.map(escape).join(','))
    .join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8;' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
