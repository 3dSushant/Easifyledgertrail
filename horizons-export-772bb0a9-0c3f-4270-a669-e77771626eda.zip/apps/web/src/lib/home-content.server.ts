import { pocketbaseAdmin } from '@/lib/pocketbase-client.server';
import { defaultHomeContent, type HomeContent } from '@/lib/home-content';

type HomeSettingsRecord = { id: string; content?: HomeContent; draft?: HomeContent };

/** Published home page content (what visitors see). Falls back to defaults. */
export async function getHomeContent(): Promise<HomeContent> {
  try {
    const result = await pocketbaseAdmin.listRecords<HomeSettingsRecord>(
      'home_settings',
      { perPage: 1 },
    );
    const rec = result.items[0];
    return rec?.content ?? defaultHomeContent;
  } catch {
    return defaultHomeContent;
  }
}

/** Draft home page content (for admin preview). Falls back to published, then defaults. */
export async function getHomeDraft(): Promise<{ content: HomeContent; draft: HomeContent; id?: string }> {
  try {
    const result = await pocketbaseAdmin.listRecords<HomeSettingsRecord>(
      'home_settings',
      { perPage: 1 },
    );
    const rec = result.items[0];
    const content = rec?.content ?? defaultHomeContent;
    const draft = rec?.draft ?? content;
    return { content, draft, id: rec?.id };
  } catch {
    return { content: defaultHomeContent, draft: defaultHomeContent };
  }
}
