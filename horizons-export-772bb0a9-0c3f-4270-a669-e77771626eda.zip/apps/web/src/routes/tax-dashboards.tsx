import type { Route } from './+types/tax-dashboards';
import { seo } from '@/lib/seo';
import { requireAuth } from '@/lib/require-auth';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { TaxDashboards } from '@/components/workspace/tax-dashboards';
import type { Ledger, Voucher } from '@/lib/accounts';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Tax Dashboards — Ledgerly', description: 'GST, TDS, PF, ESIC and PT dashboards with payable, paid and outstanding amounts.', noindex: true });
}

export async function clientLoader() {
  requireAuth();
  try {
    const [ledgers, vouchers] = await Promise.all([
      pb.collection('ledgers').getFullList<Ledger>({ sort: 'name' }),
      pb.collection('vouchers').getFullList<Voucher>({ sort: '-date,-created' }),
    ]);
    return { ledgers, vouchers };
  } catch {
    return { ledgers: [], vouchers: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading tax dashboards…</p></div>;
}

export default function TaxDashboardsRoute({ loaderData }: Route.ComponentProps) {
  return <TaxDashboards ledgers={loaderData.ledgers} vouchers={loaderData.vouchers} />;
}
