import type { Route } from './+types/admin';
import { seo } from '@/lib/seo';
import { requireAdmin } from '@/lib/require-auth';
import { AdminShell } from '@/components/admin/admin-shell';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Easify Ledger', description: 'Admin console.', noindex: true });
}

export async function clientLoader() {
  return { user: requireAdmin() };
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Opening admin console…</p></div>;
}

export default function AdminLayout({ loaderData }: Route.ComponentProps) {
  return <AdminShell user={loaderData.user} />;
}
