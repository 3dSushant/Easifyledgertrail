import type { Route } from './+types/sales';
import { seo } from '@/lib/seo';
import { Sales } from '@/components/workspace/sales';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Sales & receivables — Ledgerly',
    description: 'Track sales invoices, receivables, due dates and payment status by client and period.',
    noindex: true,
  });
}

export default function SalesPage() {
  return <Sales />;
}
