import type { Route } from './+types/admin-clients';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminClients, type ClientUser } from '@/components/admin/admin-clients';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Clients', description: 'Manage client accounts.', noindex: true });
}

export async function clientLoader() {
  try {
    const [clients, requests] = await Promise.all([
      pb.collection('users').getFullList<ClientUser>({ sort: '-created' }),
      pb.collection('access_requests').getFullList({ sort: '-created' }),
    ]);
    return { clients, requests };
  } catch {
    return { clients: [] as ClientUser[], requests: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminClientsRoute({ loaderData }: Route.ComponentProps) {
  return <AdminClients clients={loaderData.clients} requests={loaderData.requests} />;
}
