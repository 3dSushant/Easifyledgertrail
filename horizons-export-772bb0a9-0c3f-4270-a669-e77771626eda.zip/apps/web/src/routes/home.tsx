import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getHomeContent } from '@/lib/home-content.server';
import { defaultHomeContent, type HomeContent } from '@/lib/home-content';
import { Hero } from '@/components/home/hero';
import { Capabilities } from '@/components/home/capabilities';
import { HowItWorks } from '@/components/home/how-it-works';
import { Closing } from '@/components/home/closing';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Ledgerly — Your business. All accounted for.', description: 'Bring business accounting, employee payroll and GST, TDS, PF, PT and ESIC compliance together in one organised, secure client workspace.', image: socialImage, jsonLd: [{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Ledgerly', description: 'Business accounting, payroll and statutory compliance workspace.' }, { '@context': 'https://schema.org', '@type': 'Organization', name: 'Ledgerly', description: 'A secure workspace for business financial information.' }] });
}

export async function loader(): Promise<{ content: HomeContent }> {
  const content = await getHomeContent();
  return { content };
}

export default function HomePage({ loaderData }: Route.ComponentProps) {
  const content = loaderData?.content ?? defaultHomeContent;
  return <main><Hero content={content.hero} /><Capabilities content={content.capabilities} /><HowItWorks content={content.howItWorks} /><Closing content={content.closing} /></main>;
}
