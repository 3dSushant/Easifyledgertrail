import type { Route } from './+types/compliance';
import { seo } from '@/lib/seo';
import { Compliance } from '@/components/workspace/compliance';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Tax & statutory compliance — Ledgerly', description: 'Track private business GST, TDS, PF, PT and ESIC obligations, reporting periods and filing statuses.', noindex: true }); }
export default function CompliancePage() { return <Compliance />; }
