import type { Route } from './+types/contact';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getSettings } from '@/lib/services.server';
import { ContactPage } from '@/components/contact/contact-page';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Contact Us — Easify Ledger',
    description: 'Contact Easify Ledger for accounting, payroll and compliance services. WhatsApp 7620233934 or email info@EasifyLedger.com. Based in Pune, serving India.',
    image: socialImage,
    jsonLd: [{ '@context': 'https://schema.org', '@type': 'ContactPage', name: 'Contact Easify Ledger' }],
  });
}

export async function loader() {
  const settings = await getSettings();
  return { settings };
}

export default function ContactRoute({ loaderData }: Route.ComponentProps) {
  return <ContactPage settings={loaderData.settings} />;
}
