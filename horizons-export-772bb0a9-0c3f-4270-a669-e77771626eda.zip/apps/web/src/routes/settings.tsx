import type { Route } from './+types/settings';
import { seo } from '@/lib/seo';
import { Settings } from '@/components/workspace/settings';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Business settings — Ledgerly', description: 'Manage your Ledgerly business profile and account security settings.', noindex: true }); }
export default function SettingsPage() { return <Settings />; }
