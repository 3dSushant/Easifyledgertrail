import type { Route } from './+types/admin-index';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminDashboard } from '@/components/admin/admin-dashboard';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin dashboard — Easify Ledger', description: 'Admin dashboard.', noindex: true });
}

export async function clientLoader() {
  try {
    const [clients, services, messages] = await Promise.all([
      pb.collection('users').getFullList({ sort: '-created' }),
      pb.collection('services').getFullList({ sort: 'category,sort' }),
      pb.collection('contact_messages').getFullList({ sort: '-created' }),
    ]);
    return { clients, services, messages };
  } catch {
    return { clients: [], services: [], messages: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminIndex({ loaderData }: Route.ComponentProps) {
  return <AdminDashboard clients={loaderData.clients} services={loaderData.services} messages={loaderData.messages} />;
}
