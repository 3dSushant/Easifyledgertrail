import type { Route } from './+types/not-found';
import { Link } from 'react-router';
import { ArrowUpRight } from 'lucide-react';
import { seo } from '@/lib/seo';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Page not found — Ledgerly', description: 'This page is not available. Return to Ledgerly or sign in to your business workspace.', noindex: true }); }
export default function NotFound() { return <main className="not-found"><span className="eyebrow">404 / A LITTLE OFF THE BOOKS</span><h1>This page doesn’t<br />add up<span>.</span></h1><p>It may have moved, or the address might not be quite right.</p><Link to="/" className="button button-primary">Back to home <ArrowUpRight size={18} /></Link></main>; }
