import type { Route } from './+types/workspace';
import { requireAuth } from '@/lib/require-auth';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { WorkspaceShell } from '@/components/workspace/workspace-shell';
import type { BusinessRecord, WorkspaceData } from '@/lib/business';
export async function clientLoader(): Promise<WorkspaceData> {
  const user = requireAuth(); const today = new Date().toISOString().slice(0, 10);
  try {
    const [transactions, employees, compliance, runs] = await Promise.all([
      pb.collection('transactions').getFullList<BusinessRecord>({ sort: '-date,-created' }),
      pb.collection('employees').getFullList<BusinessRecord>({ sort: 'name' }),
      pb.collection('compliance_items').getFullList<BusinessRecord>({ sort: 'due_date' }),
      pb.collection('payroll_runs').getFullList<BusinessRecord>({ sort: '-period,-created' })
    ]);
    return { user, transactions, employees, compliance, runs, today };
  } catch { return { user, today, transactions: [], employees: [], compliance: [], runs: [], error: 'Your records couldn’t be loaded. Please refresh to try again.' }; }
}
clientLoader.hydrate = true as const;
export function HydrateFallback() { return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Opening your secure workspace…</p></div>; }
export default function Workspace({ loaderData }: Route.ComponentProps) { return <WorkspaceShell data={loaderData} />; }
