import type { Route } from './+types/overview';
import { seo } from '@/lib/seo';
import { Overview } from '@/components/workspace/overview';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Business overview — Ledgerly', description: 'Your private business overview with accounting, payroll and compliance summaries.', noindex: true }); }
export default function OverviewPage() { return <Overview />; }
