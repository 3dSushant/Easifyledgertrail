import type { Route } from './+types/admin-content';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminContent } from '@/components/admin/admin-content';
import { defaultSettings, type SiteSettings } from '@/lib/services';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Site Content', description: 'Edit website content.', noindex: true });
}

export async function clientLoader() {
  try {
    const result = await pb.collection('site_settings').getFullList<SiteSettings>({ perPage: 1 });
    return { settings: result[0] ?? defaultSettings };
  } catch {
    return { settings: defaultSettings };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminContentRoute({ loaderData }: Route.ComponentProps) {
  return <AdminContent settings={loaderData.settings} />;
}
