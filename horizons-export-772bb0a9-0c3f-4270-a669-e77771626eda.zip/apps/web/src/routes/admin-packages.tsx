import type { Route } from './+types/admin-packages';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminPackages } from '@/components/admin/admin-packages';
import type { Package, QuoteRequest } from '@/lib/content';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Packages', description: 'Manage packages and quote requests.', noindex: true });
}

export async function clientLoader() {
  try {
    const [packages, quotes] = await Promise.all([
      pb.collection('packages').getFullList<Package>({ sort: 'category,sort' }),
      pb.collection('quote_requests').getFullList<QuoteRequest>({ sort: '-created' }),
    ]);
    return { packages, quotes };
  } catch {
    return { packages: [], quotes: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminPackagesRoute({ loaderData }: Route.ComponentProps) {
  return <AdminPackages packages={loaderData.packages} quotes={loaderData.quotes} />;
}
