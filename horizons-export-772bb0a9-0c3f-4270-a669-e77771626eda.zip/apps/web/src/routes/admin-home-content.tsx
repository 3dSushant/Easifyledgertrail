import type { Route } from './+types/admin-home-content';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminHomeContent } from '@/components/admin/admin-home-content';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Home Page Content', description: 'Edit the home page content.', noindex: true });
}

export async function clientLoader() {
  try {
    const result = await pb.collection('home_settings').getFullList({ perPage: 1 });
    return { settings: result[0] ?? null };
  } catch {
    return { settings: null };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminHomeContentRoute({ loaderData }: Route.ComponentProps) {
  return <AdminHomeContent settings={loaderData.settings} />;
}
