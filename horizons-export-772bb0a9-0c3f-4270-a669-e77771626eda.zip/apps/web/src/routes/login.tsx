import type { Route } from './+types/login';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { LoginPanel } from '@/components/auth/login-panel';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Client login — Ledgerly', description: 'Sign in to your private Ledgerly business workspace to manage accounting records, employee payroll and statutory compliance.', image: socialImage }); }
export default function LoginPage() { return <LoginPanel />; }
