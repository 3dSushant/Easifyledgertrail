import type { Route } from './+types/jobs';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { JobsPage } from '@/components/jobs/jobs-page';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Jobs — Easify Ledger',
    description: 'Easify Ledger recruits talented candidates for businesses across India. Apply for roles in accounting, finance, operations, HR, sales and more.',
    image: socialImage,
    jsonLd: [{ '@context': 'https://schema.org', '@type': 'JobPosting', title: 'Open positions at Easify Ledger', description: 'We recruit talented candidates for clients across India across multiple categories.', employmentType: 'FULL_TIME', hiringOrganization: { '@type': 'Organization', name: 'Easify Ledger' }, jobLocation: { '@type': 'Place', address: { '@type': 'PostalAddress', addressCountry: 'IN' } } }],
  });
}

export default function JobsRoute() {
  return <JobsPage />;
}
