import type { Route } from './+types/news.$slug';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getPublishedArticles, getArticleComments } from '@/lib/content.server';
import { articleImageUrl } from '@/lib/content';
import { ArticleDetail } from '@/components/news/article-detail';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { sessionId } from '@/lib/content';
import type { ArticleComment, NewsArticle } from '@/lib/content';

export function meta({ matches, location, loaderData }: Route.MetaArgs) {
  const article = loaderData?.article;
  return seo({ matches, location }, {
    title: article ? `${article.headline} — Easify Ledger` : 'Article — Easify Ledger',
    description: article?.summary || 'News & finance updates from Easify Ledger.',
    image: (article && articleImageUrl(article)) || socialImage,
    type: 'article',
    jsonLd: article ? [
      {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: article.headline,
        description: article.summary,
        image: articleImageUrl(article),
        datePublished: article.published_at || article.created,
        author: { '@type': 'Person', name: article.author || 'Easify Ledger' },
        articleSection: article.category,
      },
      {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: '/' },
          { '@type': 'ListItem', position: 2, name: 'News', item: '/news' },
          { '@type': 'ListItem', position: 3, name: article.headline },
        ],
      },
    ] : [],
  });
}

export async function loader({ params }: Route.LoaderArgs) {
  const articles = await getPublishedArticles();
  const article = articles.find((a) => a.slug === params.slug);
  if (!article) throw new Response('Article not found', { status: 404 });
  const comments = await getArticleComments(article.id);
  return { article, comments };
}

export async function clientLoader({ serverLoader }: Route.ClientLoaderArgs) {
  const { article, comments } = (await serverLoader()) as { article: NewsArticle; comments: ArticleComment[] };
  let reaction: 'like' | 'dislike' | null = null;
  let likes = 0;
  let dislikes = 0;
  try {
    const all = await pb.collection('article_reactions').getFullList<{ type: string; session_id: string }>({
      filter: pb.filter('article = {:articleId}', { articleId: article.id }),
    });
    likes = all.filter((r) => r.type === 'like').length;
    dislikes = all.filter((r) => r.type === 'dislike').length;
    const sid = sessionId();
    const mine = all.find((r) => r.session_id === sid);
    if (mine) reaction = mine.type as 'like' | 'dislike';
  } catch { reaction = null; }
  return { article, comments, reaction, likes, dislikes };
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading article…</p></div>;
}

export default function ArticleRoute({ loaderData }: Route.ComponentProps) {
  const data = loaderData as { article: NewsArticle; comments: ArticleComment[]; reaction: 'like' | 'dislike' | null; likes: number; dislikes: number };
  return <ArticleDetail article={data.article} comments={data.comments} reaction={data.reaction} likes={data.likes} dislikes={data.dislikes} />;
}
