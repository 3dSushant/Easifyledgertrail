import type { Route } from './+types/admin-messages';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminMessages } from '@/components/admin/admin-messages';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Messages', description: 'Contact submissions.', noindex: true });
}

export async function clientLoader() {
  try {
    const messages = await pb.collection('contact_messages').getFullList({ sort: '-created' });
    return { messages };
  } catch {
    return { messages: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminMessagesRoute({ loaderData }: Route.ComponentProps) {
  return <AdminMessages messages={loaderData.messages} />;
}
