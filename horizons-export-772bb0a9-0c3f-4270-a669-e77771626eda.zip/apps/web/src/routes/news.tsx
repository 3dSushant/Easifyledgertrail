import type { Route } from './+types/news';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getPublishedArticles } from '@/lib/content.server';
import { NewsListing } from '@/components/news/news-listing';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'News & Finance Updates — Easify Ledger',
    description: 'The latest finance, GST, tax compliance, accounting and business news curated by the Easify Ledger team.',
    image: socialImage,
    jsonLd: [{ '@context': 'https://schema.org', '@type': 'CollectionPage', name: 'News & Finance Updates', description: 'Finance, GST, tax compliance and business news from Easify Ledger.' }],
  });
}

export async function loader({ url }: Route.LoaderArgs) {
  const articles = await getPublishedArticles();
  const category = url.searchParams.get('category') || undefined;
  return { articles, category };
}

export default function NewsRoute({ loaderData }: Route.ComponentProps) {
  return <NewsListing articles={loaderData.articles} activeCategory={loaderData.category} />;
}
