import type { Route } from './+types/packages';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getPublishedPackages } from '@/lib/content.server';
import { getSettings } from '@/lib/services.server';
import { PackagesPage } from '@/components/packages/packages-page';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Packages — Easify Ledger',
    description: 'Tax and statutory compliance, computerized digital accounting, and complete payroll & staff management packages for businesses across India. Get a quote today.',
    image: socialImage,
    jsonLd: [{ '@context': 'https://schema.org', '@type': 'Service', name: 'Easify Ledger Packages', serviceType: 'Tax Compliance, Accounting, Payroll & Staff Management', areaServed: 'IN' }],
  });
}

export async function loader() {
  const [packages, settings] = await Promise.all([getPublishedPackages(), getSettings()]);
  return { packages, settings };
}

export default function PackagesRoute({ loaderData }: Route.ComponentProps) {
  return <PackagesPage packages={loaderData.packages} settings={loaderData.settings} />;
}
