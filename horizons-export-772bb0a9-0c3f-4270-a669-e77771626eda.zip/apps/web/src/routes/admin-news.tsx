import type { Route } from './+types/admin-news';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminNews } from '@/components/admin/admin-news';
import type { NewsArticle } from '@/lib/content';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — News & Finance Updates', description: 'Manage news articles.', noindex: true });
}

export async function clientLoader() {
  try {
    const articles = await pb.collection('news_articles').getFullList<NewsArticle>({ sort: '-created' });
    return { articles };
  } catch {
    return { articles: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminNewsRoute({ loaderData }: Route.ComponentProps) {
  return <AdminNews articles={loaderData.articles} />;
}
