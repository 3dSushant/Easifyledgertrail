import type { Route } from './+types/payroll';
import { seo } from '@/lib/seo';
import { Payroll } from '@/components/workspace/payroll';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Payroll workspace — Ledgerly', description: 'Manage your business employee directory, monthly salaries, deductions and payroll runs.', noindex: true }); }
export default function PayrollPage() { return <Payroll />; }
