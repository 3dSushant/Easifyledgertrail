import type { Route } from './+types/hire-talent';
import { seo } from '@/lib/seo';
import { HireTalent } from '@/components/workspace/hire-talent';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Hire Talent — Ledgerly',
    description: 'Post job descriptions, review candidates and track interviews.',
    noindex: true,
  });
}

export default function HireTalentPage() {
  return <HireTalent />;
}
