import type { Route } from './+types/attendance';
import { seo } from '@/lib/seo';
import { Attendance } from '@/components/workspace/attendance';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Attendance — Ledgerly', description: 'Upload and process employee attendance with office-time rules.', noindex: true });
}

export default function AttendanceRoute() {
  return <Attendance />;
}
