import type { Route } from './+types/admin-jobs';
import { seo } from '@/lib/seo';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { AdminJobs } from '@/components/admin/admin-jobs';
import type { JobApplication } from '@/lib/content';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Job Applications', description: 'Manage job applications.', noindex: true });
}

export async function clientLoader() {
  try {
    const applications = await pb.collection('job_applications').getFullList<JobApplication>({ sort: '-created' });
    return { applications };
  } catch {
    return { applications: [] };
  }
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
  return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;
}

export default function AdminJobsRoute({ loaderData }: Route.ComponentProps) {
  return <AdminJobs applications={loaderData.applications} />;
}
