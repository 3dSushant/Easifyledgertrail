import type { Route } from './+types/admin-hire';
import { seo } from '@/lib/seo';
import { AdminHire } from '@/components/admin/admin-hire';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, { title: 'Admin — Hire Talent', description: 'Assign candidates to client job descriptions.', noindex: true });
}

export default function AdminHireRoute() {
  return <AdminHire />;
}
