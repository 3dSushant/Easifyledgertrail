import type { Route } from './+types/about';
import { seo } from '@/lib/seo';
import { socialImage } from '@/lib/business';
import { getSettings } from '@/lib/services.server';
import { AboutPage } from '@/components/about/about-page';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'About Us — Easify Ledger',
    description: 'Easify Ledger is a Pune-based business services practice helping businesses across India manage accounting, payroll and statutory compliance.',
    image: socialImage,
  });
}

export async function loader() {
  const settings = await getSettings();
  return { settings };
}

export default function AboutRoute({ loaderData }: Route.ComponentProps) {
  return <AboutPage settings={loaderData.settings} />;
}
