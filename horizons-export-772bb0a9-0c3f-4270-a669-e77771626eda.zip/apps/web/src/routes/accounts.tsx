import type { Route } from './+types/accounts';
import { seo } from '@/lib/seo';
import { AccountsTabs } from '@/components/workspace/accounts/accounts-tabs';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Accounts — Ledgerly',
    description: 'Double-entry accounts: profit & loss, balance sheet, record transactions and reports.',
    noindex: true,
  });
}

export default function AccountsPage() {
  return <AccountsTabs />;
}
