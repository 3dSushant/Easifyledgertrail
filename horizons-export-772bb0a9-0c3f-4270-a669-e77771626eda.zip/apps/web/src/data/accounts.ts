export type LedgerGroup = 'Assets' | 'Liabilities' | 'Income' | 'Expenses' | 'Equity';

/** Which subgroups belong to each ledger group (drives the ledger creator). */
export const SUBGROUPS: Record<LedgerGroup, string[]> = {
  Assets: [
    'Fixed Assets',
    'Investments',
    'Inventory',
    'Bank & Cash',
    'Receivables',
    'Advances Given',
    'Other Current Assets',
  ],
  Liabilities: [
    'Capital Introduced',
    'Loans',
    'Supplier Outstanding',
    'Other Current Liabilities',
  ],
  Income: ['Sales', 'Other Income'],
  Expenses: ['Direct Expenses', 'Indirect Expenses'],
  Equity: ['Capital Introduced'],
};

/** Balance-sheet asset subgroups, in display order. */
export const ASSET_SUBGROUPS = [
  'Fixed Assets',
  'Investments',
  'Inventory',
  'Bank & Cash',
  'Receivables',
  'Advances Given',
  'Other Current Assets',
];

/** Balance-sheet liability subgroups, in display order. */
export const LIABILITY_SUBGROUPS = [
  'Capital Introduced',
  'Loans',
  'Supplier Outstanding',
  'Other Current Liabilities',
];

export const LEDGER_GROUPS: LedgerGroup[] = [
  'Assets',
  'Liabilities',
  'Income',
  'Expenses',
  'Equity',
];

/** Master-record kinds a ledger can represent (regular accounts stay 'account'). */
export const LEDGER_KINDS = ['account', 'party', 'project', 'item'] as const;

/** Auto-assigned group/subgroup when creating a master ledger of a given kind. */
export const KIND_DEFAULTS: Record<string, { group: LedgerGroup; subgroup: string }> = {
  party: { group: 'Assets', subgroup: 'Receivables' },
  project: { group: 'Equity', subgroup: 'Capital Introduced' },
  item: { group: 'Income', subgroup: 'Sales' },
};

export const VOUCHER_TYPES = [
  'Sales',
  'Purchase',
  'Expense',
  'Bank',
  'Cash',
  'Journal',
  'Transfer',
] as const;

/** Default ledger suggestions to seed a fresh chart of accounts. */
export const DEFAULT_LEDGERS: { name: string; group: LedgerGroup; subgroup: string }[] = [
  { name: 'Cash in Hand', group: 'Assets', subgroup: 'Bank & Cash' },
  { name: 'Bank Account', group: 'Assets', subgroup: 'Bank & Cash' },
  { name: 'Sales Account', group: 'Income', subgroup: 'Sales' },
  { name: 'Purchase Account', group: 'Expenses', subgroup: 'Direct Expenses' },
  { name: 'Rent Expense', group: 'Expenses', subgroup: 'Indirect Expenses' },
  { name: 'Salary Expense', group: 'Expenses', subgroup: 'Direct Expenses' },
  { name: 'Sundry Debtors', group: 'Assets', subgroup: 'Receivables' },
  { name: 'Sundry Creditors', group: 'Liabilities', subgroup: 'Supplier Outstanding' },
  { name: 'Capital Account', group: 'Equity', subgroup: 'Capital Introduced' },
  { name: 'Output GST', group: 'Liabilities', subgroup: 'Other Current Liabilities' },
];

export const REPORTS = [
  { id: 'advances', title: 'Advances Paid to Supplier', description: 'Money paid in advance to suppliers, recoverable against future bills.' },
  { id: 'creditors', title: 'Creditors List', description: 'All suppliers you owe money to, with outstanding balances.' },
  { id: 'emi', title: 'Upcoming EMI & Monthly Payments', description: 'Recurring loan EMIs and monthly obligations coming due.' },
  { id: 'compliance', title: 'Tax Compliance Report', description: 'Statutory filings completed and pending, with due dates.' },
  { id: 'cashflow', title: 'Cash Flow Statement', description: 'Movement of cash in and out of the business by period.' },
  { id: 'ledger', title: 'Ledger Statement', description: 'Complete ledger details — every debit and credit on one account.' },
  { id: 'pnl', title: 'Profit & Loss Statement', description: 'Income versus expenses for any selected period.' },
  { id: 'balancesheet', title: 'Balance Sheet', description: 'Assets, liabilities and net worth on a given date.' },
];
