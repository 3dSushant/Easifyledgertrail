export type FieldConfig = { name: string; label: string; type?: string; required?: boolean; options?: string[]; min?: number; max?: number; wide?: boolean; accept?: string; multiple?: boolean; placeholder?: string };
export const transactionFields: FieldConfig[] = [
  { name: 'description', label: 'Description', required: true, wide: true, max: 300 },
  { name: 'type', label: 'Transaction type', options: ['Income', 'Expense'], required: true },
  { name: 'amount', label: 'Amount (₹)', type: 'number', min: 0.01, required: true },
  { name: 'date', label: 'Transaction date', type: 'date', required: true },
  { name: 'status', label: 'Payment status', options: ['Paid', 'Pending'], required: true },
  { name: 'category', label: 'Category', options: ['Sales', 'Services', 'Salary', 'Rent', 'Utilities', 'Travel', 'Supplies', 'Other'], required: true },
  { name: 'counterparty', label: 'Customer / supplier', max: 200 },
  { name: 'reference', label: 'Invoice / reference number', max: 100, wide: true }
];
export const employeeFields: FieldConfig[] = [
  { name: 'name', label: 'Employee name', required: true, max: 200 },
  { name: 'employee_code', label: 'Employee ID / code', max: 50, placeholder: 'EMP-001' },
  { name: 'email', label: 'Employee email', type: 'email' },
  { name: 'designation', label: 'Designation', max: 200 },
  { name: 'department', label: 'Department', max: 100 },
  { name: 'joining_date', label: 'Joining date', type: 'date' },
  { name: 'status', label: 'Employment status', options: ['Active', 'Inactive'], required: true },
  { name: 'basic', label: 'Monthly basic salary (₹)', type: 'number', min: 0, required: true },
  { name: 'allowances', label: 'Monthly allowances (₹)', type: 'number', min: 0 },
  { name: 'deductions', label: 'Monthly deductions (₹)', type: 'number', min: 0 },
  { name: 'paid_leave_entitlement', label: 'Paid leave entitlement (days/yr)', type: 'number', min: 0 },
  { name: 'sick_leave_entitlement', label: 'Sick leave entitlement (days/yr)', type: 'number', min: 0 },
  { name: 'office_start_time', label: 'Office start time', placeholder: '10:00' },
  { name: 'office_end_time', label: 'Office end time', placeholder: '19:00' },
  { name: 'grace_period', label: 'Grace period (minutes)', type: 'number', min: 0 },
  { name: 'weekly_off', label: 'Weekly off', options: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] },
  { name: 'late_marks_per_halfday', label: 'Late marks per half-day', type: 'number', min: 0, placeholder: '2' },
  { name: 'late_mark_rule', label: 'Late-mark rule', wide: true, max: 500, placeholder: 'e.g. 2 late marks = 1 half-day deduction' },
  { name: 'early_leaving_rule', label: 'Early-leaving rule', wide: true, max: 500 },
  { name: 'half_day_rule', label: 'Half-day rule', wide: true, max: 500 },
  { name: 'bank_name', label: 'Bank name', max: 200 },
  { name: 'account_holder_name', label: 'Account holder name', max: 200 },
  { name: 'account_number', label: 'Bank account number', max: 40 },
  { name: 'ifsc', label: 'IFSC code', max: 11 },
  { name: 'pan', label: 'PAN', max: 10, placeholder: 'ABCDE1234F' },
  { name: 'aadhaar', label: 'Aadhaar number', max: 12, placeholder: '12-digit Aadhaar' },
  { name: 'documents', label: 'Documents (KYC, slips, letters)', type: 'file', multiple: true, accept: '.pdf,.doc,.docx,image/*', wide: true }
];
export const complianceFields: FieldConfig[] = [
  { name: 'title', label: 'Filing / obligation name', required: true, wide: true, max: 300 },
  { name: 'type', label: 'Compliance category', options: ['GST', 'TDS', 'PF', 'PT', 'ESIC'], required: true },
  { name: 'period', label: 'Reporting period', required: true, max: 100 },
  { name: 'due_date', label: 'Due date', type: 'date', required: true },
  { name: 'amount', label: 'Amount payable (₹)', type: 'number', min: 0 },
  { name: 'status', label: 'Filing status', options: ['Pending', 'In progress', 'Filed'], required: true },
  { name: 'reference', label: 'Acknowledgement / reference number', max: 200 },
  { name: 'notes', label: 'Notes', type: 'textarea', max: 2000, wide: true }
];
export const complianceTypes = [
  { name: 'GST', full: 'Goods & Services Tax', description: 'Organise your GST return periods, liabilities, due dates and filing acknowledgements.' },
  { name: 'TDS', full: 'Tax Deducted at Source', description: 'Track TDS payments and returns with reporting periods and reference numbers.' },
  { name: 'PF', full: 'Provident Fund', description: 'Keep employee provident fund contributions and filing obligations in view.' },
  { name: 'PT', full: 'Professional Tax', description: 'Manage professional tax obligations and the due dates applicable to your business.' },
  { name: 'ESIC', full: 'Employees’ State Insurance', description: 'Track employee insurance contributions, payment deadlines and filing records.' }
];
export const capabilities = [
  { number: '01', title: 'Accounting,\nmade simple.', description: 'Manage all your business finances in one place. Track sales, expenses, profits, payments, stock and assets with easy-to-understand reports. Our online accounting software can also be customised to suit your business needs.', items: ['Income & expense tracking', 'Manage stock, asset & payment', 'Clear financial summaries'], link: '/services/accounting-services', label: 'Explore accounting' },
  { number: '02', title: 'Your people.\nOur Support.', description: 'Make employee management and salary processing easier. We handle salary calculations, payslips, employee records, background checks, hiring support and payroll work at an affordable cost.', items: ['Salary Calculation and Pay Slip', 'Employee records Management', 'Hiring Support and Payroll Management'], link: '/services/payroll-services', label: 'Explore payroll' },
  { number: '03', title: 'Tax & compliance\nmade easy.', description: 'Take the stress out of taxes and government paperwork. We help manage GST, TDS, PF, ESIC, Professional Tax, tax return filing and business registrations, so you can focus on running your business.', items: ['GST, TDS, PF, PT & ESIC', 'Filing status & due-date tracking', 'Acknowledgements & references'], link: '/services/tax-compliance', label: 'Explore compliance' }
];
