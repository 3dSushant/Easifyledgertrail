import { Link, useLocation } from 'react-router';
import { ArrowUpRight, MessageCircle, Mail, MapPin, ShieldCheck } from 'lucide-react';
import { Brand } from '@/components/brand';
import { whatsappLink, defaultSettings, type SiteSettings } from '@/lib/services';

export function SiteFooter({ settings }: { settings?: SiteSettings }) {
  const location = useLocation();
  if (location.pathname.startsWith('/app') || location.pathname.startsWith('/admin')) return null;

  const s = settings ?? defaultSettings;
  const wa = whatsappLink(s.whatsapp || defaultSettings.whatsapp, "Hi Easify Ledger, I'd like to know more about your services.");

  return (
    <footer className="site-footer">
      <div className="footer-cta">
        <div className="footer-cta-text">
          <h2>Ready to get started?</h2>
          <p>Sign up for a client workspace or reach out — we work with businesses across India.</p>
        </div>
        <div className="footer-cta-actions">
          <Link to="/login?mode=request" className="button button-primary">Sign up <ArrowUpRight size={17} /></Link>
          <Link to="/contact" className="button button-dark">Contact us <ArrowUpRight size={17} /></Link>
          <a href={wa} className="button button-quiet" target="_blank" rel="noreferrer"><MessageCircle size={17} /> WhatsApp</a>
        </div>
      </div>
      <div className="footer-top">
        <Brand />
        <p>Your business. All accounted for.</p>
        <Link to="/login">Let’s get to work <ArrowUpRight size={18} /></Link>
      </div>
      <div className="footer-contact">
        <span><MessageCircle size={14} /> WhatsApp / Call: <a href={wa} target="_blank" rel="noreferrer">{s.whatsapp || defaultSettings.whatsapp}</a></span>
        <span><Mail size={14} /> <a href={`mailto:${s.email || defaultSettings.email}`}>{s.email || defaultSettings.email}</a></span>
        <span><MapPin size={14} /> {s.location || defaultSettings.location}</span>
      </div>
      <div className="footer-bottom">
        <span>© 2026 Easify Ledger. All rights reserved.</span>
        <div>
          <Link to="/about">About Us</Link>
          <Link to="/packages">Packages</Link>
          <Link to="/jobs">Jobs</Link>
          <Link to="/news">News &amp; Updates</Link>
          <Link to="/contact">Contact Us</Link>
          <Link to="/login">Client access</Link>
        </div>
        <span><ShieldCheck size={12} /> Built for better business.</span>
      </div>
    </footer>
  );
}
