import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowUpRight, MessageCircle, Mail, MapPin, CheckCircle2, Phone } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { SiteSettings } from '@/lib/services';
import { whatsappLink, defaultSettings } from '@/lib/services';

export function ContactPage({ settings }: { settings: SiteSettings }) {
  const s = settings ?? defaultSettings;
  const wa = whatsappLink(s.whatsapp, "Hi Easify Ledger, I'd like to know more about your services.");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    try {
      await pb.collection('contact_messages').create({
        name: String(form.get('name') || '').trim(),
        email: String(form.get('email') || '').trim(),
        phone: String(form.get('phone') || '').trim(),
        subject: String(form.get('subject') || '').trim(),
        message: String(form.get('message') || '').trim(),
      });
      setDone(true);
    } catch {
      setError('Your message could not be sent. Please try again or reach us on WhatsApp.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="services-page">
      <section className="services-hero">
        <span className="eyebrow"><i className="red-square" /> GET IN TOUCH</span>
        <h1>Contact us<span>.</span></h1>
        <p>Questions about accounting, payroll or compliance? We’re based in Pune and work with businesses all over India. Reach us any way you like.</p>
      </section>
      <section className="contact-grid">
        <div className="contact-info">
          <a className="contact-info-row" href={wa} target="_blank" rel="noreferrer"><MessageCircle size={22} /><div><strong>WhatsApp / Call</strong><span>{s.whatsapp}</span></div></a>
          <a className="contact-info-row" href={`mailto:${s.email}`}><Mail size={22} /><div><strong>Email</strong><span>{s.email}</span></div></a>
          <div className="contact-info-row"><MapPin size={22} /><div><strong>Location</strong><span>{s.location}</span></div></div>
          <div className="contact-info-row"><Phone size={22} /><div><strong>Phone</strong><span>{s.phone}</span></div></div>
          <Link to="/login?mode=request" className="button button-primary">Sign up for a workspace <ArrowUpRight size={17} /></Link>
        </div>
        <div className="contact-form-panel">
          {done ? (
            <div className="success-panel" role="status">
              <CheckCircle2 size={28} />
              <h3>Message sent.</h3>
              <p>Thank you for reaching out. We’ll get back to you shortly.</p>
              <button className="button button-dark" onClick={() => setDone(false)}>Send another <ArrowUpRight size={16} /></button>
            </div>
          ) : (
            <form onSubmit={submit} className="contact-form">
              <h2>Send us a message</h2>
              <div className="record-fields">
                <label>Your name<input name="name" required maxLength={200} placeholder="Full name" /></label>
                <label>Email<input name="email" type="email" required placeholder="you@business.com" /></label>
                <label>Phone (optional)<input name="phone" maxLength={30} placeholder="Phone number" /></label>
                <label>Subject<input name="subject" maxLength={200} placeholder="How can we help?" /></label>
                <label className="field-wide">Message<textarea name="message" required maxLength={4000} rows={5} placeholder="Tell us about your business and what you need…" /></label>
              </div>
              {error && <p className="form-error" role="alert">{error}</p>}
              <div className="dialog-actions">
                <button className="button button-primary" disabled={busy}>{busy ? 'Sending…' : 'Send message'}<ArrowUpRight size={17} /></button>
              </div>
            </form>
          )}
        </div>
      </section>
    </main>
  );
}
