import { Link } from 'react-router';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { defaultHomeContent } from '@/lib/home-content';

type HowItWorksContent = typeof defaultHomeContent.howItWorks;

export function HowItWorks({ content }: { content?: HowItWorksContent }) {
  const c = content ?? defaultHomeContent.howItWorks;
  return <section className="how-it-works" id="how-it-works"><div><span className="eyebrow">{c.eyebrow}</span><h2>{c.heading.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}</h2><p>{c.description}</p><Link className="button button-dark" to={c.ctaLink}>{c.ctaText} <ArrowUpRight size={18} /></Link></div><ol className="steps">{c.steps.map((step, i) => <li key={i}><span>{String(i + 1).padStart(2, '0')}</span><div><h3>{step.title}</h3><p>{step.description}</p></div><ArrowRight size={18} /></li>)}</ol></section>;
}
