import { Link } from 'react-router';
import { ArrowUpRight } from 'lucide-react';
import { defaultHomeContent } from '@/lib/home-content';

type ClosingContent = typeof defaultHomeContent.closing;

export function Closing({ content }: { content?: ClosingContent }) {
  const c = content ?? defaultHomeContent.closing;
  return <section className="closing"><span className="eyebrow">{c.eyebrow}</span><div><h2>{c.heading.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}</h2><Link to="/login" className="closing-arrow" aria-label="Sign in to your business workspace"><ArrowUpRight size={64} strokeWidth={1.3} /></Link></div><p>{c.description}</p></section>;
}
