import { Link } from 'react-router';
import { ArrowUpRight, ShieldCheck, ArrowDown } from 'lucide-react';
import { ProductPreview } from '@/components/home/product-preview';
import { defaultHomeContent } from '@/lib/home-content';

type HeroContent = typeof defaultHomeContent.hero;

export function Hero({ content }: { content?: HeroContent }) {
  const c = content ?? defaultHomeContent.hero;
  return <section className="hero"><div className="hero-topline"><span className="eyebrow"><i className="red-square" /> {c.eyebrow}</span><span className="hero-edition">ACCOUNTING / PAYROLL / COMPLIANCE</span></div><div className="hero-heading"><h1>{c.heading}<span>.</span></h1><span className="hero-asterisk" aria-hidden="true">✳</span></div><div className="hero-description-row"><p>{c.description}</p><div className="hero-actions"><Link to={c.ctaLink} className="button button-primary">{c.ctaText} <ArrowUpRight size={19} /></Link><a href="#accounting" className="text-link">{c.linkText} <ArrowDown size={16} /></a></div></div><div className="hero-product"><div className="product-side-note"><span>BUILT AROUND YOUR BUSINESS</span><div className="side-note-line" /></div><ProductPreview /><div className="floating-note"><ShieldCheck size={21} /><div>Your business data.<br /><strong>Your eyes only.</strong></div></div></div><div className="hero-footnote"><span><ShieldCheck size={15} /> Private client workspaces</span><span>One clear view. Every moving part.</span><a href="#accounting">A better way to manage business <ArrowDown size={14} /></a></div></section>;
}
