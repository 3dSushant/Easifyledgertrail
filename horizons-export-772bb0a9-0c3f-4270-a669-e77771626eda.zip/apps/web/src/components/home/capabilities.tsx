import { Link } from 'react-router';
import { ArrowUpRight, Check, Wallet, Users, ShieldCheck } from 'lucide-react';
import { defaultHomeContent } from '@/lib/home-content';

type CapabilitiesContent = typeof defaultHomeContent.capabilities;

export function Capabilities({ content }: { content?: CapabilitiesContent }) {
  const c = content ?? defaultHomeContent.capabilities;
  const icons = [Wallet, Users, ShieldCheck];
  return <section className="capabilities"><div className="section-title"><span className="eyebrow">{c.eyebrow}</span><h2>{c.title.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}</h2><p>{c.description.split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}</p></div><div className="capability-grid">{c.items.map((item, i) => { const Icon = icons[i] ?? Wallet; return <article className="capability" id={['accounting', 'payroll', 'compliance'][i]} key={item.number}><div className="capability-top"><Icon size={28} strokeWidth={1.5} /><span>{item.number} /</span></div><h3>{item.title.split('\n').map((line, index) => <span key={index}>{line}<br /></span>)}</h3><p>{item.description}</p><ul>{item.items.map(text => <li key={text}><Check size={15} />{text}</li>)}</ul><Link to={item.link}>{item.label}<ArrowUpRight size={18} /></Link></article>; })}</div><div className="statutory-strip"><span>EVERY OBLIGATION.<br /><strong>NOTHING OVERLOOKED.</strong></span><div>{['GST', 'TDS', 'PF', 'PT', 'ESIC'].map(tax => <a href="#compliance" key={tax}>{tax}<ArrowUpRight size={13} /></a>)}</div></div></section>;
}
