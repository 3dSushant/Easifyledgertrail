import { useState } from 'react';
import { ArrowUpRight, Briefcase, CheckCircle2, Plus, Trash2, Upload, MapPin } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { jobCategories, type ExperienceRecord } from '@/lib/content';

const blankExperience: ExperienceRecord = {
  company: '',
  startDate: '',
  endDate: '',
  position: '',
  responsibilities: '',
};

const MAX_RESUME = 5 * 1024 * 1024;
const ALLOWED = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

export function JobsPage() {
  const [showForm, setShowForm] = useState(false);

  return (
    <main className="services-page">
      <section className="services-hero">
        <span className="eyebrow"><i className="red-square" /> CAREERS</span>
        <h1>We recruit talent for<br />businesses across India<span>.</span></h1>
        <p>Easify Ledger connects skilled candidates with growing businesses. Whether you’re a fresher starting out or an experienced professional seeking your next role, we have opportunities across accounting, finance, operations, HR, sales and more.</p>
      </section>

      <section className="category-list">
        <div className="category-card">
          <div className="category-card-head">
            <div>
              <h2>Open positions</h2>
              <span className="category-card-sub">Apply for the role that fits you</span>
            </div>
          </div>
          <p>We recruit talented candidates for our clients across India. Explore the categories below and apply with your resume — our team reviews every application and reaches out to shortlisted candidates.</p>
          <div className="category-card-items">
            {jobCategories.map((cat) => (
              <span className="category-item" key={cat}>
                <span>{cat}</span>
                <Briefcase size={14} />
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="service-cta">
        <div>
          <span className="eyebrow"><i className="red-square" /> APPLY NOW</span>
          <h2>Ready to join us<span>?</span></h2>
          <p>Fill out the application form and upload your resume. We’ll get in touch if your profile matches an open position.</p>
        </div>
        <div className="service-cta-actions">
          <button className="button button-primary" onClick={() => setShowForm(true)}><ArrowUpRight size={17} /> Apply now</button>
        </div>
      </section>

      {showForm && <JobApplicationForm onClose={() => setShowForm(false)} />}
    </main>
  );
}

function JobApplicationForm({ onClose }: { onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');
  const [candidateType, setCandidateType] = useState<'Fresher' | 'Experienced'>('Fresher');
  const [experiences, setExperiences] = useState<ExperienceRecord[]>([blankExperience]);
  const [resumeName, setResumeName] = useState('');

  function addExperience() {
    setExperiences((prev) => [...prev, { ...blankExperience }]);
  }
  function removeExperience(idx: number) {
    setExperiences((prev) => prev.filter((_, i) => i !== idx));
  }
  function updateExperience(idx: number, field: keyof ExperienceRecord, value: string) {
    setExperiences((prev) => prev.map((e, i) => (i === idx ? { ...e, [field]: value } : e)));
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');

    const form = new FormData(event.currentTarget);
    const file = form.get('resume') as File;

    if (!file || file.size === 0) {
      setError('Please upload your resume (PDF or Word, up to 5 MB).');
      setBusy(false);
      return;
    }
    if (!ALLOWED.includes(file.type)) {
      setError('Resume must be a PDF or Word document.');
      setBusy(false);
      return;
    }
    if (file.size > MAX_RESUME) {
      setError('Resume file is too large. Maximum size is 5 MB.');
      setBusy(false);
      return;
    }

    const exp = candidateType === 'Experienced'
      ? experiences.filter((e) => e.company || e.position)
      : [];

    const data = {
      full_name: String(form.get('full_name') || '').trim(),
      address: String(form.get('address') || '').trim(),
      pin_code: String(form.get('pin_code') || '').trim(),
      position: String(form.get('position') || '').trim(),
      phone: String(form.get('phone') || '').trim(),
      email: String(form.get('email') || '').trim(),
      current_ctc: String(form.get('current_ctc') || '').trim(),
      candidate_type: candidateType,
      education: String(form.get('education') || '').trim(),
      skills: String(form.get('skills') || '').trim(),
      experience: exp,
      status: 'New',
    };

    const fd = new FormData();
    Object.entries(data).forEach(([k, v]) => fd.append(k, typeof v === 'string' ? v : JSON.stringify(v)));
    fd.append('resume', file);

    try {
      await pb.collection('job_applications').create(fd);
      setDone(true);
    } catch {
      setError('Your application could not be submitted. Please check all fields and try again.');
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="dialog-backdrop" role="dialog" aria-modal="true">
        <div className="record-dialog">
          <div className="success-panel" role="status">
            <CheckCircle2 size={32} />
            <h3>Application submitted.</h3>
            <p>Thank you for applying. Our team will review your application and reach out if your profile matches an open position.</p>
            <button className="button button-dark" onClick={onClose}>Close <ArrowUpRight size={16} /></button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dialog-backdrop" role="dialog" aria-modal="true">
      <form className="record-dialog" onSubmit={submit} style={{ maxWidth: 720 }}>
        <h2>Job application<span className="accent-dot">.</span></h2>
        <p>Tell us about yourself and upload your resume. Fields marked <span className="required">*</span> are required.</p>
        <div className="record-fields">
          <label>Full name <span className="required">*</span><input name="full_name" required maxLength={200} placeholder="Full name" /></label>
          <label>Position applied for <span className="required">*</span>
            <select name="position" required defaultValue="">
              <option value="" disabled>Select a position</option>
              {jobCategories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label className="field-wide">Complete address <span className="required">*</span><input name="address" required maxLength={1000} placeholder="House no, street, area, city, state" /></label>
          <label>PIN code <span className="required">*</span><input name="pin_code" required pattern="[0-9]{6}" maxLength={6} placeholder="6-digit PIN" /></label>
          <label>Phone number <span className="required">*</span><input name="phone" type="tel" required pattern="[0-9+\-\s]{7,15}" placeholder="Phone number" /></label>
          <label>Email address <span className="required">*</span><input name="email" type="email" required placeholder="you@email.com" /></label>
          <label>Current CTC<input name="current_ctc" maxLength={100} placeholder="e.g. ₹4,50,000 / year" /></label>
          <label>Candidate type <span className="required">*</span>
            <select name="candidate_type" value={candidateType} onChange={(e) => setCandidateType(e.target.value as 'Fresher' | 'Experienced')}>
              <option value="Fresher">Fresher</option>
              <option value="Experienced">Experienced</option>
            </select>
          </label>
          <label className="field-wide">Education <span className="required">*</span><input name="education" required maxLength={1000} placeholder="Highest qualification, e.g. B.Com, MBA" /></label>
          <label className="field-wide">Skills <span className="required">*</span><textarea name="skills" required maxLength={2000} rows={3} placeholder="Comma-separated skills, e.g. Tally, Excel, GST, Accounting" /></label>
        </div>

        {candidateType === 'Experienced' && (
          <div className="experience-section">
            <div className="experience-head">
              <h3><Briefcase size={16} /> Employment history</h3>
              <button type="button" className="button button-quiet button-small" onClick={addExperience}><Plus size={14} /> Add another experience</button>
            </div>
            {experiences.map((exp, idx) => (
              <div className="experience-card" key={idx}>
                <div className="experience-card-head">
                  <span>Experience {idx + 1}</span>
                  {experiences.length > 1 && (
                    <button type="button" className="icon-button table-delete" aria-label="Remove experience" onClick={() => removeExperience(idx)}><Trash2 size={15} /></button>
                  )}
                </div>
                <div className="record-fields">
                  <label>Company name<input value={exp.company} onChange={(e) => updateExperience(idx, 'company', e.target.value)} placeholder="Company name" /></label>
                  <label>Position held<input value={exp.position} onChange={(e) => updateExperience(idx, 'position', e.target.value)} placeholder="Position held" /></label>
                  <label>Start date<input type="month" value={exp.startDate} onChange={(e) => updateExperience(idx, 'startDate', e.target.value)} /></label>
                  <label>End date<input type="month" value={exp.endDate} onChange={(e) => updateExperience(idx, 'endDate', e.target.value)} /></label>
                  <label className="field-wide">Responsibilities<textarea rows={2} value={exp.responsibilities} onChange={(e) => updateExperience(idx, 'responsibilities', e.target.value)} placeholder="Key responsibilities and achievements" /></label>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="record-fields" style={{ marginTop: 18 }}>
          <label className="field-wide">Resume upload <span className="required">*</span>
            <div className="resume-upload">
              <input name="resume" type="file" accept=".pdf,.doc,.docx" required onChange={(e) => setResumeName(e.target.files?.[0]?.name || '')} />
              <span className="resume-hint"><Upload size={14} /> {resumeName || 'PDF or Word, up to 5 MB'}</span>
            </div>
          </label>
        </div>

        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="dialog-actions">
          <button className="button button-quiet" type="button" disabled={busy} onClick={onClose}>Cancel</button>
          <button className="button button-primary" disabled={busy}>{busy ? 'Submitting…' : 'Submit application'}<ArrowUpRight size={17} /></button>
        </div>
        <div className="auth-safe" style={{ marginTop: 14 }}><MapPin size={12} /> Your details are private and visible only to authorized administrators.</div>
      </form>
    </div>
  );
}
