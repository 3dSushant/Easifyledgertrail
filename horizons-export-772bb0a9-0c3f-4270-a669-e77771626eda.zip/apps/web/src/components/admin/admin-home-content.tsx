import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { ArrowUpRight, CheckCircle2, Eye, Send, Save } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { defaultHomeContent, type HomeContent } from '@/lib/home-content';

type HomeSettingsRecord = { id: string; content?: HomeContent; draft?: HomeContent };

export function AdminHomeContent({ settings }: { settings: HomeSettingsRecord | null }) {
  const [draft, setDraft] = useState<HomeContent>(settings?.draft ?? settings?.content ?? defaultHomeContent);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState('');
  const [error, setError] = useState('');
  const revalidator = useRevalidator();

  function update(section: keyof HomeContent, field: string, value: string, index?: number) {
    setDraft((prev) => {
      const next = structuredClone(prev);
      if (index !== undefined) {
        const arr = (next[section] as unknown as Record<string, unknown[]>)[field] as { title?: string; description?: string }[];
        if (field === 'steps') {
          if (typeof value === 'string') {
            const [fi, key] = [index, 'title'];
            (arr[fi] as Record<string, string>)[key] = value;
          }
        }
      } else {
        (next[section] as Record<string, string>)[field] = value;
      }
      return next;
    });
  }

  function updateStep(index: number, key: 'title' | 'description', value: string) {
    setDraft((prev) => {
      const next = structuredClone(prev);
      next.howItWorks.steps[index][key] = value;
      return next;
    });
  }

  function updateCapability(index: number, field: 'title' | 'description' | 'link' | 'label', value: string) {
    setDraft((prev) => {
      const next = structuredClone(prev);
      const item = next.capabilities.items[index];
      if (field === 'title') item.title = value;
      else if (field === 'description') item.description = value;
      else if (field === 'link') item.link = value;
      else if (field === 'label') item.label = value;
      return next;
    });
  }

  function updateCapabilityItems(index: number, value: string) {
    setDraft((prev) => {
      const next = structuredClone(prev);
      next.capabilities.items[index].items = value.split('\n').filter(Boolean);
      return next;
    });
  }

  async function saveDraft() {
    setBusy(true); setError(''); setSaved('');
    try {
      if (settings?.id) await pb.collection('home_settings').update(settings.id, { draft });
      else await pb.collection('home_settings').create({ draft });
      setSaved('Draft saved.');
      revalidator.revalidate();
    } catch { setError('Could not save the draft. Please try again.'); }
    finally { setBusy(false); }
  }

  async function publish() {
    setBusy(true); setError(''); setSaved('');
    try {
      if (settings?.id) await pb.collection('home_settings').update(settings.id, { content: draft, draft: draft });
      else await pb.collection('home_settings').create({ content: draft, draft });
      setSaved('Home page published.');
      revalidator.revalidate();
    } catch { setError('Could not publish. Please try again.'); }
    finally { setBusy(false); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">HOME PAGE</span><h1>Home page content<span>.</span></h1><p>Edit the headings, descriptions and buttons shown on the main landing page.</p></div>
        <div className="heading-actions">
          <a className="button button-quiet button-small" href="/?preview=1" target="_blank" rel="noreferrer"><Eye size={15} />Preview live</a>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); publish(); }}>
        <section className="dashboard-panel" style={{ marginBottom: 22 }}>
          <div className="panel-heading"><div><h2>Hero section</h2><p>The first thing visitors see.</p></div></div>
          <div className="settings-form"><div className="record-fields">
            <label className="field-wide">Eyebrow<input defaultValue={draft.hero.eyebrow} onChange={(e) => update('hero', 'eyebrow', e.target.value)} maxLength={200} /></label>
            <label className="field-wide">Heading<input defaultValue={draft.hero.heading} onChange={(e) => update('hero', 'heading', e.target.value)} maxLength={300} /></label>
            <label className="field-wide">Description<textarea rows={3} defaultValue={draft.hero.description} onChange={(e) => update('hero', 'description', e.target.value)} maxLength={1000} /></label>
            <label>Button text<input defaultValue={draft.hero.ctaText} onChange={(e) => update('hero', 'ctaText', e.target.value)} maxLength={100} /></label>
            <label>Button link<input defaultValue={draft.hero.ctaLink} onChange={(e) => update('hero', 'ctaLink', e.target.value)} maxLength={200} /></label>
            <label>Secondary link text<input defaultValue={draft.hero.linkText} onChange={(e) => update('hero', 'linkText', e.target.value)} maxLength={100} /></label>
          </div></div>
        </section>

        <section className="dashboard-panel" style={{ marginBottom: 22 }}>
          <div className="panel-heading"><div><h2>Capabilities section</h2><p>The three feature cards.</p></div></div>
          <div className="settings-form"><div className="record-fields">
            <label className="field-wide">Eyebrow<input defaultValue={draft.capabilities.eyebrow} onChange={(e) => update('capabilities', 'eyebrow', e.target.value)} maxLength={200} /></label>
            <label className="field-wide">Title (use line breaks)<textarea rows={2} defaultValue={draft.capabilities.title} onChange={(e) => update('capabilities', 'title', e.target.value)} maxLength={300} /></label>
            <label className="field-wide">Description<textarea rows={2} defaultValue={draft.capabilities.description} onChange={(e) => update('capabilities', 'description', e.target.value)} maxLength={500} /></label>
          </div></div>
          {draft.capabilities.items.map((cap, i) => (
            <div className="settings-form" key={i}><div className="record-fields" style={{ marginTop: 8 }}>
              <label className="field-wide">Card {i + 1} title<textarea rows={2} defaultValue={cap.title} onChange={(e) => updateCapability(i, 'title', e.target.value)} maxLength={200} /></label>
              <label className="field-wide">Card {i + 1} description<textarea rows={3} defaultValue={cap.description} onChange={(e) => updateCapability(i, 'description', e.target.value)} maxLength={1000} /></label>
              <label className="field-wide">Card {i + 1} features (one per line)<textarea rows={3} defaultValue={cap.items.join('\n')} onChange={(e) => updateCapabilityItems(i, e.target.value)} maxLength={500} /></label>
              <label>Card {i + 1} link<input defaultValue={cap.link} onChange={(e) => updateCapability(i, 'link', e.target.value)} maxLength={200} /></label>
              <label>Card {i + 1} button label<input defaultValue={cap.label} onChange={(e) => updateCapability(i, 'label', e.target.value)} maxLength={100} /></label>
            </div></div>
          ))}
        </section>

        <section className="dashboard-panel" style={{ marginBottom: 22 }}>
          <div className="panel-heading"><div><h2>How it works section</h2><p>The three-step workflow.</p></div></div>
          <div className="settings-form"><div className="record-fields">
            <label className="field-wide">Eyebrow<input defaultValue={draft.howItWorks.eyebrow} onChange={(e) => update('howItWorks', 'eyebrow', e.target.value)} maxLength={200} /></label>
            <label className="field-wide">Heading<textarea rows={2} defaultValue={draft.howItWorks.heading} onChange={(e) => update('howItWorks', 'heading', e.target.value)} maxLength={300} /></label>
            <label className="field-wide">Description<textarea rows={2} defaultValue={draft.howItWorks.description} onChange={(e) => update('howItWorks', 'description', e.target.value)} maxLength={500} /></label>
            <label>Button text<input defaultValue={draft.howItWorks.ctaText} onChange={(e) => update('howItWorks', 'ctaText', e.target.value)} maxLength={100} /></label>
            <label>Button link<input defaultValue={draft.howItWorks.ctaLink} onChange={(e) => update('howItWorks', 'ctaLink', e.target.value)} maxLength={200} /></label>
          </div></div>
          {draft.howItWorks.steps.map((step, i) => (
            <div className="settings-form" key={i}><div className="record-fields" style={{ marginTop: 8 }}>
              <label>Step {i + 1} title<input defaultValue={step.title} onChange={(e) => updateStep(i, 'title', e.target.value)} maxLength={200} /></label>
              <label>Step {i + 1} description<input defaultValue={step.description} onChange={(e) => updateStep(i, 'description', e.target.value)} maxLength={500} /></label>
            </div></div>
          ))}
        </section>

        <section className="dashboard-panel" style={{ marginBottom: 22 }}>
          <div className="panel-heading"><div><h2>Closing section</h2><p>The final call to action.</p></div></div>
          <div className="settings-form"><div className="record-fields">
            <label className="field-wide">Eyebrow<input defaultValue={draft.closing.eyebrow} onChange={(e) => update('closing', 'eyebrow', e.target.value)} maxLength={200} /></label>
            <label className="field-wide">Heading<textarea rows={2} defaultValue={draft.closing.heading} onChange={(e) => update('closing', 'heading', e.target.value)} maxLength={300} /></label>
            <label className="field-wide">Description<textarea rows={2} defaultValue={draft.closing.description} onChange={(e) => update('closing', 'description', e.target.value)} maxLength={500} /></label>
          </div></div>
        </section>

        {saved && <p className="form-success" role="status"><CheckCircle2 size={17} />{saved}</p>}
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="dialog-actions">
          <button type="button" className="button button-quiet" onClick={saveDraft} disabled={busy}><Save size={16} />Save draft</button>
          <button type="submit" className="button button-primary" disabled={busy}>{busy ? 'Publishing…' : 'Publish'}<Send size={16} /></button>
        </div>
      </form>
    </>
  );
}
