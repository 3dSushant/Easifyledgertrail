import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Plus, Eye, ArrowUpRight, UserCheck, UserX, Building2, Check, X } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel, money, netPay, type BusinessRecord } from '@/lib/business';
import type { RecordModel } from 'pocketbase';

type ClientUser = RecordModel & { name?: string; email: string; business_name?: string; active: boolean; role: string };

export type { ClientUser };

export function AdminClients({ clients, requests }: { clients: ClientUser[]; requests: RecordModel[] }) {
  const members = clients.filter((c) => c.role !== 'admin');
  const [busyId, setBusyId] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [viewClient, setViewClient] = useState<ClientUser | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [rejectTarget, setRejectTarget] = useState<RecordModel | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [approvedCreds, setApprovedCreds] = useState<{ name: string; email: string; password: string } | null>(null);
  const revalidator = useRevalidator();

  async function toggle(client: ClientUser) {
    setBusyId(client.id);
    try {
      await pb.collection('users').update(client.id, { active: !client.active });
      revalidator.revalidate();
    } catch { setError('Could not update client status.'); }
    finally { setBusyId(''); }
  }

  async function create(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError('');
    const form = new FormData(event.currentTarget);
    try {
      await pb.collection('users').create({
        name: String(form.get('name')).trim(),
        business_name: String(form.get('business_name')).trim(),
        email: String(form.get('email')).trim(),
        password: String(form.get('password')),
        passwordConfirm: String(form.get('password')),
        role: 'member',
        active: true,
      });
      setCreateOpen(false);
      revalidator.revalidate();
    } catch { setError('Could not create the client. The email may already be in use.'); }
    finally { setBusy(false); }
  }

  function generatePassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let pwd = '';
    for (let i = 0; i < 12; i++) pwd += chars[Math.floor(Math.random() * chars.length)];
    return `El${pwd}1`;
  }

  async function approveRequest(req: RecordModel) {
    setBusy(true); setError('');
    const password = generatePassword();
    try {
      await pb.collection('users').create({
        name: req.name || '',
        business_name: req.business || '',
        email: req.email,
        password,
        passwordConfirm: password,
        role: 'member',
        active: true,
      });
      await pb.collection('access_requests').update(req.id, { status: 'approved' });
      setApprovedCreds({ name: req.name || req.business || 'Client', email: req.email, password });
      revalidator.revalidate();
    } catch { setError('Could not approve the request. The email may already be in use by an existing client.'); }
    finally { setBusy(false); }
  }

  async function confirmReject() {
    if (!rejectTarget) return;
    setBusy(true); setError('');
    try {
      await pb.collection('access_requests').update(rejectTarget.id, { status: 'rejected', rejection_reason: rejectReason.trim() });
      setRejectTarget(null);
      setRejectReason('');
      revalidator.revalidate();
    } catch { setError('Could not update the request status.'); }
    finally { setBusy(false); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">CLIENT MANAGEMENT</span><h1>Clients<span>.</span></h1><p>Create accounts, enable or disable access, and review each client’s records.</p></div>
        <button className="button button-primary" onClick={() => setCreateOpen(true)}><Plus size={17} />Add client</button>
      </div>

      {requests.length > 0 && (
        <section className="dashboard-panel" style={{ marginBottom: 22 }}>
          <div className="panel-heading"><div><h2>Access requests <span className="count-label">{requests.length}</span></h2><p>Review mobile numbers, approve to provision a client account, or reject with a reason.</p></div></div>
          <div className="table-scroll"><table><thead><tr><th>Name</th><th>Business</th><th>Email</th><th>Mobile</th><th>Requested</th><th>Status</th><th className="align-right">Actions</th></tr></thead><tbody>{requests.map((r) => {
            const status = r.status || 'pending';
            return (
              <tr key={r.id}>
                <td><strong>{r.name}</strong>{r.rejection_reason && <small style={{ color: 'var(--signal)' }}>Rejected: {r.rejection_reason}</small>}</td>
                <td>{r.business}</td>
                <td>{r.email}</td>
                <td className="nowrap">{r.phone || '—'}</td>
                <td className="nowrap">{dateLabel(r.created)}</td>
                <td>{status === 'approved' ? <span className="status-badge status-complete"><i />Approved</span> : status === 'rejected' ? <span className="status-badge status-overdue"><i />Rejected</span> : <span className="status-badge status-pending"><i />Pending</span>}</td>
                <td><div className="table-actions">
                  {status === 'pending' && <>
                    <button className="button button-quiet button-small" disabled={busy} onClick={() => approveRequest(r)}><Check size={14} />Approve</button>
                    <button className="button button-quiet button-small" disabled={busy} onClick={() => { setRejectTarget(r); setRejectReason(''); }}><X size={14} />Reject</button>
                  </>}
                  {status !== 'pending' && <span className="small-note">Reviewed</span>}
                </div></td>
              </tr>
            );
          })}</tbody></table></div>
        </section>
      )}

      <section className="dashboard-panel">
        <div className="panel-heading"><div><h2>Client accounts <span className="count-label">{members.length}</span></h2><p>Enable, disable or view each client’s workspace data.</p></div></div>
        {members.length ? (
          <div className="table-scroll"><table><thead><tr><th>Client</th><th>Email</th><th>Business</th><th>Status</th><th>Joined</th><th className="align-right">Actions</th></tr></thead><tbody>{members.map((c) => (
            <tr key={c.id}>
              <td><strong>{c.name || '—'}</strong></td>
              <td>{c.email}</td>
              <td>{c.business_name || '—'}</td>
              <td>{c.active ? <span className="status-badge status-complete"><i />Active</span> : <span className="status-badge status-inactive"><i />Disabled</span>}</td>
              <td className="nowrap">{dateLabel(c.created)}</td>
              <td><div className="table-actions">
                <button className="icon-button table-edit" aria-label="View records" onClick={() => setViewClient(c)}><Eye size={15} /></button>
                <button className="icon-button" disabled={busyId === c.id} onClick={() => toggle(c)} aria-label={c.active ? 'Disable client' : 'Enable client'}>
                  {c.active ? <UserX size={15} /> : <UserCheck size={15} />}
                </button>
              </div></td>
            </tr>
          ))}</tbody></table></div>
        ) : <div className="large-empty"><Building2 size={42} strokeWidth={1.3} /><h3>No clients yet.</h3><p>Create a client account to get started.</p><button className="button button-primary" onClick={() => setCreateOpen(true)}><Plus size={17} />Add client</button></div>}
      </section>

      <Dialog open={createOpen} onOpenChange={(v) => { if (!busy) { setCreateOpen(v); setError(''); } }}>
        <DialogContent className="record-dialog">
          <DialogTitle>New client account<span className="accent-dot">.</span></DialogTitle>
          <DialogDescription>Create a business workspace login for a client.</DialogDescription>
          <form onSubmit={create}><div className="record-fields">
            <label>Client name<input name="name" required maxLength={200} placeholder="Full name" /></label>
            <label>Business name<input name="business_name" maxLength={200} placeholder="Business name" /></label>
            <label className="field-wide">Email<input name="email" type="email" required placeholder="client@business.com" /></label>
            <label className="field-wide">Password<input name="password" type="password" required minLength={8} placeholder="At least 8 characters" /></label>
          </div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" type="button" disabled={busy} onClick={() => setCreateOpen(false)}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Creating…' : 'Create client'}<ArrowUpRight size={17} /></button></div></form>
        </DialogContent>
      </Dialog>

      <ClientRecords client={viewClient} onClose={() => setViewClient(null)} />

      <Dialog open={!!rejectTarget} onOpenChange={(v) => { if (!busy && !v) { setRejectTarget(null); setRejectReason(''); } }}>
        <DialogContent className="record-dialog">
          <DialogTitle>Reject access request<span className="accent-dot">.</span></DialogTitle>
          <DialogDescription>The request will be marked rejected. The applicant is not notified automatically.</DialogDescription>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="record-fields">
            <label className="field-wide">Rejection reason<textarea defaultValue="" rows={3} onChange={(e) => setRejectReason(e.target.value)} placeholder="Optional reason for records" /></label>
          </div>
          <div className="dialog-actions">
            <button className="button button-quiet" disabled={busy} onClick={() => { setRejectTarget(null); setRejectReason(''); }}>Cancel</button>
            <button className="button button-primary" disabled={busy} onClick={confirmReject}>{busy ? 'Saving…' : 'Reject request'}<ArrowUpRight size={17} /></button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!approvedCreds} onOpenChange={(v) => { if (!v) setApprovedCreds(null); }}>
        <DialogContent className="record-dialog">
          <DialogTitle>Client account created<span className="accent-dot">.</span></DialogTitle>
          <DialogDescription>Share these temporary credentials with the client. They can sign in and change their password later.</DialogDescription>
          {approvedCreds && (
            <div className="record-fields">
              <label className="field-wide">Client name<input value={approvedCreds.name} readOnly /></label>
              <label>Email<input value={approvedCreds.email} readOnly /></label>
              <label>Temporary password<input value={approvedCreds.password} readOnly /></label>
            </div>
          )}
          <div className="dialog-actions">
            <button className="button button-primary" onClick={() => setApprovedCreds(null)}><Check size={16} />Done</button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function ClientRecords({ client, onClose }: { client: ClientUser | null; onClose: () => void }) {
  const [data, setData] = useState<{ transactions: BusinessRecord[]; employees: BusinessRecord[]; compliance: BusinessRecord[] } | null>(null);
  const [loading, setLoading] = useState(false);

  async function load(id: string) {
    setLoading(true);
    try {
      const filter = `owner = "${id}"`;
      const [transactions, employees, compliance] = await Promise.all([
        pb.collection('transactions').getFullList<BusinessRecord>({ filter, sort: '-date' }),
        pb.collection('employees').getFullList<BusinessRecord>({ filter, sort: 'name' }),
        pb.collection('compliance_items').getFullList<BusinessRecord>({ filter, sort: 'due_date' }),
      ]);
      setData({ transactions, employees, compliance });
    } catch { setData({ transactions: [], employees: [], compliance: [] }); }
    finally { setLoading(false); }
  }

  return (
    <Dialog open={Boolean(client)} onOpenChange={(v) => { if (!v) { onClose(); setData(null); } }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        {client && (
          <>
            <DialogTitle>{client.name || client.business_name || 'Client'} records<span className="accent-dot">.</span></DialogTitle>
            <DialogDescription>{client.email} · {client.business_name || '—'}</DialogDescription>
            {!data && !loading && <button className="button button-primary" onClick={() => load(client.id)}>Load records <ArrowUpRight size={16} /></button>}
            {loading && <p className="small-note">Loading records…</p>}
            {data && (
              <div style={{ marginTop: 16 }}>
                <p className="small-note" style={{ marginBottom: 8 }}>{data.transactions.length} transactions · {data.employees.length} employees · {data.compliance.length} compliance items</p>
                {data.transactions.length > 0 && (
                  <div className="table-scroll" style={{ marginBottom: 16 }}><table><thead><tr><th>Date</th><th>Description</th><th>Type</th><th className="align-right">Amount</th></tr></thead><tbody>{data.transactions.slice(0, 10).map((t) => (
                    <tr key={t.id}><td className="nowrap">{dateLabel(t.date)}</td><td><strong>{t.description}</strong></td><td>{t.type}</td><td className="align-right amount-cell">{money(t.amount || 0)}</td></tr>
                  ))}</tbody></table></div>
                )}
                {data.employees.length > 0 && (
                  <div className="table-scroll" style={{ marginBottom: 16 }}><table><thead><tr><th>Employee</th><th>Designation</th><th className="align-right">Net pay</th></tr></thead><tbody>{data.employees.map((e) => (
                    <tr key={e.id}><td><strong>{e.name}</strong></td><td>{e.designation || '—'}</td><td className="align-right amount-cell">{money(netPay(e))}</td></tr>
                  ))}</tbody></table></div>
                )}
                {data.compliance.length > 0 && (
                  <div className="table-scroll"><table><thead><tr><th>Title</th><th>Type</th><th>Due</th><th>Status</th></tr></thead><tbody>{data.compliance.map((c) => (
                    <tr key={c.id}><td><strong>{c.title}</strong></td><td>{c.type}</td><td className="nowrap">{dateLabel(c.due_date)}</td><td>{c.status}</td></tr>
                  ))}</tbody></table></div>
                )}
                {data.transactions.length === 0 && data.employees.length === 0 && data.compliance.length === 0 && <p className="small-note">This client has no records yet.</p>}
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
