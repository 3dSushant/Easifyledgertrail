import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Plus, Pencil, Trash2, ArrowUpRight, Mail, Phone, Building2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel } from '@/lib/business';
import { packageCategories, type Package, type QuoteRequest } from '@/lib/content';

const blank = { category: 'Tax and Statutory Compliance', name: '', description: '', services: [] as string[], image: '', cta_text: 'Get a Quote', sort: 0, published: true };

export function AdminPackages({ packages, quotes }: { packages: Package[]; quotes: QuoteRequest[] }) {
  const [editing, setEditing] = useState<Package | null>(null);
  const [creating, setCreating] = useState(false);
  const revalidator = useRevalidator();

  async function remove(id: string) {
    if (!confirm('Delete this package permanently?')) return;
    try { await pb.collection('packages').delete(id); revalidator.revalidate(); } catch { alert('Could not delete the package.'); }
  }

  async function removeQuote(id: string) {
    if (!confirm('Delete this quote request?')) return;
    try { await pb.collection('quote_requests').delete(id); revalidator.revalidate(); } catch { alert('Could not delete the request.'); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">OFFERINGS</span><h1>Packages<span>.</span></h1><p>Manage packages shown on the website and review quote requests.</p></div>
        <button className="button button-primary" onClick={() => setCreating(true)}><Plus size={17} />Add package</button>
      </div>

      {packageCategories.map((cat) => {
        const items = packages.filter((p) => p.category === cat.name);
        return (
          <section className="dashboard-panel" key={cat.slug} style={{ marginBottom: 22 }}>
            <div className="panel-heading"><div><h2>{cat.name} <span className="count-label">{items.length}</span></h2><p>{cat.short}</p></div></div>
            {items.length ? (
              <div className="table-scroll"><table><thead><tr><th>Package</th><th>Services</th><th>Published</th><th className="align-right">Actions</th></tr></thead><tbody>{items.map((p) => (
                <tr key={p.id}>
                  <td><strong>{p.name}</strong><small>{p.cta_text}</small></td>
                  <td>{p.services?.length || 0} service(s)</td>
                  <td>{p.published ? <span className="status-badge status-complete"><i />Published</span> : <span className="status-badge status-inactive"><i />Hidden</span>}</td>
                  <td><div className="table-actions">
                    <button className="icon-button table-edit" aria-label="Edit" onClick={() => setEditing(p)}><Pencil size={15} /></button>
                    <button className="icon-button table-delete" aria-label="Delete" onClick={() => remove(p.id)}><Trash2 size={15} /></button>
                  </div></td>
                </tr>
              ))}</tbody></table></div>
            ) : <div className="compact-empty"><p>No packages in this category yet.</p></div>}
          </section>
        );
      })}

      <section className="dashboard-panel" style={{ marginTop: 22 }}>
        <div className="panel-heading"><div><h2>Quote requests <span className="count-label">{quotes.length}</span></h2><p>Submitted from the Packages page</p></div></div>
        {quotes.length ? (
          <div className="table-scroll"><table><thead><tr><th>Name</th><th>Company</th><th>Contact</th><th>Package</th><th>Requested</th><th className="align-right">Actions</th></tr></thead><tbody>{quotes.map((q) => (
            <tr key={q.id}>
              <td><strong>{q.name}</strong></td>
              <td>{q.company || '—'}</td>
              <td><small><Mail size={11} /> {q.email}</small><small><Phone size={11} /> {q.phone}</small></td>
              <td>{q.package}</td>
              <td className="nowrap">{dateLabel(q.created)}</td>
              <td><div className="table-actions"><button className="icon-button table-delete" aria-label="Delete" onClick={() => removeQuote(q.id)}><Trash2 size={15} /></button></div></td>
            </tr>
          ))}</tbody></table></div>
        ) : <div className="large-empty"><Building2 size={42} strokeWidth={1.3} /><h3>No quote requests yet.</h3><p>Quote requests from the Packages page will appear here.</p></div>}
      </section>

      {(creating || editing) && <PackageEditor pkg={editing} onClose={() => { setCreating(false); setEditing(null); }} />}
    </>
  );
}

function PackageEditor({ pkg, onClose }: { pkg: Package | null; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const revalidator = useRevalidator();

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError('');
    const form = new FormData(event.currentTarget);
    const services = String(form.get('services') || '').split('\n').map((s) => s.trim()).filter(Boolean);
    const values = {
      category: String(form.get('category')),
      name: String(form.get('name')).trim(),
      description: String(form.get('description')).trim(),
      services,
      image: String(form.get('image')).trim(),
      cta_text: String(form.get('cta_text')).trim() || 'Get a Quote',
      sort: Number(form.get('sort') || 0),
      published: form.get('published') === 'on',
    };
    try {
      if (pkg) await pb.collection('packages').update(pkg.id, values);
      else await pb.collection('packages').create(values);
      onClose(); revalidator.revalidate();
    } catch { setError('Could not save the package.'); }
    finally { setBusy(false); }
  }

  const f = pkg ?? blank;
  return (
    <Dialog open onOpenChange={(v) => { if (!busy && !v) onClose(); }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        <DialogTitle>{pkg ? 'Edit' : 'New'} package<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>This content appears on the public Packages page.</DialogDescription>
        <form onSubmit={save}><div className="record-fields">
          <label>Category<select name="category" defaultValue={f.category}>{packageCategories.map((c) => <option key={c.slug} value={c.name}>{c.name}</option>)}</select></label>
          <label>Sort order<input name="sort" type="number" defaultValue={f.sort} /></label>
          <label className="field-wide">Package name<input name="name" defaultValue={f.name} required placeholder="Package name" /></label>
          <label className="field-wide">Description<textarea name="description" defaultValue={f.description} required rows={3} placeholder="Professional description" /></label>
          <label className="field-wide">Image URL<input name="image" defaultValue={f.image} placeholder="https://…" /></label>
          <label>Call-to-action text<input name="cta_text" defaultValue={f.cta_text} placeholder="Get a Quote" /></label>
          <label className="field-wide">Included services (one per line)<textarea name="services" defaultValue={f.services?.join('\n')} rows={5} placeholder={'GST filing\nTDS filing'} /></label>
          <label className="field-wide" style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><input type="checkbox" name="published" defaultChecked={f.published} style={{ width: 'auto', minHeight: 'auto' }} /> Published (visible on website)</label>
        </div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" type="button" disabled={busy} onClick={onClose}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save package'}<ArrowUpRight size={17} /></button></div></form>
      </DialogContent>
    </Dialog>
  );
}
