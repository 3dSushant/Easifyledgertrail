import { Trash2, MessageSquare, Mail, Phone } from 'lucide-react';
import { useRevalidator } from 'react-router';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel } from '@/lib/business';
import type { RecordModel } from 'pocketbase';

export function AdminMessages({ messages }: { messages: RecordModel[] }) {
  const revalidator = useRevalidator();
  async function remove(id: string) {
    if (!confirm('Delete this message?')) return;
    try { await pb.collection('contact_messages').delete(id); revalidator.revalidate(); } catch { alert('Could not delete the message.'); }
  }
  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">CONTACT SUBMISSIONS</span><h1>Messages<span>.</span></h1><p>Messages submitted through the website contact form.</p></div>
      </div>
      <section className="dashboard-panel">
        <div className="panel-heading"><div><h2>Inbox <span className="count-label">{messages.length}</span></h2></div></div>
        {messages.length ? (
          <div className="deadline-list">{messages.map((m) => (
            <div key={m.id} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: '16px 0', borderTop: '1px solid #efefe9' }}>
              <span className="tax-icon"><MessageSquare size={15} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <strong>{m.name} <span style={{ color: 'var(--quiet)', fontWeight: 400 }}>· {dateLabel(m.created)}</span></strong>
                <small style={{ display: 'flex', gap: 14, marginTop: 6, flexWrap: 'wrap' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Mail size={12} /> {m.email}</span>
                  {m.phone && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Phone size={12} /> {m.phone}</span>}
                </small>
                {m.subject && <p style={{ fontSize: 12, fontWeight: 600, marginTop: 8 }}>{m.subject}</p>}
                <p style={{ fontSize: 12, color: 'var(--quiet)', marginTop: 6, lineHeight: 1.7 }}>{m.message}</p>
              </div>
              <button className="icon-button table-delete" aria-label="Delete message" onClick={() => remove(m.id)}><Trash2 size={15} /></button>
            </div>
          ))}</div>
        ) : <div className="large-empty"><MessageSquare size={42} strokeWidth={1.3} /><h3>No messages yet.</h3><p>Contact form submissions will appear here.</p></div>}
      </section>
    </>
  );
}
