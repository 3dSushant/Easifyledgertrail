import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Search, Trash2, Download, Eye, Pencil, Briefcase, Mail, Phone, MapPin, GraduationCap } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel } from '@/lib/business';
import { jobCategories, type JobApplication, type ExperienceRecord } from '@/lib/content';

const STATUSES = ['New', 'Shortlisted', 'Interview', 'Selected', 'Rejected'] as const;

export function AdminJobs({ applications }: { applications: JobApplication[] }) {
  const [search, setSearch] = useState('');
  const [position, setPosition] = useState('all');
  const [type, setType] = useState('all');
  const [status, setStatus] = useState('all');
  const [viewing, setViewing] = useState<JobApplication | null>(null);
  const [editing, setEditing] = useState<JobApplication | null>(null);
  const revalidator = useRevalidator();

  const filtered = applications.filter((a) => {
    if (search) {
      const q = search.toLowerCase();
      if (!`${a.full_name} ${a.email} ${a.phone} ${a.position}`.toLowerCase().includes(q)) return false;
    }
    if (position !== 'all' && a.position !== position) return false;
    if (type !== 'all' && a.candidate_type !== type) return false;
    if (status !== 'all' && a.status !== status) return false;
    return true;
  });

  async function remove(id: string) {
    if (!confirm('Delete this application permanently? This cannot be undone.')) return;
    try { await pb.collection('job_applications').delete(id); revalidator.revalidate(); } catch { alert('Could not delete the application.'); }
  }

  async function changeStatus(id: string, newStatus: string) {
    try { await pb.collection('job_applications').update(id, { status: newStatus }); revalidator.revalidate(); } catch { alert('Could not update status.'); }
  }

  async function openResume(a: JobApplication) {
    if (!a.resume) return;
    try {
      const url = pb.files.getURL(a, a.resume);
      const res = await fetch(url, { headers: { Authorization: pb.authStore.token ? `Bearer ${pb.authStore.token}` : '' } });
      if (!res.ok) throw new Error('fetch failed');
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, '_blank');
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } catch { alert('Could not load the resume. Please try again.'); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">RECRUITMENT</span><h1>Job Applications<span>.</span></h1><p>Review candidate applications, resumes and statuses.</p></div>
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading"><div><h2>Applications <span className="count-label">{filtered.length}</span></h2></div></div>
        <div className="table-filters">
          <div className="search-control"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, email, phone…" /></div>
          <select value={position} onChange={(e) => setPosition(e.target.value)}>
            <option value="all">All positions</option>
            {jobCategories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="all">All types</option>
            <option value="Fresher">Fresher</option>
            <option value="Experienced">Experienced</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">All statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        {filtered.length ? (
          <div className="table-scroll"><table>
            <thead><tr><th>Candidate</th><th>Position</th><th>Type</th><th>Status</th><th>Applied</th><th className="align-right">Actions</th></tr></thead>
            <tbody>{filtered.map((a) => (
              <tr key={a.id}>
                <td><strong>{a.full_name}</strong><small>{a.email}</small></td>
                <td>{a.position}</td>
                <td><span className="type-label">{a.candidate_type}</span></td>
                <td>
                  <select className="status-select" value={a.status} onChange={(e) => changeStatus(a.id, e.target.value)}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td className="nowrap">{dateLabel(a.created)}</td>
                <td><div className="table-actions">
                  <button className="icon-button table-edit" aria-label="View" onClick={() => setViewing(a)}><Eye size={15} /></button>
                  <button className="icon-button table-edit" aria-label="Edit" onClick={() => setEditing(a)}><Pencil size={15} /></button>
                  {a.resume && <button className="icon-button table-edit" aria-label="Resume" onClick={() => openResume(a)}><Download size={15} /></button>}
                  <button className="icon-button table-delete" aria-label="Delete" onClick={() => remove(a.id)}><Trash2 size={15} /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table></div>
        ) : <div className="large-empty"><Briefcase size={42} strokeWidth={1.3} /><h3>No applications found.</h3><p>Job applications will appear here once candidates apply.</p></div>}
      </section>

      {viewing && <ApplicationViewer application={viewing} onOpenResume={() => openResume(viewing)} onClose={() => setViewing(null)} />}
      {editing && <ApplicationEditor application={editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function ApplicationViewer({ application: a, onOpenResume, onClose }: { application: JobApplication; onOpenResume: () => void; onClose: () => void }) {
  const exp: ExperienceRecord[] = Array.isArray(a.experience) ? a.experience : [];
  return (
    <Dialog open onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        <DialogTitle>Candidate profile<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>{a.full_name} · {a.position}</DialogDescription>
        <div className="application-profile">
          <div className="profile-row"><Mail size={14} /> <span>{a.email}</span></div>
          <div className="profile-row"><Phone size={14} /> <span>{a.phone}</span></div>
          <div className="profile-row"><MapPin size={14} /> <span>{a.address} — {a.pin_code}</span></div>
          <div className="profile-row"><Briefcase size={14} /> <span>{a.candidate_type}{a.current_ctc ? ` · CTC ${a.current_ctc}` : ''}</span></div>
          <div className="profile-row"><GraduationCap size={14} /> <span>{a.education}</span></div>
          <div className="profile-block"><strong>Skills</strong><p>{a.skills}</p></div>
          {exp.length > 0 && (
            <div className="profile-block"><strong>Experience</strong>
              {exp.map((e, i) => (
                <div className="profile-exp" key={i}>
                  <strong>{e.position || '—'} · {e.company || '—'}</strong>
                  <small>{e.startDate || '—'} → {e.endDate || 'Present'}</small>
                  {e.responsibilities && <p>{e.responsibilities}</p>}
                </div>
              ))}
            </div>
          )}
          {a.resume && <button className="button button-dark button-small" onClick={onOpenResume}><Download size={15} /> View resume</button>}
        </div>
        <div className="dialog-actions"><button className="button button-quiet" onClick={onClose}>Close</button></div>
      </DialogContent>
    </Dialog>
  );
}

function ApplicationEditor({ application: a, onClose }: { application: JobApplication; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const revalidator = useRevalidator();

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError('');
    const form = new FormData(event.currentTarget);
    const values = {
      full_name: String(form.get('full_name')).trim(),
      position: String(form.get('position')),
      phone: String(form.get('phone')).trim(),
      email: String(form.get('email')).trim(),
      current_ctc: String(form.get('current_ctc')).trim(),
      education: String(form.get('education')).trim(),
      skills: String(form.get('skills')).trim(),
      status: String(form.get('status')),
    };
    try {
      await pb.collection('job_applications').update(a.id, values);
      onClose(); revalidator.revalidate();
    } catch { setError('Could not save the changes.'); }
    finally { setBusy(false); }
  }

  return (
    <Dialog open onOpenChange={(v) => { if (!busy && !v) onClose(); }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        <DialogTitle>Edit application<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>Update candidate details and status.</DialogDescription>
        <form onSubmit={save}><div className="record-fields">
          <label>Full name<input name="full_name" defaultValue={a.full_name} required /></label>
          <label>Position<select name="position" defaultValue={a.position}>{jobCategories.map((c) => <option key={c} value={c}>{c}</option>)}</select></label>
          <label>Phone<input name="phone" defaultValue={a.phone} required /></label>
          <label>Email<input name="email" type="email" defaultValue={a.email} required /></label>
          <label>Current CTC<input name="current_ctc" defaultValue={a.current_ctc} /></label>
          <label>Status<select name="status" defaultValue={a.status}>{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</select></label>
          <label className="field-wide">Education<input name="education" defaultValue={a.education} required /></label>
          <label className="field-wide">Skills<textarea name="skills" defaultValue={a.skills} rows={3} required /></label>
        </div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" type="button" disabled={busy} onClick={onClose}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button></div></form>
      </DialogContent>
    </Dialog>
  );
}
