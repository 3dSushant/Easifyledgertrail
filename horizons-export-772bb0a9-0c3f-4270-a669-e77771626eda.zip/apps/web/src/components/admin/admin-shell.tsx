import { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate, useRevalidator } from 'react-router';
import { LayoutDashboard, Users, Settings, MessageSquare, LogOut, Menu, X, RefreshCw, Globe, Briefcase, Newspaper, Package, UserPlus } from 'lucide-react';
import { Brand } from '@/components/brand';
import { useAuth } from '@/hooks/use-auth';
import type { RecordModel } from 'pocketbase';

export function AdminShell({ user }: { user: RecordModel }) {
  const [open, setOpen] = useState(false);
  const { logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const revalidator = useRevalidator();

  const current = location.pathname.includes('clients') ? 'Clients'
    : location.pathname.includes('services') ? 'Services'
    : location.pathname.includes('home-content') ? 'Home Page'
    : location.pathname.includes('content') ? 'Site Content'
    : location.pathname.includes('messages') ? 'Messages'
    : location.pathname.includes('jobs') ? 'Job Applications'
    : location.pathname.includes('hire') ? 'Hire Talent'
    : location.pathname.includes('news') ? 'News & Updates'
    : location.pathname.includes('packages') ? 'Packages'
    : 'Dashboard';

  return (
    <div className="workspace-shell">
      <aside className={`workspace-sidebar ${open ? 'sidebar-open' : ''}`}>
        <div className="sidebar-brand"><Brand /><button className="mobile-menu icon-button" onClick={() => setOpen(false)} aria-label="Close navigation"><X size={20} /></button></div>
        <div className="business-switch"><span className="business-avatar">A</span><div><strong>Admin Console</strong><small>{user.email}</small></div></div>
        <span className="sidebar-label">ADMINISTRATION</span>
        <nav aria-label="Admin navigation">
          <NavLink to="/admin" end onClick={() => setOpen(false)}><LayoutDashboard size={19} />Dashboard</NavLink>
          <NavLink to="/admin/clients" onClick={() => setOpen(false)}><Users size={19} />Clients</NavLink>
          <NavLink to="/admin/home-content" onClick={() => setOpen(false)}><LayoutDashboard size={19} />Home Page</NavLink>
          <NavLink to="/admin/content" onClick={() => setOpen(false)}><Settings size={19} />Site Content</NavLink>
          <NavLink to="/admin/messages" onClick={() => setOpen(false)}><MessageSquare size={19} />Messages</NavLink>
          <NavLink to="/admin/jobs" onClick={() => setOpen(false)}><Briefcase size={19} />Job Applications</NavLink>
          <NavLink to="/admin/hire" onClick={() => setOpen(false)}><UserPlus size={19} />Hire Talent</NavLink>
          <NavLink to="/admin/news" onClick={() => setOpen(false)}><Newspaper size={19} />News &amp; Updates</NavLink>
          <NavLink to="/admin/packages" onClick={() => setOpen(false)}><Package size={19} />Packages</NavLink>
        </nav>
        <div className="sidebar-bottom">
          <a href="/" target="_blank" rel="noreferrer"><Globe size={18} />View website</a>
          <button onClick={() => { logout(); navigate('/login'); }}><LogOut size={18} />Sign out</button>
        </div>
      </aside>
      {open && <button className="sidebar-backdrop" aria-label="Close navigation" onClick={() => setOpen(false)} />}
      <div className="workspace-body">
        <header className="workspace-header">
          <div><button className="mobile-menu icon-button" aria-label="Open navigation" onClick={() => setOpen(true)}><Menu size={22} /></button><span>Admin <span className="breadcrumb-slash">/</span> <strong>{current}</strong></span></div>
          <div><button className="icon-button" onClick={() => revalidator.revalidate()} disabled={revalidator.state !== 'idle'} aria-label="Refresh"><RefreshCw size={17} className={revalidator.state !== 'idle' ? 'spin' : ''} /></button><span className="user-avatar">{String(user.name || 'A').slice(0, 2).toUpperCase()}</span></div>
        </header>
        <main className="workspace-content"><Outlet /></main>
        <footer className="workspace-footer"><span>Easify Ledger · Admin Console</span><span>Manage clients, services and website content</span></footer>
      </div>
    </div>
  );
}
