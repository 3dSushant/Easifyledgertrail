import { useEffect, useRef, useState } from 'react';
import { useRevalidator } from 'react-router';
import { Plus, Pencil, Trash2, ArrowUpRight, MessageSquare, Eye, EyeOff } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel } from '@/lib/business';
import { newsCategories, slugify, articleImageUrl, type NewsArticle, type ArticleComment } from '@/lib/content';

const blank = { headline: '', slug: '', summary: '', content: '', image: '', author: '', category: 'Finance Updates', status: 'draft' as 'draft' | 'published' };

export function AdminNews({ articles }: { articles: NewsArticle[] }) {
  const [editing, setEditing] = useState<NewsArticle | null>(null);
  const [creating, setCreating] = useState(false);
  const [viewingComments, setViewingComments] = useState<NewsArticle | null>(null);
  const revalidator = useRevalidator();

  async function remove(id: string) {
    if (!confirm('Delete this article permanently? Comments and reactions will also be removed.')) return;
    try { await pb.collection('news_articles').delete(id); revalidator.revalidate(); } catch { alert('Could not delete the article.'); }
  }

  async function togglePublish(a: NewsArticle) {
    const next = a.status === 'published' ? 'draft' : 'published';
    try { await pb.collection('news_articles').update(a.id, { status: next, published_at: next === 'published' ? new Date().toISOString() : a.published_at }); revalidator.revalidate(); } catch { alert('Could not change status.'); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">CONTENT</span><h1>News &amp; Finance Updates<span>.</span></h1><p>Create, publish and moderate articles.</p></div>
        <button className="button button-primary" onClick={() => setCreating(true)}><Plus size={17} />New article</button>
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading"><div><h2>Articles <span className="count-label">{articles.length}</span></h2></div></div>
        {articles.length ? (
          <div className="table-scroll"><table>
            <thead><tr><th>Headline</th><th>Category</th><th>Status</th><th>Published</th><th className="align-right">Actions</th></tr></thead>
            <tbody>{articles.map((a) => (
              <tr key={a.id}>
                <td><strong>{a.headline}</strong><small>/{a.slug}</small></td>
                <td>{a.category}</td>
                <td>{a.status === 'published' ? <span className="status-badge status-complete"><i />Published</span> : <span className="status-badge status-inactive"><i />Draft</span>}</td>
                <td className="nowrap">{dateLabel(a.published_at || a.created)}</td>
                <td><div className="table-actions">
                  <button className="icon-button table-edit" aria-label="Toggle publish" onClick={() => togglePublish(a)}>{a.status === 'published' ? <EyeOff size={15} /> : <Eye size={15} />}</button>
                  <button className="icon-button table-edit" aria-label="Comments" onClick={() => setViewingComments(a)}><MessageSquare size={15} /></button>
                  <button className="icon-button table-edit" aria-label="Edit" onClick={() => setEditing(a)}><Pencil size={15} /></button>
                  <button className="icon-button table-delete" aria-label="Delete" onClick={() => remove(a.id)}><Trash2 size={15} /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table></div>
        ) : <div className="large-empty"><MessageSquare size={42} strokeWidth={1.3} /><h3>No articles yet.</h3><p>Create your first news article to publish it on the website.</p></div>}
      </section>

      {(creating || editing) && <ArticleEditor article={editing} onClose={() => { setCreating(false); setEditing(null); }} />}
      {viewingComments && <CommentsManager article={viewingComments} onClose={() => setViewingComments(null)} />}
    </>
  );
}

function ArticleEditor({ article, onClose }: { article: NewsArticle | null; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState<string | null>(article ? articleImageUrl(article) || null : null);
  const [removeImage, setRemoveImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const revalidator = useRevalidator();

  function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setError('Please choose a JPG, PNG or WebP image.');
      e.target.value = '';
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Image must be under 5 MB.');
      e.target.value = '';
      return;
    }
    setError('');
    setRemoveImage(false);
    setPreview(URL.createObjectURL(file));
  }

  function clearImage() {
    setPreview(null);
    setRemoveImage(true);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError('');
    const form = new FormData(event.currentTarget);
    const headline = String(form.get('headline')).trim();
    const status = String(form.get('status')) as 'draft' | 'published';
    const baseValues = {
      headline,
      slug: String(form.get('slug')).trim().toLowerCase() || slugify(headline),
      summary: String(form.get('summary')).trim(),
      content: String(form.get('content')).trim(),
      image: String(form.get('image')).trim(),
      author: String(form.get('author')).trim(),
      category: String(form.get('category')),
      status,
      published_at: status === 'published' && !article?.published_at ? new Date().toISOString() : article?.published_at || '',
    };
    const file = fileInputRef.current?.files?.[0];
    try {
      if (file || removeImage) {
        const fd = new FormData();
        Object.entries(baseValues).forEach(([k, v]) => fd.set(k, String(v)));
        if (file) fd.append('image_file', file);
        else fd.set('image_file', ''); // delete existing uploaded image
        if (article) await pb.collection('news_articles').update(article.id, fd);
        else await pb.collection('news_articles').create(fd);
      } else {
        if (article) await pb.collection('news_articles').update(article.id, baseValues);
        else await pb.collection('news_articles').create(baseValues);
      }
      onClose(); revalidator.revalidate();
    } catch { setError('Could not save the article. The slug may already be in use.'); }
    finally { setBusy(false); }
  }

  const f = article ?? blank;
  return (
    <Dialog open onOpenChange={(v) => { if (!busy && !v) onClose(); }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        <DialogTitle>{article ? 'Edit' : 'New'} article<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>This content appears on the public News &amp; Finance Updates page.</DialogDescription>
        <form onSubmit={save}><div className="record-fields">
          <label className="field-wide">Headline<input name="headline" defaultValue={f.headline} required placeholder="Article headline" /></label>
          <label>Slug<input name="slug" defaultValue={f.slug} placeholder="auto-generated from headline" /></label>
          <label>Category<select name="category" defaultValue={f.category}>{newsCategories.map((c) => <option key={c} value={c}>{c}</option>)}</select></label>
          <label>Author<input name="author" defaultValue={f.author} placeholder="Author name" /></label>
          <label className="field-wide">Summary<input name="summary" defaultValue={f.summary} required placeholder="Short one-line summary" /></label>
          <label>Status<select name="status" defaultValue={f.status}><option value="draft">Draft</option><option value="published">Published</option></select></label>
          <label className="field-wide">Featured image
            <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={onFileChange} style={{ minHeight: 'auto', padding: '8px' }} />
            {preview && !removeImage && (
              <div className="logo-preview" style={{ width: '100%', height: 140, marginTop: 8, position: 'relative' }}>
                <img src={preview} alt="Featured preview" />
                <button type="button" className="icon-button table-delete" style={{ position: 'absolute', top: 4, right: 4, background: 'white' }} onClick={clearImage} aria-label="Remove image"><Trash2 size={15} /></button>
              </div>
            )}
            <span className="small-note">Upload a JPG, PNG or WebP image (max 5 MB). Replaces any existing featured image.</span>
          </label>
          <label className="field-wide">Content<textarea name="content" defaultValue={f.content} required rows={8} placeholder="Full article content. Separate paragraphs with a blank line." /></label>
        </div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" type="button" disabled={busy} onClick={onClose}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save article'}<ArrowUpRight size={17} /></button></div></form>
      </DialogContent>
    </Dialog>
  );
}

function CommentsManager({ article, onClose }: { article: NewsArticle; onClose: () => void }) {
  const [comments, setComments] = useState<ArticleComment[]>([]);
  const [loading, setLoading] = useState(true);
  const revalidator = useRevalidator();

  async function load() {
    try {
      const list = await pb.collection('article_comments').getFullList<ArticleComment>({ filter: pb.filter('article = {:articleId}', { articleId: article.id }), sort: '-created' });
      setComments(list);
    } catch { setComments([]); }
    finally { setLoading(false); }
  }
  useEffect(() => { void load(); }, []);

  async function removeComment(id: string) {
    if (!confirm('Delete this comment?')) return;
    try { await pb.collection('article_comments').delete(id); setComments((prev) => prev.filter((c) => c.id !== id)); revalidator.revalidate(); } catch { alert('Could not delete the comment.'); }
  }

  return (
    <Dialog open onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="record-dialog payroll-details-dialog">
        <DialogTitle>Comments<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>On “{article.headline}”</DialogDescription>
        {loading ? <p className="small-note">Loading comments…</p> : (
          comments.length ? (
            <div className="comment-admin-list">{comments.map((c) => (
              <div className="comment-admin-item" key={c.id}>
                <div><strong>{c.name}</strong> <small>· {c.email} · {dateLabel(c.created)}</small></div>
                <p>{c.content}</p>
                <button className="icon-button table-delete" aria-label="Delete comment" onClick={() => removeComment(c.id)}><Trash2 size={15} /></button>
              </div>
            ))}</div>
          ) : <div className="compact-empty"><MessageSquare size={28} strokeWidth={1.4} /><strong>No comments yet.</strong></div>
        )}
        <div className="dialog-actions"><button className="button button-quiet" onClick={onClose}>Close</button></div>
      </DialogContent>
    </Dialog>
  );
}
