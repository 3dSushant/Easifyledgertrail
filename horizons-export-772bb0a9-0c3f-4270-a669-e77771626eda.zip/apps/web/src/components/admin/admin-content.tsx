import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { ArrowUpRight, CheckCircle2, Building2, MessageCircle } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { SiteSettings } from '@/lib/services';

export function AdminContent({ settings }: { settings: SiteSettings }) {
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const revalidator = useRevalidator();

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(''); setSaved(false);
    const form = new FormData(event.currentTarget);
    const values = {
      about_title: String(form.get('about_title')).trim(),
      about_content: String(form.get('about_content')).trim(),
      whatsapp: String(form.get('whatsapp')).trim(),
      email: String(form.get('email')).trim(),
      phone: String(form.get('phone')).trim(),
      location: String(form.get('location')).trim(),
    };
    try {
      if (settings.id) await pb.collection('site_settings').update(settings.id, values);
      else await pb.collection('site_settings').create(values);
      setSaved(true);
      revalidator.revalidate();
    } catch { setError('Could not save the content. Please try again.'); }
    finally { setBusy(false); }
  }

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">WEBSITE CONTENT</span><h1>Site content<span>.</span></h1><p>Edit the About page and contact details shown across the website.</p></div>
      </div>
      <form onSubmit={save}>
        <div className="settings-grid">
          <section className="dashboard-panel">
            <div className="panel-heading"><div><h2><Building2 size={21} />About page</h2><p>The title and content shown on the About Us page.</p></div></div>
            <div className="settings-form"><div className="record-fields">
              <label className="field-wide">About title<input name="about_title" defaultValue={settings.about_title} maxLength={200} /></label>
              <label className="field-wide">About content<textarea name="about_content" defaultValue={settings.about_content} rows={8} maxLength={8000} /></label>
            </div></div>
          </section>
          <section className="dashboard-panel security-panel">
            <div className="panel-heading"><div><h2><MessageCircle size={21} />Contact details</h2><p>Shown in the footer and contact page.</p></div></div>
            <div className="settings-form"><div className="record-fields">
              <label className="field-wide">WhatsApp number<input name="whatsapp" defaultValue={settings.whatsapp} maxLength={30} /></label>
              <label className="field-wide">Phone<input name="phone" defaultValue={settings.phone} maxLength={30} /></label>
              <label className="field-wide">Email<input name="email" type="email" defaultValue={settings.email} maxLength={120} /></label>
              <label className="field-wide">Location<input name="location" defaultValue={settings.location} maxLength={200} /></label>
            </div></div>
          </section>
        </div>
        {saved && <p className="form-success" role="status"><CheckCircle2 size={17} />Content saved.</p>}
        {error && <p className="form-error" role="alert">{error}</p>}
        <div className="dialog-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}<ArrowUpRight size={17} /></button></div>
      </form>
    </>
  );
}
