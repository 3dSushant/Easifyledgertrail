import { useCallback, useEffect, useState } from 'react';
import { useRevalidator } from 'react-router';
import { Plus, Eye, Download, Trash2, X, ArrowUpRight, Briefcase, Users } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { dateLabel } from '@/lib/business';

type JD = {
  id: string; created: string; job_title: string; department?: string; positions?: number;
  employment_type?: string; status: string; expand?: { owner?: { name?: string; business_name?: string; email?: string } };
};

type Candidate = {
  id: string; created: string; jd: string; name: string; email?: string; phone?: string;
  resume?: string; experience?: string; skills?: string; status: string; interview_notes?: string;
};

const STATUSES = ['Shortlisted', 'Rejected', 'Pending Interview', 'Selected', 'Hired'] as const;

export function AdminHire() {
  const revalidator = useRevalidator();
  const [jds, setJds] = useState<JD[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [addFor, setAddFor] = useState<JD | null>(null);
  const [viewing, setViewing] = useState<JD | null>(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const [jdList, candList] = await Promise.all([
        pb.collection('hire_jds').getFullList<JD>({ sort: '-created', expand: 'owner' }),
        pb.collection('hire_candidates').getFullList<Candidate>({ sort: '-created' }),
      ]);
      setJds(jdList);
      setCandidates(candList);
    } catch { setError('Hiring records couldn’t be loaded.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function addCandidate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!addFor) return;
    setBusy(true); setFormError('');
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    if (!name) { setFormError('Enter a candidate name.'); setBusy(false); return; }
    const resume = form.get('resume') as File | null;
    const values: Record<string, unknown> = {
      jd: addFor.id,
      name,
      email: String(form.get('email') || '').trim(),
      phone: String(form.get('phone') || '').trim(),
      experience: String(form.get('experience') || '').trim(),
      skills: String(form.get('skills') || '').trim(),
      status: String(form.get('status') || 'Pending Interview'),
      interview_notes: '',
    };
    try {
      if (resume && resume.size > 0) {
        const fd = new FormData();
        for (const [k, v] of Object.entries(values)) fd.append(k, String(v));
        fd.append('resume', resume);
        await pb.collection('hire_candidates').create(fd);
      } else {
        await pb.collection('hire_candidates').create(values);
      }
      setAddFor(null); setFormError('');
      void load();
    } catch { setFormError('Couldn’t add the candidate. Try again.'); }
    finally { setBusy(false); }
  }

  async function removeCandidate(id: string) {
    if (!confirm('Remove this candidate permanently?')) return;
    try { await pb.collection('hire_candidates').delete(id); void load(); } catch { alert('Could not remove.'); }
  }

  async function openResume(c: Candidate) {
    if (!c.resume) return;
    try {
      const url = pb.files.getURL(c as never, c.resume);
      const res = await fetch(url, { headers: { Authorization: pb.authStore.token ? `Bearer ${pb.authStore.token}` : '' } });
      if (!res.ok) throw new Error('fetch failed');
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, '_blank');
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } catch { alert('Could not load the resume.'); }
  }

  if (loading) return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading…</p></div>;

  const viewingCandidates = viewing ? candidates.filter((c) => c.jd === viewing.id) : [];

  return (
    <>
      {error && <div className="error-banner" role="alert">{error} <button onClick={load}>Try again</button></div>}

      <div className="page-heading">
        <div><span className="eyebrow">RECRUITMENT</span><h1>Hire Talent<span>.</span></h1><p>Assign candidate profiles and resumes to client job descriptions.</p></div>
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading"><div><h2>Client job descriptions <span className="count-label">{jds.length}</span></h2><p>{candidates.length} candidates assigned across all clients.</p></div></div>
        {jds.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Role</th><th>Client</th><th>Positions</th><th>Candidates</th><th>Selected / Hired</th><th>Status</th><th className="align-right">Actions</th></tr></thead>
              <tbody>
                {jds.map((j) => {
                  const cs = candidates.filter((c) => c.jd === j.id);
                  const selected = cs.filter((c) => c.status === 'Selected' || c.status === 'Hired').length;
                  const owner = j.expand?.owner;
                  return (
                    <tr key={j.id}>
                      <td><strong>{j.job_title}</strong><small>{j.department || '—'}</small></td>
                      <td>{owner?.business_name || owner?.name || owner?.email || '—'}</td>
                      <td>{j.positions || 1}</td>
                      <td>{cs.length}</td>
                      <td>{selected}</td>
                      <td><span className={`status-badge ${j.status === 'Open' ? 'status-complete' : 'status-inactive'}`}><i />{j.status}</span></td>
                      <td>
                        <div className="table-actions">
                          <button className="icon-button table-edit" aria-label="Add candidate" onClick={() => setAddFor(j)}><Plus size={15} /></button>
                          <button className="icon-button table-edit" aria-label="View candidates" onClick={() => setViewing(j)}><Eye size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="large-empty"><Briefcase size={42} strokeWidth={1.3} /><h3>No job descriptions yet.</h3><p>Clients post job descriptions from their workspace. They’ll appear here for candidate assignment.</p></div>
        )}
      </section>

      {/* Add candidate dialog */}
      <Dialog open={!!addFor} onOpenChange={(v) => { if (!busy) { setAddFor(v ? addFor : null); setFormError(''); } }}>
        <DialogContent className="record-dialog payroll-details-dialog">
          {addFor && (
            <>
              <DialogTitle>Assign candidate · {addFor.job_title}<span className="accent-dot">.</span></DialogTitle>
              <DialogDescription>Upload or assign a candidate profile and resume to this job description.</DialogDescription>
              <form onSubmit={addCandidate}>
                <div className="record-fields">
                  <label className="field-wide">Candidate name<span className="required"> *</span><input name="name" maxLength={200} required /></label>
                  <label>Email<input name="email" type="email" maxLength={120} /></label>
                  <label>Phone<input name="phone" maxLength={30} /></label>
                  <label>Experience<input name="experience" maxLength={200} placeholder="e.g. 3 years" /></label>
                  <label>Skills<input name="skills" maxLength={2000} /></label>
                  <label>Status<select name="status" defaultValue="Pending Interview">{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</select></label>
                  <label className="field-wide">Resume (PDF / DOC)<input name="resume" type="file" accept=".pdf,.doc,.docx" /></label>
                </div>
                {formError && <p className="form-error" role="alert">{formError}</p>}
                <div className="dialog-actions">
                  <button className="button button-quiet" type="button" disabled={busy} onClick={() => setAddFor(null)}><X size={16} />Cancel</button>
                  <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Assign candidate'}<ArrowUpRight size={17} /></button>
                </div>
              </form>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* View candidates */}
      <Dialog open={!!viewing} onOpenChange={(v) => { if (!v) setViewing(null); }}>
        <DialogContent className="record-dialog payroll-details-dialog">
          {viewing && (
            <>
              <DialogTitle>{viewing.job_title} — candidates<span className="accent-dot">.</span></DialogTitle>
              <DialogDescription>Statuses shown are set by the client. Upload resumes via the + action on the JD row.</DialogDescription>
              {viewingCandidates.length ? (
                <div className="table-scroll" style={{ marginTop: 16 }}>
                  <table>
                    <thead><tr><th>Candidate</th><th>Experience</th><th>Status</th><th>Resume</th><th>Added</th><th className="align-right">Actions</th></tr></thead>
                    <tbody>
                      {viewingCandidates.map((c) => (
                        <tr key={c.id}>
                          <td><strong>{c.name}</strong><small>{c.email || c.phone || '—'}</small></td>
                          <td>{c.experience || '—'}</td>
                          <td><span className="status-badge status-pending"><i />{c.status}</span></td>
                          <td>{c.resume ? <button className="icon-button table-edit" aria-label="View resume" onClick={() => openResume(c)}><Download size={15} /></button> : '—'}</td>
                          <td className="nowrap">{dateLabel(c.created)}</td>
                          <td className="align-right"><button className="icon-button table-delete" aria-label="Remove" onClick={() => removeCandidate(c.id)}><Trash2 size={15} /></button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div className="compact-empty" style={{ minHeight: 160 }}><Users size={30} strokeWidth={1.4} /><strong>No candidates yet.</strong><p>Use the + action to assign the first candidate.</p></div>}
              <div className="dialog-actions"><button className="button button-quiet" onClick={() => setViewing(null)}>Close</button></div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
