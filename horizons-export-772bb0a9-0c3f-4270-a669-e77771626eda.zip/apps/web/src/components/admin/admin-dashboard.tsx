import { Link } from 'react-router';
import { Users, FileText, MessageSquare, ArrowUpRight, ArrowRight, UserCheck, UserX } from 'lucide-react';
import { dateLabel } from '@/lib/business';
import type { RecordModel } from 'pocketbase';

export function AdminDashboard({ clients, services, messages }: { clients: RecordModel[]; services: RecordModel[]; messages: RecordModel[] }) {
  const members = clients.filter((c) => (c as { role?: string }).role !== 'admin');
  const active = members.filter((c) => c.active);
  const disabled = members.filter((c) => !c.active);
  const published = services.filter((s) => s.published);

  return (
    <>
      <div className="page-heading">
        <div><span className="eyebrow">ADMIN CONSOLE</span><h1>Dashboard<span>.</span></h1><p>Manage clients, services and website content.</p></div>
      </div>
      <div className="summary-cards">
        <div className="summary-card"><div><Users size={18} /> Clients</div><strong>{members.length}</strong><p>{active.length} active · {disabled.length} disabled</p></div>
        <div className="summary-card"><div><FileText size={18} /> Services</div><strong>{published.length}</strong><p>{services.length - published.length} draft(s)</p></div>
        <div className="summary-card"><div><MessageSquare size={18} /> Messages</div><strong>{messages.length}</strong><p>Contact form submissions</p></div>
        <div className="summary-card summary-highlight"><div><UserCheck size={18} /> Active clients</div><strong>{active.length}</strong><p>Can sign in to their workspace</p></div>
      </div>
      <div className="overview-lower">
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2>Recent clients</h2><p>The latest business accounts</p></div><Link to="/admin/clients" className="text-link">View all <ArrowRight size={15} /></Link></div>
          {members.length ? (
            <div className="table-scroll"><table><thead><tr><th>Client</th><th>Email</th><th>Status</th><th>Joined</th></tr></thead><tbody>{members.slice(0, 6).map((c) => (
              <tr key={c.id}><td><strong>{c.name || c.business_name || '—'}</strong><small>{c.business_name || '—'}</small></td><td>{c.email}</td><td>{c.active ? <span className="status-badge status-complete"><i />Active</span> : <span className="status-badge status-inactive"><i />Disabled</span>}</td><td className="nowrap">{dateLabel(c.created)}</td></tr>
            ))}</tbody></table></div>
          ) : <div className="compact-empty"><Users size={30} strokeWidth={1.4} /><strong>No clients yet.</strong><p>Client accounts will appear here once created.</p></div>}
        </section>
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2>Recent messages</h2><p>Latest contact submissions</p></div><Link to="/admin/messages" className="text-link">View all <ArrowRight size={15} /></Link></div>
          {messages.length ? (
            <div className="deadline-list">{messages.slice(0, 5).map((m) => (
              <div key={m.id}><span className="tax-icon"><MessageSquare size={15} /></span><div><strong>{m.name}</strong><small>{m.subject || m.message?.slice(0, 60)} · {dateLabel(m.created)}</small></div></div>
            ))}</div>
          ) : <div className="compact-empty"><MessageSquare size={30} strokeWidth={1.4} /><strong>No messages yet.</strong><p>Contact form submissions will appear here.</p></div>}
        </section>
      </div>
      <div className="workspace-help"><ArrowUpRight size={16} /><span>Use the sidebar to manage clients, edit services and update website content.</span></div>
    </>
  );
}
