import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { Brand } from '@/components/brand';

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  if (location.pathname.startsWith('/app') || location.pathname.startsWith('/admin')) return null;

  return (
    <header className="site-header">
      <div className="header-inner">
        <Brand />
        <nav
          className={open ? 'marketing-nav nav-open' : 'marketing-nav'}
          aria-label="Main navigation"
        >
          <Link to="/about" onClick={() => setOpen(false)}>About Us</Link>
          <Link to="/packages" onClick={() => setOpen(false)}>Packages</Link>
          <Link to="/jobs" onClick={() => setOpen(false)}>Jobs</Link>
          <Link to="/news" onClick={() => setOpen(false)}>News &amp; Finance Updates</Link>
          <Link to="/contact" onClick={() => setOpen(false)}>Contact Us</Link>
        </nav>
        <Link className="header-login" to="/login">Client login <ArrowUpRight size={16} /></Link>
        <button
          className="mobile-menu icon-button"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>
    </header>
  );
}
