import { Link } from 'react-router';
import { ArrowUpRight, ShieldCheck, MapPin, MessageCircle, Mail } from 'lucide-react';
import type { SiteSettings } from '@/lib/services';
import { whatsappLink, defaultSettings } from '@/lib/services';
import { ServiceCta } from '@/components/services/service-cta';

export function AboutPage({ settings }: { settings: SiteSettings }) {
  const s = settings ?? defaultSettings;
  const paragraphs = (s.about_content || '').split('\n').filter(Boolean);
  const wa = whatsappLink(s.whatsapp);

  return (
    <main className="services-page">
      <section className="services-hero">
        <span className="eyebrow"><i className="red-square" /> WHO WE ARE</span>
        <h1>{s.about_title || 'About Easify Ledger'}<span>.</span></h1>
        <p>Accounting, payroll and compliance services for businesses across India — clear, organised and affordable.</p>
      </section>
      <section className="about-body">
        <div className="about-content">
          {paragraphs.map((p, i) => <p key={i}>{p}</p>)}
        </div>
        <aside className="about-side">
          <div className="about-fact"><MapPin size={20} /><div><strong>Location</strong><span>{s.location}</span></div></div>
          <div className="about-fact"><MessageCircle size={20} /><div><strong>WhatsApp / Call</strong><a href={wa} target="_blank" rel="noreferrer">{s.whatsapp}</a></div></div>
          <div className="about-fact"><Mail size={20} /><div><strong>Email</strong><a href={`mailto:${s.email}`}>{s.email}</a></div></div>
          <div className="about-fact"><ShieldCheck size={20} /><div><strong>Privacy</strong><span>Private client workspaces for every business.</span></div></div>
          <Link to="/login?mode=request" className="button button-primary">Sign up <ArrowUpRight size={17} /></Link>
        </aside>
      </section>
      <ServiceCta settings={s} />
    </main>
  );
}
