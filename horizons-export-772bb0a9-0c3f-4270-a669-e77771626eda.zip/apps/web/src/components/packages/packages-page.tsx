import { useState } from 'react';
import { ArrowUpRight, MessageCircle, Check, CheckCircle2, X } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { Package } from '@/lib/content';
import { packageCategories } from '@/lib/content';
import { whatsappLink, defaultSettings } from '@/lib/services';
import type { SiteSettings } from '@/lib/services';

export function PackagesPage({ packages, settings }: { packages: Package[]; settings: SiteSettings }) {
  const [quotePkg, setQuotePkg] = useState<Package | null>(null);
  const s = settings ?? defaultSettings;

  return (
    <main className="services-page">
      <section className="services-hero">
        <span className="eyebrow"><i className="red-square" /> WHAT WE OFFER</span>
        <h1>Packages for every<br />part of your business<span>.</span></h1>
        <p>Tax and statutory compliance, computerized digital accounting, and complete payroll &amp; staff management — organised, affordable and handled end to end. Based in Pune, working with businesses across India.</p>
      </section>

      {packageCategories.map((cat) => {
        const items = packages.filter((p) => p.category === cat.name);
        if (!items.length) return null;
        return (
          <section className="category-card" key={cat.slug}>
            <div className="category-card-head">
              <div>
                <h2>{cat.name}</h2>
                <span className="category-card-sub">{cat.short}</span>
              </div>
            </div>
            <p>{cat.description}</p>
            <div className="package-grid">
              {items.map((pkg) => {
                const wa = whatsappLink(s.whatsapp, `Hi Easify Ledger, I'm interested in your ${pkg.name} package.`);
                return (
                  <article className="package-card" key={pkg.id}>
                    {pkg.image && <div className="package-card-image"><img src={pkg.image} alt={pkg.name} loading="lazy" /></div>}
                    <div className="package-card-body">
                      <h3>{pkg.name}</h3>
                      <p>{pkg.description}</p>
                      {pkg.services?.length > 0 && (
                        <ul className="service-card-features">
                          {pkg.services.map((f) => <li key={f}><Check size={14} />{f}</li>)}
                        </ul>
                      )}
                      <div className="package-actions">
                        <button className="button button-primary button-small" onClick={() => setQuotePkg(pkg)}>{pkg.cta_text || 'Get a Quote'} <ArrowUpRight size={15} /></button>
                        <a href={wa} className="button button-dark button-small" target="_blank" rel="noreferrer"><MessageCircle size={15} /> WhatsApp</a>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        );
      })}

      {quotePkg && <QuoteForm pkg={quotePkg} onClose={() => setQuotePkg(null)} />}
    </main>
  );
}

function QuoteForm({ pkg, onClose }: { pkg: Package; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    const data = {
      name: String(form.get('name') || '').trim(),
      company: String(form.get('company') || '').trim(),
      phone: String(form.get('phone') || '').trim(),
      email: String(form.get('email') || '').trim(),
      package: pkg.name,
      message: String(form.get('message') || '').trim(),
    };
    if (!data.name || !data.phone || !data.email) {
      setError('Please fill in your name, phone and email.');
      setBusy(false);
      return;
    }
    if (!/^[0-9+\-\s]{7,15}$/.test(data.phone)) {
      setError('Please enter a valid phone number.');
      setBusy(false);
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(data.email)) {
      setError('Please enter a valid email address.');
      setBusy(false);
      return;
    }
    try {
      await pb.collection('quote_requests').create(data);
      setDone(true);
    } catch {
      setError('Your request could not be submitted. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="dialog-backdrop" role="dialog" aria-modal="true">
      <form className="record-dialog" onSubmit={submit}>
        {done ? (
          <div className="success-panel" role="status">
            <CheckCircle2 size={32} />
            <h3>Request sent.</h3>
            <p>Thank you for your interest in <strong>{pkg.name}</strong>. Our team will contact you shortly.</p>
            <button className="button button-dark" type="button" onClick={onClose}>Close <ArrowUpRight size={16} /></button>
          </div>
        ) : (
          <>
            <div className="quote-head">
              <div>
                <h2>Get a quote<span className="accent-dot">.</span></h2>
                <p>For <strong>{pkg.name}</strong></p>
              </div>
              <button type="button" className="icon-button" aria-label="Close" onClick={onClose}><X size={18} /></button>
            </div>
            <div className="record-fields">
              <label>Name <span className="required">*</span><input name="name" required maxLength={200} placeholder="Full name" /></label>
              <label>Company name<input name="company" maxLength={200} placeholder="Business name" /></label>
              <label>Phone number <span className="required">*</span><input name="phone" type="tel" required pattern="[0-9+\-\s]{7,15}" placeholder="Phone number" /></label>
              <label>Email address <span className="required">*</span><input name="email" type="email" required placeholder="you@business.com" /></label>
              <label className="field-wide">Selected package<input value={pkg.name} readOnly /></label>
              <label className="field-wide">Message<textarea name="message" rows={3} maxLength={4000} placeholder="Tell us about your business and what you need…" /></label>
            </div>
            {error && <p className="form-error" role="alert">{error}</p>}
            <div className="dialog-actions">
              <button className="button button-quiet" type="button" disabled={busy} onClick={onClose}>Cancel</button>
              <button className="button button-primary" disabled={busy}>{busy ? 'Sending…' : 'Send request'}<ArrowUpRight size={17} /></button>
            </div>
          </>
        )}
      </form>
    </div>
  );
}
