import { Link } from 'react-router';
export function Brand({ light = false }: { light?: boolean }) {
  return <Link to="/" className={`brand ${light ? 'brand-light' : ''}`} aria-label="Easify ledger home"><span><span className="brand-dot">Easify</span> ledger</span></Link>;
}
