import { Link } from 'react-router';
import { ArrowUpRight, MessageCircle, Mail } from 'lucide-react';
import type { SiteSettings } from '@/lib/services';
import { whatsappLink, defaultSettings } from '@/lib/services';

export function ServiceCta({ settings }: { settings: SiteSettings }) {
  const s = settings ?? defaultSettings;
  const wa = whatsappLink(s.whatsapp, "Hi Easify Ledger, I'd like to get started.");
  return (
    <section className="service-cta">
      <div>
        <span className="eyebrow"><i className="red-square" /> GET STARTED</span>
        <h2>Sign up or talk to us<span>.</span></h2>
        <p>Based in Pune, working with businesses across India. Reach out on WhatsApp or email and we’ll take it from there.</p>
      </div>
      <div className="service-cta-actions">
        <Link to="/login?mode=request" className="button button-primary">Sign up <ArrowUpRight size={17} /></Link>
        <a href={wa} className="button button-dark" target="_blank" rel="noreferrer"><MessageCircle size={17} /> {s.whatsapp}</a>
        <a href={`mailto:${s.email}`} className="button button-quiet"><Mail size={17} /> {s.email}</a>
      </div>
    </section>
  );
}
