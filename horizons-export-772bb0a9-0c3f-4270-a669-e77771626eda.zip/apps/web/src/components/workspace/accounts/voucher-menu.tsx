import { useState } from 'react';
import { ChevronDown, Plus, UserPlus, FolderPlus, PackagePlus, BookText, Banknote } from 'lucide-react';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import type { Ledger, Voucher } from '@/lib/accounts';
import { VoucherEditor } from './voucher-editor';
import { LedgerEditor, EntityEditor } from './ledger-editor';

export type MenuSection = 'Sales' | 'Purchase' | 'Expense' | 'BankCash';

type Item = { id: string; label: string; icon: typeof Plus };

const MENU: Record<MenuSection, Item[]> = {
  Sales: [
    { id: 'voucher', label: 'Create Sales Invoice', icon: Plus },
    { id: 'client', label: 'Create Client Ledger', icon: UserPlus },
    { id: 'project', label: 'Create Project / Section', icon: FolderPlus },
    { id: 'item', label: 'Create Goods / Service Item', icon: PackagePlus },
  ],
  Purchase: [
    { id: 'voucher', label: 'Create Purchase Voucher', icon: Plus },
    { id: 'supplier', label: 'Create Supplier Ledger', icon: UserPlus },
    { id: 'project', label: 'Create Project / Section', icon: FolderPlus },
    { id: 'item', label: 'Create Goods / Service Item', icon: PackagePlus },
  ],
  Expense: [
    { id: 'voucher', label: 'Create Expense Voucher', icon: Plus },
    { id: 'expense-ledger', label: 'Create Expense Ledger', icon: BookText },
    { id: 'project', label: 'Create Project / Section', icon: FolderPlus },
    { id: 'item', label: 'Create Goods / Service Item', icon: PackagePlus },
  ],
  BankCash: [
    { id: 'voucher', label: 'Create Bank / Cash Voucher Entry', icon: Plus },
    { id: 'bank-ledger', label: 'Create Bank / Cash Ledger', icon: Banknote },
    { id: 'expense-ledger', label: 'Create Expense Ledger', icon: BookText },
    { id: 'client', label: 'Create Client Ledger', icon: UserPlus },
    { id: 'supplier', label: 'Create Supplier / Creditor Ledger', icon: UserPlus },
  ],
};

const VOUCHER_TYPE: Record<MenuSection, { type: string; choices: string[] }> = {
  Sales: { type: 'Sales', choices: ['Sales'] },
  Purchase: { type: 'Purchase', choices: ['Purchase'] },
  Expense: { type: 'Expense', choices: ['Expense'] },
  BankCash: { type: 'Bank', choices: ['Bank', 'Cash', 'Transfer'] },
};

export function VoucherMenu({
  section, ledgers, vouchers, today, onSaved,
}: { section: MenuSection; ledgers: Ledger[]; vouchers: Voucher[]; today: string; onSaved: () => void }) {
  const [active, setActive] = useState<string | null>(null);
  const items = MENU[section];
  const vt = VOUCHER_TYPE[section];

  function handleSaved() {
    onSaved();
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="button button-dark button-small">
            <Plus size={15} />Create<ChevronDown size={14} />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {items.map((it) => (
            <DropdownMenuItem key={it.id} onClick={() => setActive(it.id)}>
              <it.icon size={15} />{it.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {active === 'voucher' && (
        <VoucherEditor
          key="voucher"
          ledgers={ledgers}
          vouchers={vouchers}
          defaultType={vt.type}
          typeChoices={vt.choices}
          today={today}
          forcedOpen
          hideTrigger
          onSaved={handleSaved}
          onClose={() => setActive(null)}
        />
      )}
      {active === 'client' && (
        <EntityEditor
          kind="party"
          open
          onOpenChange={(v) => { if (!v) setActive(null); }}
          onSaved={(l) => { setActive(null); onSaved(); }}
        />
      )}
      {active === 'supplier' && (
        <EntityEditor
          kind="party"
          subgroupOverride="Supplier Outstanding"
          open
          onOpenChange={(v) => { if (!v) setActive(null); }}
          onSaved={(l) => { setActive(null); onSaved(); }}
        />
      )}
      {active === 'project' && (
        <EntityEditor
          kind="project"
          open
          onOpenChange={(v) => { if (!v) setActive(null); }}
          onSaved={(l) => { setActive(null); onSaved(); }}
        />
      )}
      {active === 'item' && (
        <EntityEditor
          kind="item"
          open
          onOpenChange={(v) => { if (!v) setActive(null); }}
          onSaved={(l) => { setActive(null); onSaved(); }}
        />
      )}
      {active === 'expense-ledger' && (
        <LedgerEditor
          forcedOpen
          defaultGroup="Expenses"
          defaultSubgroup="Indirect Expenses"
          onSaved={(l) => { setActive(null); onSaved(); }}
          onClose={() => setActive(null)}
        />
      )}
      {active === 'bank-ledger' && (
        <LedgerEditor
          forcedOpen
          defaultGroup="Assets"
          defaultSubgroup="Bank & Cash"
          onSaved={(l) => { setActive(null); onSaved(); }}
          onClose={() => setActive(null)}
        />
      )}
    </>
  );
}
