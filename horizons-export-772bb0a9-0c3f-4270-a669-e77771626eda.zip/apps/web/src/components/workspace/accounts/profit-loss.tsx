import { useState } from 'react';
import { ArrowRight, ChevronLeft, TrendingUp, TrendingDown, Wallet, FileText, ArrowUpRight } from 'lucide-react';
import type { Ledger, Voucher } from '@/lib/accounts';
import {
  profitAndLoss, vendorOutstanding, projectBreakdown, ledgerBalance,
  vouchersForLedger, movementInVoucher, money, dateLabel,
} from '@/lib/accounts';
import { VoucherDetail } from './voucher-detail';

export function ProfitLoss({
  ledgers, vouchers, today,
}: { ledgers: Ledger[]; vouchers: Voucher[]; today: string }) {
  const [view, setView] = useState<'summary' | 'ledger' | 'voucher'>('summary');
  const [activeLedger, setActiveLedger] = useState<Ledger | null>(null);
  const [activeVoucher, setActiveVoucher] = useState<Voucher | null>(null);

  const pnl = profitAndLoss(ledgers, vouchers);
  const outstanding = vendorOutstanding(ledgers, vouchers);
  const projects = projectBreakdown(ledgers, vouchers);

  const expenseLedgers = ledgers
    .filter((l) => l.group === 'Expenses')
    .map((l) => ({ ledger: l, balance: ledgerBalance(l, vouchers) }))
    .filter((x) => x.balance !== 0)
    .sort((a, b) => b.balance - a.balance);

  const incomeLedgers = ledgers
    .filter((l) => l.group === 'Income')
    .map((l) => ({ ledger: l, balance: ledgerBalance(l, vouchers) }))
    .filter((x) => x.balance !== 0)
    .sort((a, b) => b.balance - a.balance);

  function openLedger(ledger: Ledger) {
    setActiveLedger(ledger);
    setView('ledger');
  }
  function openVoucher(v: Voucher) {
    setActiveVoucher(v);
    setView('voucher');
  }

  if (view === 'voucher' && activeVoucher) {
    return (
      <VoucherDetail
        voucher={activeVoucher}
        ledgers={ledgers}
        today={today}
        onBack={() => { setView('ledger'); setActiveVoucher(null); }}
      />
    );
  }

  if (view === 'ledger' && activeLedger) {
    const list = vouchersForLedger(activeLedger.id, vouchers);
    return (
      <>
        <div className="page-heading">
          <div>
            <button className="text-link" onClick={() => { setView('summary'); setActiveLedger(null); }}>
              <ChevronLeft size={15} />Back to P&L
            </button>
            <h1 style={{ marginTop: 12 }}>{activeLedger.name}<span>.</span></h1>
            <p>{activeLedger.group} · {activeLedger.subgroup} · Balance {money(ledgerBalance(activeLedger, vouchers))}</p>
          </div>
        </div>
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div><h2>Vouchers in this ledger <span className="count-label">{list.length}</span></h2><p>Every entry that touched this account.</p></div>
          </div>
          {list.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Counterparty</th><th className="align-right">Movement</th><th className="align-right">Open</th></tr></thead>
                <tbody>
                  {list.map((v) => {
                    const move = movementInVoucher(activeLedger.id, v);
                    return (
                      <tr key={v.id}>
                        <td className="nowrap">{dateLabel(v.date)}</td>
                        <td><span className="type-label">{v.type}</span></td>
                        <td><strong>{v.reference || '—'}</strong></td>
                        <td>{v.counterparty || '—'}</td>
                        <td className={`align-right amount-cell ${move >= 0 ? 'income-amount' : ''}`}>{move >= 0 ? '+' : '−'}{money(Math.abs(move))}</td>
                        <td className="align-right"><button className="icon-button table-edit" onClick={() => openVoucher(v)} aria-label="Open voucher"><ArrowUpRight size={16} /></button></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="large-empty"><FileText size={42} strokeWidth={1.3} /><h3>No vouchers yet.</h3><p>Record a transaction that uses this ledger to see entries here.</p></div>
          )}
        </section>
      </>
    );
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">PROFIT & LOSS</span>
          <h1>Income, expenses & profit<span>.</span></h1>
          <p>Total sales, total expenses and your bottom line — with a project-wise breakdown.</p>
        </div>
      </div>

      <div className="summary-cards">
        <div className="summary-card">
          <div><TrendingUp size={17} />Total sales</div>
          <strong>{money(pnl.income)}</strong>
          <p>All income recorded across sales & other income ledgers</p>
        </div>
        <div className="summary-card">
          <div><TrendingDown size={17} />Total expenses</div>
          <strong>{money(pnl.expenses)}</strong>
          <p>All direct & indirect expenses recorded</p>
        </div>
        <div className={`summary-card ${pnl.isProfit ? 'summary-profit' : 'summary-loss'}`}>
          <div>{pnl.isProfit ? <TrendingUp size={17} /> : <TrendingDown size={17} />}{pnl.isProfit ? 'Net profit' : 'Net loss'}</div>
          <strong>{money(Math.abs(pnl.profit))}</strong>
          <p>{pnl.isProfit ? 'Your business is profitable' : 'Expenses exceed income'}</p>
        </div>
        <div className="summary-card">
          <div><Wallet size={17} />Outstanding vendor payments</div>
          <strong>{money(outstanding)}</strong>
          <p>Unpaid supplier balances owed</p>
        </div>
      </div>

      <section className="dashboard-panel" style={{ marginBottom: 21 }}>
        <div className="panel-heading">
          <div><h2>Project / section-wise P&L</h2><p>Income, expenses, profit and receivables for each project.</p></div>
        </div>
        {projects.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Project</th><th className="align-right">Income</th><th className="align-right">Expenses</th><th className="align-right">Profit</th><th className="align-right">Outstanding</th></tr></thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.project}>
                    <td><strong>{p.project}</strong></td>
                    <td className="align-right income-amount">{money(p.income)}</td>
                    <td className="align-right amount-cell">{money(p.expenses)}</td>
                    <td className={`align-right amount-cell ${p.profit >= 0 ? 'income-amount' : 'summary-loss-text'}`}>{money(p.profit)}</td>
                    <td className="align-right">{money(p.outstanding)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="compact-empty"><FileText size={30} strokeWidth={1.4} /><strong>No projects tagged yet.</strong><p>Tag vouchers with a project name to see a section-wise breakdown here.</p></div>
        )}
      </section>

      <div className="overview-lower">
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div><h2>Expense breakdown</h2><p>Click an expense to see every voucher behind it.</p></div>
          </div>
          {expenseLedgers.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Ledger</th><th>Sub-group</th><th className="align-right">Amount</th><th className="align-right">Open</th></tr></thead>
                <tbody>
                  {expenseLedgers.map(({ ledger, balance }) => (
                    <tr key={ledger.id} className="drill-row">
                      <td><strong>{ledger.name}</strong></td>
                      <td>{ledger.subgroup}</td>
                      <td className="align-right amount-cell">{money(balance)}</td>
                      <td className="align-right"><button className="icon-button table-edit" onClick={() => openLedger(ledger)} aria-label={`Open ${ledger.name}`}><ArrowRight size={16} /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="compact-empty"><TrendingDown size={30} strokeWidth={1.4} /><strong>No expenses recorded.</strong><p>Record an expense voucher to build your P&L.</p></div>
          )}
        </section>
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div><h2>Income breakdown</h2><p>Click an income ledger to drill into its vouchers.</p></div>
          </div>
          {incomeLedgers.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Ledger</th><th>Sub-group</th><th className="align-right">Amount</th><th className="align-right">Open</th></tr></thead>
                <tbody>
                  {incomeLedgers.map(({ ledger, balance }) => (
                    <tr key={ledger.id} className="drill-row">
                      <td><strong>{ledger.name}</strong></td>
                      <td>{ledger.subgroup}</td>
                      <td className="align-right income-amount">{money(balance)}</td>
                      <td className="align-right"><button className="icon-button table-edit" onClick={() => openLedger(ledger)} aria-label={`Open ${ledger.name}`}><ArrowRight size={16} /></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="compact-empty"><TrendingUp size={30} strokeWidth={1.4} /><strong>No income recorded.</strong><p>Record a sales invoice to build your P&L.</p></div>
          )}
        </section>
      </div>
    </>
  );
}
