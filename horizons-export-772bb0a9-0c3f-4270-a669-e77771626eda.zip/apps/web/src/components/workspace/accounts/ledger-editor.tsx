import { useEffect, useState } from 'react';
import { Plus, Pencil, BookText, ArrowUpRight, UserPlus, FolderPlus, PackagePlus, Layers, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { DEFAULT_LEDGERS, LEDGER_GROUPS, SUBGROUPS, KIND_DEFAULTS, type LedgerGroup } from '@/data/accounts';
import type { Ledger, LedgerKind, BillWiseOpening, OpeningNature, CustomSubgroup } from '@/lib/accounts';
import { openingTotal } from '@/lib/accounts';

export function LedgerEditor({
  ledger,
  compact,
  forcedOpen,
  hideTrigger,
  small,
  defaultGroup,
  defaultSubgroup,
  onSaved,
  onClose,
}: {
  ledger?: Ledger;
  compact?: boolean;
  forcedOpen?: boolean;
  hideTrigger?: boolean;
  small?: boolean;
  defaultGroup?: LedgerGroup;
  defaultSubgroup?: string;
  onSaved?: (ledger: Ledger) => void;
  onClose?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [group, setGroup] = useState<LedgerGroup>(ledger?.group || defaultGroup || 'Assets');
  const [customSubs, setCustomSubs] = useState<CustomSubgroup[]>([]);
  const [creatingSub, setCreatingSub] = useState(false);
  const [newSubName, setNewSubName] = useState('');
  const [subError, setSubError] = useState('');

  // Opening balance state
  const [openingMode, setOpeningMode] = useState<'single' | 'billwise'>(
    ledger?.bill_wise_opening?.length ? 'billwise' : 'single',
  );
  const [openingAmount, setOpeningAmount] = useState(String(ledger?.opening_balance || 0));
  const [openingNature, setOpeningNature] = useState<OpeningNature>(ledger?.opening_balance_nature || (ledger && (ledger.group === 'Assets' || ledger.group === 'Expenses') ? 'debit' : 'credit'));
  const [openingDate, setOpeningDate] = useState(ledger?.opening_balance_date || '');
  const [bills, setBills] = useState<BillWiseOpening[]>(ledger?.bill_wise_opening || []);

  useEffect(() => {
    if (forcedOpen) setOpen(true);
  }, [forcedOpen]);

  useEffect(() => {
    let active = true;
    pb.collection('custom_subgroups')
      .getFullList<CustomSubgroup>({ sort: 'name' })
      .then((list) => { if (active) setCustomSubs(list); })
      .catch(() => {});
    return () => { active = false; };
  }, [open, creatingSub]);

  const subgroups = Array.from(new Set([...SUBGROUPS[group], ...customSubs.filter((s) => s.group === group).map((s) => s.name)]));

  async function createSubgroup() {
    const name = newSubName.trim();
    if (!name) { setSubError('Enter a subgroup name.'); return; }
    if (subgroups.some((s) => s.toLowerCase() === name.toLowerCase())) {
      setSubError('A subgroup with this name already exists under this group.');
      return;
    }
    setBusy(true);
    setSubError('');
    try {
      const rec = await pb.collection('custom_subgroups').create({ group, name, owner: pb.authStore.record?.id });
      setCustomSubs((prev) => [...prev, rec as CustomSubgroup]);
      setNewSubName('');
      setCreatingSub(false);
      // Pre-select the new subgroup by setting it on the form after render.
      setTimeout(() => {
        const sel = document.querySelector<HTMLSelectElement>('select[name="subgroup"]');
        if (sel) sel.value = name;
      }, 0);
    } catch {
      setSubError('Couldn’t create the subgroup. It may already exist.');
    } finally {
      setBusy(false);
    }
  }

  function addBill() {
    setBills((prev) => [...prev, { date: '', reference: '', amount: 0, nature: openingNature }]);
  }
  function updateBill(index: number, patch: Partial<BillWiseOpening>) {
    setBills((prev) => prev.map((b, i) => (i === index ? { ...b, ...patch } : b)));
  }
  function removeBill(index: number) {
    setBills((prev) => prev.filter((_, i) => i !== index));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    if (!name) { setError('Please enter a ledger name.'); setBusy(false); return; }
    const subgroup = String(form.get('subgroup') || '');
    if (!subgroup) { setError('Please select a sub-group.'); setBusy(false); return; }

    const values: Record<string, unknown> = {
      name,
      group,
      subgroup,
      opening_balance: openingMode === 'single' ? Number(openingAmount || 0) : 0,
      opening_balance_date: openingMode === 'single' ? openingDate : '',
      opening_balance_nature: openingMode === 'single' ? openingNature : '',
      bill_wise_opening: openingMode === 'billwise' ? bills : [],
      project: String(form.get('project') || '').trim(),
      kind: 'account' as LedgerKind,
    };
    try {
      let rec: Ledger;
      if (ledger) { rec = (await pb.collection('ledgers').update(ledger.id, values)) as Ledger; }
      else { rec = (await pb.collection('ledgers').create({ ...values, owner: pb.authStore.record?.id })) as Ledger; }
      setOpen(false);
      onSaved?.(rec);
    } catch {
      setError('This ledger couldn’t be saved. Try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!busy) {
          setOpen(value);
          setError('');
          if (value && ledger) setGroup(ledger.group);
          if (value && !ledger && defaultGroup) setGroup(defaultGroup);
          if (!value) onClose?.();
        }
      }}
    >
      <button
        onClick={() => setOpen(true)}
        className={ledger ? 'icon-button table-edit' : compact ? 'button button-small button-dark' : small ? 'button button-quiet button-small' : 'button button-quiet'}
        aria-label={ledger ? `Edit ${ledger.name}` : 'Create ledger'}
        style={hideTrigger ? { display: 'none' } : undefined}
      >
        {ledger ? <Pencil size={15} /> : (<><BookText size={16} />Create ledger</>)}
      </button>
      <DialogContent className="record-dialog">
        <DialogTitle>
          {ledger ? 'Edit' : 'New'} ledger<span className="accent-dot">.</span>
        </DialogTitle>
        <DialogDescription>
          Create an account in your chart of accounts — like Tally. Double-entry: every voucher debits one ledger and credits another.
        </DialogDescription>
        <form onSubmit={save}>
          <div className="record-fields">
            <label className="field-wide">
              Ledger name<span className="required"> *</span>
              <input name="name" defaultValue={ledger?.name || ''} maxLength={200} required />
            </label>
            <label>
              Account group<span className="required"> *</span>
              <select name="group" value={group} onChange={(e) => setGroup(e.target.value as LedgerGroup)} disabled={!!defaultGroup}>
                {LEDGER_GROUPS.map((g) => (<option key={g} value={g}>{g}</option>))}
              </select>
            </label>
            <label>
              Sub-group<span className="required"> *</span>
              <div className="subgroup-control">
                <select key={group} name="subgroup" defaultValue={ledger?.subgroup || defaultSubgroup || subgroups[0]}>
                  {subgroups.map((s) => (<option key={s} value={s}>{s}</option>))}
                </select>
                <button type="button" className="icon-button subgroup-add" onClick={() => setCreatingSub((v) => !v)} aria-label="Create sub group"><Layers size={15} /></button>
              </div>
            </label>
            {creatingSub && (
              <div className="field-wide subgroup-create">
                <input value={newSubName} onChange={(e) => setNewSubName(e.target.value)} placeholder={`New sub-group under ${group}`} maxLength={200} />
                <button type="button" className="button button-dark button-small" onClick={createSubgroup} disabled={busy}><Plus size={14} />Add</button>
              </div>
            )}
            {subError && <p className="form-error field-wide" role="alert">{subError}</p>}
            <label>
              Project / section
              <input name="project" defaultValue={ledger?.project || ''} maxLength={200} placeholder="Optional" />
            </label>
          </div>

          {/* Opening balance section — hidden for expense ledgers, which do not carry an opening balance. */}
          {group !== 'Expenses' && (
          <div className="opening-balance-section">
            <div className="sale-type-toggle">
              <span className="sale-type-label">Opening balance</span>
              <div className="sale-type-options">
                <button type="button" className={openingMode === 'single' ? 'active' : ''} onClick={() => setOpeningMode('single')}>Single</button>
                <button type="button" className={openingMode === 'billwise' ? 'active' : ''} onClick={() => setOpeningMode('billwise')}>Bill-wise</button>
              </div>
            </div>
            {openingMode === 'single' ? (
              <div className="record-fields">
                <label>
                  Amount (₹)
                  <input type="number" step="0.01" min={0} value={openingAmount} onChange={(e) => setOpeningAmount(e.target.value)} />
                </label>
                <label>
                  Nature
                  <select value={openingNature} onChange={(e) => setOpeningNature(e.target.value as OpeningNature)}>
                    <option value="debit">Debit</option>
                    <option value="credit">Credit</option>
                  </select>
                </label>
                <label>
                  Opening balance date
                  <input type="date" value={openingDate} onChange={(e) => setOpeningDate(e.target.value)} />
                </label>
              </div>
            ) : (
              <div className="bill-wise">
                {bills.map((bill, index) => (
                  <div className="bill-row" key={index}>
                    <input type="date" value={bill.date || ''} onChange={(e) => updateBill(index, { date: e.target.value })} />
                    <input value={bill.reference || ''} onChange={(e) => updateBill(index, { reference: e.target.value })} placeholder="Invoice / ref no." />
                    <input type="number" step="0.01" min={0} value={bill.amount || ''} onChange={(e) => updateBill(index, { amount: Number(e.target.value) })} placeholder="Amount" />
                    <select value={bill.nature} onChange={(e) => updateBill(index, { nature: e.target.value as OpeningNature })}>
                      <option value="debit">Dr</option>
                      <option value="credit">Cr</option>
                    </select>
                    <button type="button" className="icon-button table-delete" onClick={() => removeBill(index)} aria-label="Remove bill"><Trash2 size={14} /></button>
                  </div>
                ))}
                <button type="button" className="button button-quiet button-small voucher-add-row" onClick={addBill}><Plus size={14} />Add bill</button>
                <div className="bill-wise-total">Total opening balance: <strong>{money(openingTotal({ bill_wise_opening: bills }))}</strong></div>
              </div>
            )}
          </div>)}

          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="dialog-actions">
            <button className="button button-quiet" type="button" disabled={busy} onClick={() => setOpen(false)}>Cancel</button>
            <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save ledger'}<ArrowUpRight size={17} /></button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

const money = (value: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value || 0);

const KIND_LABEL: Record<string, string> = {
  party: 'counterparty',
  project: 'project / section',
  item: 'item / service',
};

const KIND_ICON: Record<string, typeof UserPlus> = {
  party: UserPlus,
  project: FolderPlus,
  item: PackagePlus,
};

/**
 * Controlled master-record creator for party / project / item ledgers.
 * The group + subgroup are auto-assigned from KIND_DEFAULTS (or an override)
 * so the master lands in the right accounting bucket.
 */
export function EntityEditor({
  kind,
  subgroupOverride,
  open,
  onOpenChange,
  onSaved,
}: {
  kind: LedgerKind;
  subgroupOverride?: string;
  open: boolean;
  onOpenChange: (value: boolean) => void;
  onSaved: (ledger: Ledger) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const defaults = KIND_DEFAULTS[kind];
  const subgroup = subgroupOverride || defaults.subgroup;
  const Icon = KIND_ICON[kind];
  const showOpening = kind === 'party' || kind === 'project';
  const [openingAmount, setOpeningAmount] = useState('0');
  const [openingNature, setOpeningNature] = useState<OpeningNature>(
    defaults.group === 'Assets' || defaults.group === 'Expenses' ? 'debit' : 'credit',
  );
  const [openingDate, setOpeningDate] = useState('');

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    if (!name) { setError('Please enter a name.'); setBusy(false); return; }
    const values: Record<string, unknown> = {
      name,
      group: defaults.group,
      subgroup,
      kind,
      opening_balance: showOpening ? Number(openingAmount || 0) : 0,
      opening_balance_nature: showOpening ? openingNature : '',
      opening_balance_date: showOpening ? openingDate : '',
    };
    if (kind === 'party') {
      values.address = String(form.get('address') || '').trim();
      values.gstin = String(form.get('gstin') || '').trim();
      values.pan = String(form.get('pan') || '').trim();
      values.bank_details = String(form.get('bank_details') || '').trim();
      values.account_number = String(form.get('account_number') || '').trim();
      values.ifsc = String(form.get('ifsc') || '').trim().toUpperCase();
      values.phone = String(form.get('phone') || '').trim();
      values.email = String(form.get('email') || '').trim();
    } else if (kind === 'item') {
      values.item_code = String(form.get('item_code') || '').trim();
      values.hsn_code = String(form.get('hsn_code') || '').trim();
      values.gst_rate = Number(form.get('gst_rate') || 0);
      values.unit = String(form.get('unit') || '').trim();
    }
    try {
      const rec = await pb.collection('ledgers').create({ ...values, owner: pb.authStore.record?.id });
      onSaved(rec as Ledger);
      onOpenChange(false);
    } catch {
      setError('This couldn’t be saved. Try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!busy) { onOpenChange(v); setError(''); } }}>
      <DialogContent className="record-dialog">
        <DialogTitle>
          <Icon size={18} /> New {KIND_LABEL[kind]}<span className="accent-dot">.</span>
        </DialogTitle>
        <DialogDescription>
          {kind === 'party' && 'Create a customer / supplier master so it appears in the party dropdown and avoids duplicate entries.'}
          {kind === 'project' && 'Create a project or section to tag invoices and track project-wise profit.'}
          {kind === 'item' && 'Create an item or service master so it appears in the item dropdown and avoids duplicate entries.'}
        </DialogDescription>
        <form onSubmit={save}>
          <div className="record-fields">
            <label className="field-wide">
              {kind === 'party' ? 'Counterparty name' : kind === 'project' ? 'Project / section name' : 'Item / service name'}<span className="required"> *</span>
              <input name="name" autoFocus maxLength={200} required />
            </label>
            {kind === 'party' && (
              <>
                <label className="field-wide"><span>Address</span><input name="address" maxLength={500} /></label>
                <label><span>GST No</span><input name="gstin" maxLength={15} /></label>
                <label><span>PAN No</span><input name="pan" maxLength={10} /></label>
                <label className="field-wide"><span>Bank name</span><input name="bank_details" maxLength={200} placeholder="Bank name" /></label>
                <label><span>Account number</span><input name="account_number" maxLength={40} /></label>
                <label><span>IFSC code</span><input name="ifsc" maxLength={11} /></label>
                <label><span>Phone no</span><input name="phone" maxLength={30} /></label>
                <label><span>Email ID</span><input name="email" type="email" maxLength={120} /></label>
              </>
            )}
            {kind === 'item' && (
              <>
                <label><span>Item code</span><input name="item_code" maxLength={100} /></label>
                <label><span>HSN / SAC code</span><input name="hsn_code" maxLength={15} /></label>
                <label><span>Default GST rate (%)</span><input name="gst_rate" type="number" step="0.01" min={0} defaultValue={0} /></label>
                <label><span>Unit</span><input name="unit" maxLength={30} placeholder="Nos, Kg, Hr…" /></label>
              </>
            )}
          </div>

          {showOpening && (
            <div className="opening-balance-section">
              <div className="sale-type-toggle">
                <span className="sale-type-label">Opening balance</span>
              </div>
              <div className="record-fields">
                <label>
                  Amount (₹)
                  <input type="number" step="0.01" min={0} value={openingAmount} onChange={(e) => setOpeningAmount(e.target.value)} />
                </label>
                <label>
                  Nature
                  <select value={openingNature} onChange={(e) => setOpeningNature(e.target.value as OpeningNature)}>
                    <option value="debit">Debit</option>
                    <option value="credit">Credit</option>
                  </select>
                </label>
                <label>
                  Opening balance date
                  <input type="date" value={openingDate} onChange={(e) => setOpeningDate(e.target.value)} />
                </label>
              </div>
            </div>
          )}

          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="dialog-actions">
            <button className="button button-quiet" type="button" disabled={busy} onClick={() => onOpenChange(false)}>Cancel</button>
            <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : `Save ${KIND_LABEL[kind]}`}<ArrowUpRight size={17} /></button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function SeedLedgers({ onDone }: { onDone: () => void }) {
  const [busy, setBusy] = useState(false);
  async function seed() {
    setBusy(true);
    try {
      await Promise.all(
        DEFAULT_LEDGERS.map((l, i) =>
          pb.collection('ledgers').create(
            { ...l, opening_balance: 0, kind: 'account', owner: pb.authStore.record?.id },
            { requestKey: `seed-ledger-${i}` },
          ),
        ),
      );
      onDone();
    } catch {
      /* ignore */
    } finally {
      setBusy(false);
    }
  }
  return (
    <button className="button button-dark button-small" onClick={seed} disabled={busy}>
      <Plus size={16} />{busy ? 'Adding…' : 'Add sample ledgers'}
    </button>
  );
}

/**
 * Standalone sub-group creator. Reuses the same `custom_subgroups` collection
 * and validation as the inline subgroup control inside the ledger editor, so
 * a sub-group created here is immediately available in every ledger form.
 */
export function SubgroupEditor({
  forcedOpen,
  hideTrigger,
  onSaved,
  onClose,
}: {
  forcedOpen?: boolean;
  hideTrigger?: boolean;
  onSaved?: () => void;
  onClose?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [group, setGroup] = useState<LedgerGroup>('Assets');
  const [name, setName] = useState('');

  useEffect(() => {
    if (forcedOpen) setOpen(true);
  }, [forcedOpen]);

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) { setError('Enter a subgroup name.'); return; }
    setBusy(true);
    setError('');
    try {
      await pb.collection('custom_subgroups').create({ group, name: trimmed, owner: pb.authStore.record?.id });
      setOpen(false);
      setName('');
      onSaved?.();
    } catch {
      setError('Couldn’t create the subgroup. It may already exist under this group.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!busy) {
          setOpen(value);
          setError('');
          if (!value) onClose?.();
        }
      }}
    >
      <button
        onClick={() => setOpen(true)}
        className="button button-quiet button-small"
        aria-label="Create sub group"
        style={hideTrigger ? { display: 'none' } : undefined}
      >
        <Layers size={15} />Create sub group
      </button>
      <DialogContent className="record-dialog">
        <DialogTitle>
          New sub-group<span className="accent-dot">.</span>
        </DialogTitle>
        <DialogDescription>
          Create a sub-group under an account group. It appears in the sub-group dropdown of every ledger form.
        </DialogDescription>
        <form onSubmit={save}>
          <div className="record-fields">
            <label>
              Account group<span className="required"> *</span>
              <select value={group} onChange={(e) => setGroup(e.target.value as LedgerGroup)}>
                {LEDGER_GROUPS.map((g) => (<option key={g} value={g}>{g}</option>))}
              </select>
            </label>
            <label className="field-wide">
              Sub-group name<span className="required"> *</span>
              <input value={name} onChange={(e) => setName(e.target.value)} maxLength={200} autoFocus required placeholder="e.g. Vehicle Loans" />
            </label>
          </div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="dialog-actions">
            <button className="button button-quiet" type="button" disabled={busy} onClick={() => setOpen(false)}>Cancel</button>
            <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save sub-group'}<ArrowUpRight size={17} /></button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
