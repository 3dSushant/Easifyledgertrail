import { useState } from 'react';
import { ChevronLeft, FileText, Pencil, Package, Download } from 'lucide-react';
import { useOutletContext } from 'react-router';
import type { Ledger, Voucher } from '@/lib/accounts';
import { money, dateLabel } from '@/lib/accounts';
import { downloadInvoicePdf } from '@/lib/invoice-pdf';
import type { CompanyProfile, WorkspaceData } from '@/lib/business';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { VoucherEditor } from './voucher-editor';

export function VoucherDetail({
  voucher, ledgers, onBack, today,
}: {
  voucher: Voucher; ledgers: Ledger[]; onBack: () => void; today: string;
}) {
  const { user } = useOutletContext<WorkspaceData>();
  const [pdfBusy, setPdfBusy] = useState(false);
  const totalDebit = (voucher.entries || []).reduce((s, e) => s + Number(e.debit || 0), 0);
  const totalCredit = (voucher.entries || []).reduce((s, e) => s + Number(e.credit || 0), 0);
  const counterparty = ledgers.find((l) => l.id === voucher.counterparty_ledger);

  const logoFilename = (user as { logo?: string }).logo;
  const profile: CompanyProfile = {
    business_name: user.business_name,
    business_address: user.business_address,
    gstin: user.gstin,
    pan: (user as { pan?: string }).pan,
    bank_name: (user as { bank_name?: string }).bank_name,
    account_number: (user as { account_number?: string }).account_number,
    ifsc: (user as { ifsc?: string }).ifsc,
    upi_id: (user as { upi_id?: string }).upi_id,
    licenses: (user as { licenses?: string }).licenses,
    email: user.email,
    phone: (user as { phone?: string }).phone,
    logo: logoFilename ? pb.files.getUrl(user, logoFilename) : undefined,
  };

  async function exportPdf() {
    setPdfBusy(true);
    try {
      await downloadInvoicePdf(voucher, profile, counterparty, voucher.type === 'Purchase' ? 'purchase' : 'sales');
    } finally {
      setPdfBusy(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <button className="text-link" onClick={onBack}><ChevronLeft size={15} />Back</button>
          <h1 style={{ marginTop: 12 }}>{voucher.type} voucher<span>.</span></h1>
          <p>{dateLabel(voucher.date)} · {voucher.reference || 'No reference'} · {voucher.counterparty || '—'}{voucher.project ? ` · ${voucher.project}` : ''}</p>
        </div>
        <div className="heading-actions">
          {(voucher.type === 'Sales' || voucher.type === 'Purchase') && (
            <button className="button button-dark button-small" onClick={exportPdf} disabled={pdfBusy}>
              <Download size={15} />{pdfBusy ? 'Preparing…' : voucher.type === 'Purchase' ? 'Download purchase PDF' : 'Download invoice PDF'}
            </button>
          )}
          <VoucherEditor ledgers={ledgers} voucher={voucher} today={today} />
        </div>
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading">
          <div><h2><FileText size={16} /> Double-entry detail</h2><p>Every debit has a matching credit.</p></div>
        </div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>Ledger</th><th>Group</th><th className="align-right">Debit</th><th className="align-right">Credit</th></tr></thead>
            <tbody>
              {(voucher.entries || []).map((e, i) => (
                <tr key={i}>
                  <td><strong>{e.ledgerName || ledgers.find((l) => l.id === e.ledger)?.name || '—'}</strong></td>
                  <td>{e.ledgerGroup || '—'}</td>
                  <td className="align-right amount-cell">{e.debit ? money(e.debit) : '—'}</td>
                  <td className="align-right income-amount">{e.credit ? money(e.credit) : '—'}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={2}><strong>Total</strong></td>
                <td className="align-right amount-cell"><strong>{money(totalDebit)}</strong></td>
                <td className="align-right income-amount"><strong>{money(totalCredit)}</strong></td>
              </tr>
            </tfoot>
          </table>
        </div>
        {voucher.notes && <p className="small-note" style={{ padding: '0 22px 18px' }}>{voucher.notes}</p>}
      </section>

      {voucher.items && voucher.items.length > 0 && (
        <section className="dashboard-panel" style={{ marginTop: 21 }}>
          <div className="panel-heading">
            <div><h2><Package size={16} /> Invoice items</h2><p>{voucher.sale_type === 'service' ? 'Service sale' : 'Goods sale'}{voucher.credit_days ? ` · Credit ${voucher.credit_days} days` : ''}</p></div>
          </div>
          <div className="table-scroll">
            <table>
              <thead><tr><th>Item / service</th><th>Code</th><th>HSN</th><th>Qty</th><th className="align-right">Rate</th>{voucher.sale_type === 'goods' && <th className="align-right">Disc %</th>}<th className="align-right">GST %</th><th className="align-right">Amount</th><th className="align-right">GST</th></tr></thead>
              <tbody>
                {voucher.items.map((it, i) => (
                  <tr key={i}>
                    <td><strong>{it.itemName || '—'}</strong></td>
                    <td>{it.item_code || '—'}</td>
                    <td>{it.hsn || '—'}</td>
                    <td>{voucher.sale_type === 'service' ? (it.qtyText || '—') : (it.qty ?? '—')}</td>
                    <td className="align-right">{it.rate != null ? money(it.rate) : '—'}</td>
                    {voucher.sale_type === 'goods' && <td className="align-right">{it.discount ?? 0}</td>}
                    <td className="align-right">{it.gst_rate ?? 0}</td>
                    <td className="align-right amount-cell">{money(it.amount)}</td>
                    <td className="align-right amount-cell">{money(it.gst_amount)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={voucher.sale_type === 'goods' ? 7 : 6}><strong>Total</strong></td>
                  <td className="align-right amount-cell"><strong>{money(voucher.items.reduce((s, i) => s + i.amount, 0))}</strong></td>
                  <td className="align-right amount-cell"><strong>{money(voucher.items.reduce((s, i) => s + i.gst_amount, 0))}</strong></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>
      )}
    </>
  );
}
