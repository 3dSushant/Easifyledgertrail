import { useState } from 'react';
import { useOutletContext } from 'react-router';
import { BarChart3, Scale, ReceiptText, FileBarChart, BookText, GitCompareArrows, Package } from 'lucide-react';
import type { WorkspaceData } from '@/lib/business';
import { useAccounts } from './use-accounts';
import { ProfitLoss } from './profit-loss';
import { BalanceSheet } from './balance-sheet';
import { RecordTransaction } from './record-transaction';
import { Reports } from './reports';
import { TrialBalance } from './trial-balance';
import { Inventory } from './inventory';
import { LedgerEditor, SeedLedgers } from './ledger-editor';
// Create-ledger / create-voucher actions live only in the Record Transaction tab.

const TABS = [
  { id: 'pnl', label: 'Profit & Loss', icon: BarChart3 },
  { id: 'balance', label: 'Balance Sheet', icon: Scale },
  { id: 'trial', label: 'Trial Balance', icon: GitCompareArrows },
  { id: 'record', label: 'Record Transaction', icon: ReceiptText },
  { id: 'inventory', label: 'Inventory', icon: Package },
  { id: 'reports', label: 'Report', icon: FileBarChart },
] as const;

type TabId = (typeof TABS)[number]['id'];

export function AccountsTabs() {
  const { today } = useOutletContext<WorkspaceData>();
  const { ledgers, vouchers, loading, error, reload } = useAccounts();
  const [tab, setTab] = useState<TabId>('pnl');

  if (loading) {
    return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading your accounts…</p></div>;
  }

  const hasLedgers = ledgers.length > 0;

  return (
    <>
      {error && <div className="error-banner" role="alert">{error} <button onClick={reload}>Try again</button></div>}

      {!hasLedgers ? (
        <div className="large-empty">
          <BookText size={48} strokeWidth={1.2} />
          <h3>Set up your chart of accounts.</h3>
          <p>Your accounts workspace runs on double-entry bookkeeping — just like Tally. Create your first ledger, or add a sample set to get started.</p>
          <div className="heading-actions">
            <LedgerEditor onSaved={reload} />
            <SeedLedgers onDone={reload} />
          </div>
        </div>
      ) : (
        <>
          <div className="workspace-tabs accounts-tabs">
            {TABS.map((t) => (
              <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
                <t.icon size={15} /> {t.label}
              </button>
            ))}
          </div>

          {tab === 'pnl' && <ProfitLoss ledgers={ledgers} vouchers={vouchers} today={today} />}
          {tab === 'balance' && <BalanceSheet ledgers={ledgers} vouchers={vouchers} today={today} />}
          {tab === 'trial' && <TrialBalance ledgers={ledgers} vouchers={vouchers} />}
          {tab === 'record' && <RecordTransaction ledgers={ledgers} vouchers={vouchers} today={today} />}
          {tab === 'inventory' && <Inventory ledgers={ledgers} vouchers={vouchers} today={today} />}
          {tab === 'reports' && <Reports ledgers={ledgers} vouchers={vouchers} today={today} />}
        </>
      )}
    </>
  );
}
