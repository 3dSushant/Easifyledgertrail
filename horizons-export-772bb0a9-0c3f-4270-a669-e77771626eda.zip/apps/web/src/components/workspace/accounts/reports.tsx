import { useState } from 'react';
import { useOutletContext } from 'react-router';
import { FileBarChart, Search, ChevronLeft, ArrowUpRight, TrendingUp, TrendingDown } from 'lucide-react';
import type { Ledger, Voucher } from '@/lib/accounts';
import {
  ledgerBalance, vouchersForLedger, movementInVoucher, profitAndLoss,
  groupTotal, netWorth, money, dateLabel, exportCsv, openingSigned,
} from '@/lib/accounts';
import { REPORTS } from '@/data/accounts';
import type { WorkspaceData } from '@/lib/business';
import { VoucherDetail } from './voucher-detail';

export function Reports({
  ledgers, vouchers, today,
}: { ledgers: Ledger[]; vouchers: Voucher[]; today: string }) {
  const { compliance } = useOutletContext<WorkspaceData>();
  const [active, setActive] = useState<string | null>(null);
  const [ledgerQuery, setLedgerQuery] = useState('');
  const [selectedLedger, setSelectedLedger] = useState<Ledger | null>(null);
  const [openVoucher, setOpenVoucher] = useState<Voucher | null>(null);

  if (openVoucher) {
    return <VoucherDetail voucher={openVoucher} ledgers={ledgers} today={today} onBack={() => setOpenVoucher(null)} />;
  }

  const report = REPORTS.find((r) => r.id === active);

  function back() {
    setActive(null);
    setSelectedLedger(null);
  }

  function renderReport() {
    if (!report) return null;

    if (report.id === 'advances') {
      const advancesGiven = ledgers
        .filter((l) => l.subgroup === 'Advances Given')
        .map((l) => ({ l, b: ledgerBalance(l, vouchers) }))
        .filter((x) => x.b !== 0);
      // Liability ledgers carrying a debit balance are also advances paid
      // (e.g. advance to supplier booked under a liability ledger).
      const liabilityDebit = ledgers
        .filter((l) => l.group === 'Liabilities' && l.subgroup !== 'Supplier Outstanding')
        .map((l) => ({ l, b: ledgerBalance(l, vouchers) }))
        .filter((x) => x.b < 0)
        .map((x) => ({ l: x.l, b: Math.abs(x.b) }));
      const list = [...advancesGiven, ...liabilityDebit];
      return <ReportTable title="Advances Paid to Supplier" rows={list} />;
    }
    if (report.id === 'creditors') {
      const list = ledgers.filter((l) => l.subgroup === 'Supplier Outstanding').map((l) => ({ l, b: ledgerBalance(l, vouchers) })).filter((x) => x.b !== 0);
      return <ReportTable title="Creditors List" rows={list} />;
    }
    if (report.id === 'emi') {
      const loans = ledgers.filter((l) => l.subgroup === 'Loans').map((l) => ({ l, b: ledgerBalance(l, vouchers) })).filter((x) => x.b !== 0);
      return (
        <ReportPanel title="Upcoming EMI & Monthly Payments" onExport={() => exportCsv('emi-payments.csv', ['Loan', 'Outstanding (INR)'], loans.map((x) => [x.l.name, x.b]))}>
          {loans.length ? (
            <div className="table-scroll"><table><thead><tr><th>Loan / obligation</th><th className="align-right">Outstanding</th></tr></thead><tbody>{loans.map((x) => <tr key={x.l.id}><td><strong>{x.l.name}</strong></td><td className="align-right amount-cell">{money(x.b)}</td></tr>)}</tbody></table></div>
          ) : <EmptyReport text="No loan ledgers recorded. Create a loan ledger under Liabilities → Loans to track EMIs." />}
        </ReportPanel>
      );
    }
    if (report.id === 'compliance') {
      const filed = compliance.filter((c) => c.status === 'Filed');
      const pending = compliance.filter((c) => c.status !== 'Filed');
      return (
        <ReportPanel title="Compliance Report" onExport={() => exportCsv('compliance-report.csv', ['Title', 'Type', 'Period', 'Due date', 'Status'], compliance.map((c) => [c.title || '', c.type || '', c.period || '', c.due_date || '', c.status || '']))}>
          <div className="report-cols">
            <div>
              <h3 className="report-sub">Pending ({pending.length})</h3>
              {pending.length ? (
                <div className="table-scroll"><table><thead><tr><th>Filing</th><th>Type</th><th>Due</th><th>Status</th></tr></thead><tbody>{pending.map((c) => <tr key={c.id}><td><strong>{c.title}</strong></td><td>{c.type}</td><td className="nowrap">{dateLabel(c.due_date)}</td><td><span className="status-badge status-pending"><i />{c.status}</span></td></tr>)}</tbody></table></div>
              ) : <EmptyReport text="No pending filings. Everything is filed." />}
            </div>
            <div>
              <h3 className="report-sub">Completed ({filed.length})</h3>
              {filed.length ? (
                <div className="table-scroll"><table><thead><tr><th>Filing</th><th>Type</th><th>Period</th></tr></thead><tbody>{filed.map((c) => <tr key={c.id}><td><strong>{c.title}</strong></td><td>{c.type}</td><td>{c.period}</td></tr>)}</tbody></table></div>
              ) : <EmptyReport text="No completed filings yet." />}
            </div>
          </div>
        </ReportPanel>
      );
    }
    if (report.id === 'cashflow') {
      const months = Array.from({ length: 6 }, (_, i) => {
        const d = new Date(`${today.slice(0, 7)}-01T00:00:00Z`); d.setUTCMonth(d.getUTCMonth() - 5 + i);
        return d.toISOString().slice(0, 7);
      });
      const rows = months.map((m) => {
        const mv = vouchers.filter((v) => (v.date || '').startsWith(m));
        let inflow = 0; let outflow = 0;
        for (const v of mv) for (const e of v.entries || []) {
          const ledger = ledgers.find((l) => l.id === e.ledger);
          if (!ledger) continue;
          if (ledger.subgroup === 'Bank & Cash') inflow += Number(e.debit || 0) - Number(e.credit || 0);
        }
        for (const v of mv) for (const e of v.entries || []) {
          const ledger = ledgers.find((l) => l.id === e.ledger);
          if (ledger?.group === 'Expenses') outflow += Number(e.debit || 0);
        }
        return { m, inflow, outflow, net: inflow - outflow };
      });
      return (
        <ReportPanel title="Cash Flow Statement" onExport={() => exportCsv('cash-flow.csv', ['Month', 'Inflow', 'Outflow', 'Net'], rows.map((r) => [r.m, r.inflow, r.outflow, r.net]))}>
          <div className="table-scroll"><table><thead><tr><th>Month</th><th className="align-right">Inflow</th><th className="align-right">Outflow</th><th className="align-right">Net</th></tr></thead><tbody>{rows.map((r) => <tr key={r.m}><td><strong>{dateLabel(`${r.m}-01`)}</strong></td><td className="align-right income-amount">{money(r.inflow)}</td><td className="align-right amount-cell">{money(r.outflow)}</td><td className={`align-right amount-cell ${r.net >= 0 ? 'income-amount' : 'summary-loss-text'}`}>{money(r.net)}</td></tr>)}</tbody></table></div>
        </ReportPanel>
      );
    }
    if (report.id === 'ledger') {
      const matches = ledgers.filter((l) => l.name.toLowerCase().includes(ledgerQuery.toLowerCase()));
      return (
        <ReportPanel title="Ledger Statement">
          <div className="table-filters">
            <label className="search-control"><Search size={16} /><input value={ledgerQuery} onChange={(e) => setLedgerQuery(e.target.value)} placeholder="Search ledger by name…" aria-label="Search ledger" /></label>
          </div>
          {selectedLedger ? (
            <LedgerStatement ledger={selectedLedger} vouchers={vouchers} onBack={() => setSelectedLedger(null)} onOpenVoucher={(v) => setOpenVoucher(v)} />
          ) : (
            <div className="table-scroll"><table><thead><tr><th>Ledger</th><th>Group</th><th>Sub-group</th><th className="align-right">Balance</th><th className="align-right">Open</th></tr></thead><tbody>{matches.map((l) => <tr key={l.id} className="drill-row"><td><strong>{l.name}</strong></td><td>{l.group}</td><td>{l.subgroup}</td><td className="align-right amount-cell">{money(ledgerBalance(l, vouchers))}</td><td className="align-right"><button className="icon-button table-edit" onClick={() => setSelectedLedger(l)} aria-label={`Open ${l.name}`}><ArrowUpRight size={16} /></button></td></tr>)}</tbody></table></div>
          )}
        </ReportPanel>
      );
    }
    if (report.id === 'pnl') {
      const pnl = profitAndLoss(ledgers, vouchers);
      return (
        <ReportPanel title="Profit & Loss Statement" onExport={() => exportCsv('profit-loss.csv', ['Particulars', 'Amount (INR)'], [['Total income', pnl.income], ['Total expenses', pnl.expenses], ['Net profit / (loss)', pnl.profit]])}>
          <div className="table-scroll"><table><thead><tr><th>Particulars</th><th className="align-right">Amount</th></tr></thead><tbody><tr><td><strong>Total income (sales & other income)</strong></td><td className="align-right income-amount">{money(pnl.income)}</td></tr><tr><td><strong>Total expenses (direct & indirect)</strong></td><td className="align-right amount-cell">{money(pnl.expenses)}</td></tr><tr><td><strong>Net {pnl.isProfit ? 'profit' : 'loss'}</strong></td><td className={`align-right amount-cell ${pnl.isProfit ? 'income-amount' : 'summary-loss-text'}`}>{money(Math.abs(pnl.profit))}</td></tr></tbody></table></div>
        </ReportPanel>
      );
    }
    if (report.id === 'balancesheet') {
      const assets = groupTotal('Assets', ledgers, vouchers);
      const liabilities = groupTotal('Liabilities', ledgers, vouchers);
      const worth = netWorth(ledgers, vouchers);
      return (
        <ReportPanel title="Balance Sheet" onExport={() => exportCsv('balance-sheet.csv', ['Particulars', 'Amount (INR)'], [['Total assets', assets], ['Total liabilities', liabilities], ['Net worth', worth]])}>
          <div className="table-scroll"><table><thead><tr><th>Particulars</th><th className="align-right">Amount</th></tr></thead><tbody><tr><td><strong>Total assets</strong></td><td className="align-right income-amount">{money(assets)}</td></tr><tr><td><strong>Total liabilities</strong></td><td className="align-right amount-cell">{money(liabilities)}</td></tr><tr><td><strong>Business net worth</strong></td><td className="align-right amount-cell">{money(worth)}</td></tr></tbody></table></div>
        </ReportPanel>
      );
    }
    return null;
  }

  if (report) {
    return (
      <>
        <div className="page-heading">
          <div>
            <button className="text-link" onClick={back}><ChevronLeft size={15} />All reports</button>
            <h1 style={{ marginTop: 12 }}>{report.title}<span>.</span></h1>
            <p>{report.description}</p>
          </div>
        </div>
        <section className="dashboard-panel">{renderReport()}</section>
      </>
    );
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">REPORTING</span>
          <h1>Reports & statements<span>.</span></h1>
          <p>Search any ledger, view complete details, and generate the reports your business needs.</p>
        </div>
      </div>
      <div className="report-grid">
        {REPORTS.map((r) => (
          <button className="report-card" key={r.id} onClick={() => setActive(r.id)}>
            <div className="report-card-top"><FileBarChart size={22} /><ArrowUpRight size={16} /></div>
            <h3>{r.title}</h3>
            <p>{r.description}</p>
          </button>
        ))}
      </div>
    </>
  );
}

function ReportPanel({ title, children, onExport }: { title: string; children: React.ReactNode; onExport?: () => void }) {
  return (
    <>
      <div className="panel-heading">
        <div><h2>{title}</h2></div>
        {onExport && <button className="button button-quiet button-small" onClick={onExport}><TrendingUp size={14} />Export CSV</button>}
      </div>
      <div style={{ padding: '0 22px 22px' }}>{children}</div>
    </>
  );
}

function ReportTable({ title, rows }: { title: string; rows: { l: Ledger; b: number }[] }) {
  const total = rows.reduce((s, x) => s + x.b, 0);
  return (
    <ReportPanel title={title} onExport={() => exportCsv(`${title.toLowerCase().replace(/\s+/g, '-')}.csv`, ['Ledger', 'Amount (INR)'], rows.map((x) => [x.l.name, x.b]))}>
      {rows.length ? (
        <div className="table-scroll"><table><thead><tr><th>Ledger</th><th className="align-right">Amount</th></tr></thead><tbody>{rows.map((x) => <tr key={x.l.id} className="drill-row"><td><strong>{x.l.name}</strong></td><td className="align-right amount-cell">{money(x.b)}</td></tr>)}</tbody><tfoot><tr><td><strong>Total</strong></td><td className="align-right amount-cell"><strong>{money(total)}</strong></td></tr></tfoot></table></div>
      ) : <EmptyReport text="No balances recorded in this group yet." />}
    </ReportPanel>
  );
}

function LedgerStatement({ ledger, vouchers, onBack, onOpenVoucher }: { ledger: Ledger; vouchers: Voucher[]; onBack: () => void; onOpenVoucher: (v: Voucher) => void }) {
  const list = vouchersForLedger(ledger.id, vouchers).sort((a, b) => (a.date || '').localeCompare(b.date || ''));

  // Summary figures computed from every voucher that touches this ledger.
  let debitTotal = 0;
  let creditTotal = 0;
  let paymentPaid = 0;
  let invoiceSubtotal = 0;
  let gstTotal = 0;
  let tdsTotal = 0;
  for (const v of list) {
    const touches = (v.entries || []).some((e) => e.ledger === ledger.id);
    for (const e of v.entries || []) {
      if (e.ledger === ledger.id) {
        debitTotal += Number(e.debit || 0);
        creditTotal += Number(e.credit || 0);
        if (v.type === 'Bank' || v.type === 'Cash') paymentPaid += Number(e.credit || 0);
      }
      if (touches && (e.ledgerName || '').toLowerCase().includes('tds')) {
        tdsTotal += Number(e.credit || 0) - Number(e.debit || 0);
      }
    }
    if (touches && v.items?.length) {
      for (const it of v.items) {
        invoiceSubtotal += Number(it.amount || 0);
        gstTotal += Number(it.gst_amount || 0);
      }
    }
  }
  const opening = openingSigned(ledger);
  const closing = ledgerBalance(ledger, vouchers);

  const summary = [
    { label: 'Opening balance', value: money(Math.abs(opening)) + (opening < 0 ? ' Cr' : opening > 0 ? ' Dr' : '') },
    { label: 'Debit total', value: money(debitTotal) },
    { label: 'Credit total', value: money(creditTotal) },
    { label: 'Closing balance', value: money(Math.abs(closing)) + (closing < 0 ? ' Cr' : closing > 0 ? ' Dr' : '') },
    { label: 'Invoice booked (excl. GST)', value: money(invoiceSubtotal) },
    { label: 'Total GST', value: money(gstTotal) },
    { label: 'Total TDS deducted', value: money(tdsTotal) },
    { label: 'Total payment paid', value: money(paymentPaid) },
  ];

  let running = Number(ledger.opening_balance || 0);
  return (
    <>
      <div style={{ marginBottom: 14 }}>
        <button className="text-link" onClick={onBack}><ChevronLeft size={15} />Back to ledgers</button>
      </div>
      <div className="ledger-summary-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10, marginBottom: 18 }}>
        {summary.map((s) => (
          <div key={s.label} className="summary-card" style={{ padding: '14px 15px' }}>
            <div style={{ fontSize: 10, color: 'var(--quiet)' }}>{s.label}</div>
            <strong style={{ display: 'block', fontSize: 15, marginTop: 8, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{s.value}</strong>
          </div>
        ))}
      </div>
      <div className="table-scroll"><table><thead><tr><th>Date</th><th>Reference</th><th>Counterparty</th><th className="align-right">Debit</th><th className="align-right">Credit</th><th className="align-right">Balance</th><th className="align-right">Open</th></tr></thead><tbody>{list.map((v) => {
        const move = movementInVoucher(ledger.id, v);
        running += move;
        return <tr key={v.id} className="drill-row"><td className="nowrap">{dateLabel(v.date)}</td><td><strong>{v.reference || '—'}</strong></td><td>{v.counterparty || '—'}</td><td className="align-right amount-cell">{move > 0 ? money(move) : '—'}</td><td className="align-right income-amount">{move < 0 ? money(Math.abs(move)) : '—'}</td><td className="align-right amount-cell">{money(running)}</td><td className="align-right"><button className="icon-button table-edit" onClick={() => onOpenVoucher(v)} aria-label="Open voucher"><ArrowUpRight size={16} /></button></td></tr>;
      })}</tbody></table></div>
    </>
  );
}

function EmptyReport({ text }: { text: string }) {
  return <div className="compact-empty"><TrendingDown size={30} strokeWidth={1.4} /><strong>Nothing to show.</strong><p>{text}</p></div>;
}
