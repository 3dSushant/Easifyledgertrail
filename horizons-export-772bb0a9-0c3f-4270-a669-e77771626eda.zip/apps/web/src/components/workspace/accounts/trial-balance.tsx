import { Fragment, useState } from 'react';
import { Download, Scale, ArrowUpRight, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import type { Ledger, Voucher } from '@/lib/accounts';
import { trialBalance, vouchersForLedger, movementInVoucher, money, dateLabel, exportCsv } from '@/lib/accounts';

export function TrialBalance({
  ledgers, vouchers,
}: { ledgers: Ledger[]; vouchers: Voucher[] }) {
  const { groups, totalDebit, totalCredit, balanced } = trialBalance(ledgers, vouchers);
  const [selected, setSelected] = useState<Ledger | null>(null);

  function download() {
    const rows: (string | number)[][] = [];
    for (const g of groups) {
      rows.push([g.label, '', '', '']);
      for (const r of g.rows) {
        rows.push([r.ledger.name, r.debit || '', r.credit || '', r.debit - r.credit]);
      }
    }
    rows.push(['', '', '', '']);
    rows.push(['Total', totalDebit, totalCredit, totalDebit - totalCredit]);
    exportCsv('trial-balance.csv', ['Ledger', 'Debit (INR)', 'Credit (INR)', 'Balance (INR)'], rows);
  }

  const selectedVouchers = selected ? vouchersForLedger(selected.id, vouchers) : [];

  function downloadDrilldown() {
    if (!selected) return;
    exportCsv(
      `${selected.name.replace(/\s+/g, '-').toLowerCase()}-statement.csv`,
      ['Date', 'Type', 'Reference', 'Counterparty', 'Debit (INR)', 'Credit (INR)', 'Movement (INR)'],
      selectedVouchers.map((v) => {
        const move = movementInVoucher(selected.id, v);
        return [v.date || '', v.type, v.reference || '', v.counterparty || '', move > 0 ? move : '', move < 0 ? Math.abs(move) : '', move];
      }),
    );
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">TRIAL BALANCE</span>
          <h1>Trial balance<span>.</span></h1>
          <p>Tally-style trial balance from posted double-entry transactions and opening balances. Click any ledger to drill into its vouchers.</p>
        </div>
        <div className="heading-actions">
          <button className="button button-quiet button-small" onClick={download} disabled={!groups.length}><Download size={15} />Export CSV</button>
        </div>
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading">
          <div><h2><Scale size={16} /> Posted balances</h2><p>Every ledger with a non-zero balance, grouped in Tally order. Click a ledger to see its vouchers.</p></div>
          <span className={`status-badge ${balanced ? 'status-complete' : 'status-overdue'}`}><i />{balanced ? 'Balanced' : 'Not balanced'}</span>
        </div>

        {groups.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Ledger</th><th className="align-right">Debit</th><th className="align-right">Credit</th><th className="align-right">Balance</th><th className="align-right">Open</th></tr></thead>
              <tbody>
                {groups.map((g) => (
                  <Fragment key={g.group}>
                    <tr><td colSpan={5} className="tb-group-head">{g.label}</td></tr>
                    {g.rows.map((r) => (
                      <tr key={r.ledger.id} className="drill-row">
                        <td><strong>{r.ledger.name}</strong><small>{r.ledger.subgroup}</small></td>
                        <td className="align-right amount-cell">{r.debit ? money(r.debit) : '—'}</td>
                        <td className="align-right income-amount">{r.credit ? money(r.credit) : '—'}</td>
                        <td className="align-right amount-cell">{money(r.debit - r.credit)}</td>
                        <td className="align-right"><button className="icon-button table-edit" onClick={() => setSelected(r.ledger)} aria-label={`Open ${r.ledger.name}`}><ArrowUpRight size={16} /></button></td>
                      </tr>
                    ))}
                  </Fragment>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td><strong>Total</strong></td>
                  <td className="align-right amount-cell"><strong>{money(totalDebit)}</strong></td>
                  <td className="align-right income-amount"><strong>{money(totalCredit)}</strong></td>
                  <td className="align-right amount-cell"><strong>{money(totalDebit - totalCredit)}</strong></td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <div className="large-empty">
            <Scale size={42} strokeWidth={1.3} />
            <h3>No balances to show.</h3>
            <p>Record transactions or set opening balances on your ledgers to build the trial balance.</p>
          </div>
        )}
      </section>

      <Dialog open={!!selected} onOpenChange={(v) => { if (!v) setSelected(null); }}>
        <DialogContent className="record-dialog payroll-details-dialog">
          <DialogTitle>{selected?.name}<span className="accent-dot">.</span></DialogTitle>
          <div className="panel-heading" style={{ paddingLeft: 0, paddingRight: 0 }}>
            <div><h2 style={{ fontSize: 13 }}>Vouchers in this ledger <span className="count-label">{selectedVouchers.length}</span></h2><p>Every entry that touched this account.</p></div>
            <button className="button button-quiet button-small" onClick={downloadDrilldown} disabled={!selectedVouchers.length}><Download size={15} />Export CSV</button>
          </div>
          {selectedVouchers.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Counterparty</th><th className="align-right">Debit</th><th className="align-right">Credit</th><th className="align-right">Movement</th></tr></thead>
                <tbody>
                  {selectedVouchers.map((v) => {
                    const move = movementInVoucher(selected!.id, v);
                    return (
                      <tr key={v.id}>
                        <td className="nowrap">{dateLabel(v.date)}</td>
                        <td><span className="type-label">{v.type}</span></td>
                        <td><strong>{v.reference || '—'}</strong></td>
                        <td>{v.counterparty || '—'}</td>
                        <td className="align-right amount-cell">{move > 0 ? money(move) : '—'}</td>
                        <td className="align-right income-amount">{move < 0 ? money(Math.abs(move)) : '—'}</td>
                        <td className={`align-right amount-cell ${move >= 0 ? 'income-amount' : ''}`}>{move >= 0 ? '+' : '−'}{money(Math.abs(move))}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="compact-empty"><Scale size={30} strokeWidth={1.4} /><strong>No vouchers yet.</strong><p>Record a transaction that uses this ledger to see entries here.</p></div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
