import { useEffect, useMemo, useRef, useState } from 'react';
import { Plus, Pencil, ArrowUpRight, Trash2, ArrowRightLeft, X } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { VOUCHER_TYPES } from '@/data/accounts';
import type { Ledger, Voucher, VoucherEntry, InvoiceItem, LedgerKind, LedgerGroup } from '@/lib/accounts';
import { money, ledgerBalance } from '@/lib/accounts';
import { EntityEditor, LedgerEditor } from './ledger-editor';

type Row = { ledger: string; debit: string; credit: string };

type ItemRow = {
  item_ledger: string;
  item_code: string;
  hsn: string;
  qty: string;
  qtyText: string;
  rate: string;
  discount: string;
  gst_rate: string;
  amount: string;
};

type BankCashRow = { date: string; ledger: string; amount: string };

function toRows(entries?: VoucherEntry[]): Row[] {
  if (!entries?.length) return [{ ledger: '', debit: '', credit: '' }];
  return entries.map((e) => ({ ledger: e.ledger, debit: e.debit ? String(e.debit) : '', credit: e.credit ? String(e.credit) : '' }));
}

function toItems(items?: InvoiceItem[]): ItemRow[] {
  if (!items?.length) return [emptyItem()];
  return items.map((i) => ({
    item_ledger: i.item_ledger || '',
    item_code: i.item_code || '',
    hsn: i.hsn || '',
    qty: i.qty != null ? String(i.qty) : '',
    qtyText: i.qtyText || '',
    rate: i.rate != null ? String(i.rate) : '',
    discount: i.discount != null ? String(i.discount) : '',
    gst_rate: i.gst_rate != null ? String(i.gst_rate) : '',
    amount: i.amount != null ? String(i.amount) : '',
  }));
}

function emptyItem(): ItemRow {
  return { item_ledger: '', item_code: '', hsn: '', qty: '', qtyText: '', rate: '', discount: '', gst_rate: '', amount: '' };
}

function emptyBankRow(today: string): BankCashRow {
  return { date: today, ledger: '', amount: '' };
}

const num = (s: string) => parseFloat(s) || 0;

/** Ledgers valid as posting accounts (excludes master party/project/item kinds). */
const isPostingLedger = (l: Ledger) => l.kind === 'account' || !l.kind;

export function VoucherEditor({
  ledgers,
  vouchers,
  voucher,
  defaultType,
  typeChoices,
  today,
  onSaved,
  forcedOpen,
  hideTrigger,
  onClose,
}: {
  ledgers: Ledger[];
  vouchers?: Voucher[];
  voucher?: Voucher;
  defaultType?: string;
  typeChoices?: string[];
  today: string;
  onSaved?: () => void;
  forcedOpen?: boolean;
  hideTrigger?: boolean;
  onClose?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const choices = typeChoices || (voucher ? [voucher.type] : VOUCHER_TYPES);
  const [type, setType] = useState(voucher?.type || defaultType || choices[0] || 'Sales');
  const [rows, setRows] = useState<Row[]>(toRows(voucher?.entries || []));
  const [extraLedgers, setExtraLedgers] = useState<Ledger[]>([]);

  // Invoice state (sales + purchase)
  const [counterpartyId, setCounterpartyId] = useState(voucher?.counterparty_ledger || '');
  const [projectId, setProjectId] = useState(voucher?.project_ledger || '');
  const [creditDays, setCreditDays] = useState(String(voucher?.credit_days || ''));
  const [saleType, setSaleType] = useState<'goods' | 'service'>(voucher?.sale_type || 'goods');
  const [purchasePostTo, setPurchasePostTo] = useState<'inventory' | 'expense'>('expense');
  const [expenseProjectId, setExpenseProjectId] = useState(voucher?.project_ledger || '');
  const [itemRows, setItemRows] = useState<ItemRow[]>(toItems(voucher?.items));
  const [creating, setCreating] = useState<LedgerKind | null>(null);
  const [creatingSubgroup, setCreatingSubgroup] = useState<string | null>(null);

  // Guards the voucher dialog against a dismissal event that Radix may fire in
  // the same tick a nested ledger/entity editor closes after saving. While the
  // ref is set, the voucher dialog refuses to close — so creating a ledger from
  // inside a voucher never discards the in-progress entry.
  const justSavedLedgerRef = useRef(false);
  const flagJustSavedLedger = () => {
    justSavedLedgerRef.current = true;
    window.setTimeout(() => {
      justSavedLedgerRef.current = false;
    }, 200);
  };

  useEffect(() => {
    if (forcedOpen) { setOpen(true); reset(); }
  }, [forcedOpen]);

  // Expense voucher state
  const [expenseLedgerId, setExpenseLedgerId] = useState(
    (voucher?.entries || []).find((e) => Number(e.debit) > 0)?.ledger || '',
  );
  const [expenseAmount, setExpenseAmount] = useState(String(voucher?.total || ''));
  const [creditLedgerId, setCreditLedgerId] = useState(
    (voucher?.entries || []).find((e) => Number(e.credit) > 0)?.ledger || '',
  );
  const [tdsSection, setTdsSection] = useState('');
  const [tdsRate, setTdsRate] = useState('');

  // Bank / cash state
  const [entryKind, setEntryKind] = useState<'payment' | 'receipt'>(voucher?.entry_kind || 'payment');
  const [bankCashLedgerId, setBankCashLedgerId] = useState(voucher?.bank_cash_ledger || '');
  const [bankCashRows, setBankCashRows] = useState<BankCashRow[]>(
    (voucher?.entries || []).filter((e) => e.ledger !== voucher?.bank_cash_ledger).length
      ? (voucher?.entries || [])
          .filter((e) => e.ledger !== voucher?.bank_cash_ledger)
          .map((e) => ({ date: e.date || voucher?.date || today, ledger: e.ledger, amount: String(Number(e.debit) || Number(e.credit) || 0) }))
      : [emptyBankRow(today)],
  );

  // Dedupe by id: a ledger just created inside the voucher lives in
  // `extraLedgers`, and the realtime reload then also delivers it via `ledgers`.
  // Without dedupe it would appear twice in every dropdown.
  const allLedgers = useMemo(() => {
    const map = new Map<string, Ledger>();
    for (const l of [...ledgers, ...extraLedgers]) map.set(l.id, l);
    return Array.from(map.values());
  }, [ledgers, extraLedgers]);
  const parties = allLedgers.filter((l) => l.kind === 'party');
  const clients = parties.filter((l) => l.subgroup !== 'Supplier Outstanding');
  const suppliers = parties.filter((l) => l.subgroup === 'Supplier Outstanding');
  const projects = allLedgers.filter((l) => l.kind === 'project');
  const items = allLedgers.filter((l) => l.kind === 'item');
  const bankCashLedgers = allLedgers.filter((l) => l.subgroup === 'Bank & Cash');
  const expenseLedgers = allLedgers.filter((l) => l.group === 'Expenses' && isPostingLedger(l));
  const creditLedgerOptions = allLedgers.filter(
    (l) => isPostingLedger(l) && (l.subgroup === 'Bank & Cash' || l.subgroup === 'Supplier Outstanding' || l.subgroup === 'Receivables'),
  );

  const isSales = type === 'Sales';
  const isPurchase = type === 'Purchase';
  const isInvoice = isSales || isPurchase;
  const isExpense = type === 'Expense';
  const isBankCash = type === 'Bank' || type === 'Cash' || type === 'Transfer';

  const totalDebit = rows.reduce((s, r) => s + num(r.debit), 0);
  const totalCredit = rows.reduce((s, r) => s + num(r.credit), 0);
  const balanced = Math.abs(totalDebit - totalCredit) < 0.01 && totalDebit > 0;

  // --- invoice computations (sales + purchase, goods/service for sales only) ---
  const computedItems = itemRows.map((r) => {
    const gstRate = num(r.gst_rate);
    let amount = 0;
    if (isPurchase || saleType === 'goods') {
      const qty = num(r.qty);
      const rate = num(r.rate);
      const disc = num(r.discount);
      amount = qty * rate * (1 - disc / 100);
    } else {
      const qty = num(r.qty);
      const rate = num(r.rate);
      amount = qty && rate ? qty * rate : num(r.amount);
    }
    const gst = amount * (gstRate / 100);
    return { ...r, amount, gst };
  });
  const subtotal = computedItems.reduce((s, i) => s + i.amount, 0);
  const totalGst = computedItems.reduce((s, i) => s + i.gst, 0);
  const grandTotal = subtotal + totalGst;

  // --- bank/cash computations ---
  const bankCashTotal = bankCashRows.reduce((s, r) => s + num(r.amount), 0);
  const bankCashLedger = allLedgers.find((l) => l.id === bankCashLedgerId);
  const bankOpening = bankCashLedger ? ledgerBalance(bankCashLedger, vouchers || []) : 0;
  const bankClosing = bankCashLedger
    ? entryKind === 'payment'
      ? bankOpening - bankCashTotal
      : bankOpening + bankCashTotal
    : 0;

  function reset() {
    setType(voucher?.type || defaultType || choices[0] || 'Sales');
    setRows(toRows(voucher?.entries || []));
    setCounterpartyId(voucher?.counterparty_ledger || '');
    setProjectId(voucher?.project_ledger || '');
    setCreditDays(String(voucher?.credit_days || ''));
    setSaleType(voucher?.sale_type || 'goods');
    setPurchasePostTo('expense');
    setExpenseProjectId(voucher?.project_ledger || '');
    setItemRows(toItems(voucher?.items));
    setExpenseLedgerId((voucher?.entries || []).find((e) => Number(e.debit) > 0)?.ledger || '');
    setExpenseAmount(String(voucher?.total || ''));
    setCreditLedgerId((voucher?.entries || []).find((e) => Number(e.credit) > 0)?.ledger || '');
    setTdsSection('');
    setTdsRate('');
    setEntryKind(voucher?.entry_kind || 'payment');
    setBankCashLedgerId(voucher?.bank_cash_ledger || '');
    setBankCashRows(
      (voucher?.entries || []).filter((e) => e.ledger !== voucher?.bank_cash_ledger).length
        ? (voucher?.entries || [])
            .filter((e) => e.ledger !== voucher?.bank_cash_ledger)
            .map((e) => ({ date: e.date || voucher?.date || today, ledger: e.ledger, amount: String(Number(e.debit) || Number(e.credit) || 0) }))
        : [emptyBankRow(today)],
    );
    setError('');
  }

  function addRow() { setRows((prev) => [...prev, { ledger: '', debit: '', credit: '' }]); }
  function removeRow(index: number) { setRows((prev) => prev.filter((_, i) => i !== index)); }
  function updateRow(index: number, patch: Partial<Row>) { setRows((prev) => prev.map((r, i) => (i === index ? { ...r, ...patch } : r))); }

  function addItem() { setItemRows((prev) => [...prev, emptyItem()]); }
  function removeItem(index: number) { setItemRows((prev) => prev.filter((_, i) => i !== index)); }
  function updateItem(index: number, patch: Partial<ItemRow>) { setItemRows((prev) => prev.map((r, i) => (i === index ? { ...r, ...patch } : r))); }

  function addBankRow() { setBankCashRows((prev) => [...prev, emptyBankRow(today)]); }
  function removeBankRow(index: number) { setBankCashRows((prev) => prev.filter((_, i) => i !== index)); }
  function updateBankRow(index: number, patch: Partial<BankCashRow>) { setBankCashRows((prev) => prev.map((r, i) => (i === index ? { ...r, ...patch } : r))); }

  function pickItem(index: number, id: string) {
    if (id === '__new__') { setCreating('item'); return; }
    const ledger = items.find((l) => l.id === id);
    updateItem(index, {
      item_ledger: id,
      item_code: ledger?.item_code || '',
      hsn: ledger?.hsn_code || '',
      gst_rate: ledger?.gst_rate != null ? String(ledger.gst_rate) : '',
    });
  }

  async function ensureGstLedger(name: string, group: LedgerGroup, subgroup: string): Promise<Ledger | null> {
    if (totalGst <= 0) return null;
    const existing = allLedgers.find((l) => l.name.toLowerCase() === name.toLowerCase());
    if (existing) return existing;
    const rec = await pb.collection('ledgers').create({
      name, group, subgroup, kind: 'account', opening_balance: 0, owner: pb.authStore.record?.id,
    });
    const ledger = rec as Ledger;
    setExtraLedgers((prev) => [...prev, ledger]);
    return ledger;
  }

  async function ensureInventoryLedger(): Promise<Ledger | null> {
    const existing = allLedgers.find((l) => l.name.toLowerCase() === 'inventory');
    if (existing) return existing;
    const rec = await pb.collection('ledgers').create({
      name: 'Inventory', group: 'Assets', subgroup: 'Inventory', kind: 'account', opening_balance: 0, owner: pb.authStore.record?.id,
    });
    const ledger = rec as Ledger;
    setExtraLedgers((prev) => [...prev, ledger]);
    return ledger;
  }

  async function ensureTdsLedger(): Promise<Ledger | null> {
    const existing = allLedgers.find((l) => l.name.toLowerCase() === 'tds payable');
    if (existing) return existing;
    const rec = await pb.collection('ledgers').create({
      name: 'TDS Payable', group: 'Liabilities', subgroup: 'Other Current Liabilities', kind: 'account', opening_balance: 0, owner: pb.authStore.record?.id,
    });
    const ledger = rec as Ledger;
    setExtraLedgers((prev) => [...prev, ledger]);
    return ledger;
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);

    try {
      if (isInvoice) {
        const validItems = computedItems.filter((r) => r.item_ledger);
        const partyList = isSales ? clients : suppliers;
        if (!counterpartyId) { setError(`Select a ${isSales ? 'client' : 'supplier'} (or create a new one).`); setBusy(false); return; }
        if (!validItems.length) { setError('Add at least one item line.'); setBusy(false); return; }
        const party = partyList.find((p) => p.id === counterpartyId);
        const project = projects.find((p) => p.id === projectId);
        const gstLedger = await ensureGstLedger(
          isSales ? 'Output GST' : 'Input GST',
          isSales ? 'Liabilities' : 'Assets',
          isSales ? 'Other Current Liabilities' : 'Other Current Assets',
        );

        const invoiceItems: InvoiceItem[] = validItems.map((r) => {
          const ledger = items.find((l) => l.id === r.item_ledger);
          return {
            item_ledger: r.item_ledger,
            itemName: ledger?.name || '',
            item_code: r.item_code,
            hsn: r.hsn,
            qty: isPurchase || saleType === 'goods' ? num(r.qty) : undefined,
            qtyText: saleType === 'service' ? r.qtyText : undefined,
            rate: num(r.rate) || undefined,
            discount: isPurchase || saleType === 'goods' ? num(r.discount) : undefined,
            gst_rate: num(r.gst_rate),
            amount: r.amount,
            gst_amount: r.gst,
            post_to: isPurchase ? purchasePostTo : undefined,
          };
        });

        const entries: VoucherEntry[] = [];
        if (isSales) {
          entries.push({ ledger: counterpartyId, ledgerName: party?.name || '', ledgerGroup: 'Assets', debit: grandTotal, credit: 0 });
          for (const it of invoiceItems) entries.push({ ledger: it.item_ledger, ledgerName: it.itemName, ledgerGroup: 'Income', debit: 0, credit: it.amount });
          if (gstLedger) entries.push({ ledger: gstLedger.id, ledgerName: 'Output GST', ledgerGroup: 'Liabilities', debit: 0, credit: totalGst });
        } else {
          if (purchasePostTo === 'inventory') {
            const inventoryLedger = await ensureInventoryLedger();
            if (inventoryLedger) entries.push({ ledger: inventoryLedger.id, ledgerName: 'Inventory', ledgerGroup: 'Assets', debit: subtotal, credit: 0 });
          } else {
            for (const it of invoiceItems) entries.push({ ledger: it.item_ledger, ledgerName: it.itemName, ledgerGroup: 'Expenses', debit: it.amount, credit: 0 });
          }
          if (gstLedger) entries.push({ ledger: gstLedger.id, ledgerName: 'Input GST', ledgerGroup: 'Assets', debit: totalGst, credit: 0 });
          entries.push({ ledger: counterpartyId, ledgerName: party?.name || '', ledgerGroup: 'Liabilities', debit: 0, credit: grandTotal });
        }

        const values: Record<string, unknown> = {
          date: String(form.get('date') || today),
          type,
          reference: String(form.get('reference') || '').trim(),
          counterparty: party?.name || '',
          project: project?.name || '',
          notes: String(form.get('notes') || '').trim(),
          entries,
          total: grandTotal,
          counterparty_ledger: counterpartyId,
          project_ledger: projectId || undefined,
          credit_days: num(creditDays),
          items: invoiceItems,
        };
        if (isSales) values.sale_type = saleType;
        else values.purchase_type = 'goods';
        if (isPurchase) values.post_to = purchasePostTo;

        if (voucher) await pb.collection('vouchers').update(voucher.id, values);
        else await pb.collection('vouchers').create({ ...values, owner: pb.authStore.record?.id });
      } else if (isExpense) {
        if (!expenseLedgerId) { setError('Select an expense ledger.'); setBusy(false); return; }
        if (!creditLedgerId) { setError('Select a credit ledger (bank, cash, supplier or client).'); setBusy(false); return; }
        const amt = num(expenseAmount);
        if (amt <= 0) { setError('Enter a valid amount.'); setBusy(false); return; }
        const expLedger = allLedgers.find((l) => l.id === expenseLedgerId);
        const crLedger = allLedgers.find((l) => l.id === creditLedgerId);
        const expProject = projects.find((p) => p.id === expenseProjectId);
        const tdsRateNum = num(tdsRate);
        const tdsAmount = tdsRateNum > 0 && tdsSection ? Math.round(amt * tdsRateNum) / 100 : 0;
        const entries: VoucherEntry[] = [
          { ledger: expenseLedgerId, ledgerName: expLedger?.name || '', ledgerGroup: 'Expenses', debit: amt, credit: 0 },
          { ledger: creditLedgerId, ledgerName: crLedger?.name || '', ledgerGroup: crLedger?.group, debit: 0, credit: amt - tdsAmount },
        ];
        if (tdsAmount > 0) {
          const tdsLedger = await ensureTdsLedger();
          if (tdsLedger) entries.push({ ledger: tdsLedger.id, ledgerName: 'TDS Payable', ledgerGroup: 'Liabilities', debit: 0, credit: tdsAmount });
        }
        const values = {
          date: String(form.get('date') || today),
          type: 'Expense',
          reference: String(form.get('reference') || '').trim(),
          counterparty: crLedger?.name || '',
          notes: String(form.get('notes') || '').trim() + (tdsSection ? ` · TDS ${tdsSection} @ ${tdsRateNum}%` : ''),
          entries,
          total: amt,
          project: expProject?.name || '',
          project_ledger: expenseProjectId || undefined,
        };
        if (voucher) await pb.collection('vouchers').update(voucher.id, values);
        else await pb.collection('vouchers').create({ ...values, owner: pb.authStore.record?.id });
      } else if (isBankCash) {
        if (!bankCashLedgerId) { setError('Select a bank or cash ledger.'); setBusy(false); return; }
        const validRows = bankCashRows.filter((r) => r.ledger && num(r.amount) > 0);
        if (!validRows.length) { setError('Add at least one ledger row with an amount.'); setBusy(false); return; }
        const bcLedger = allLedgers.find((l) => l.id === bankCashLedgerId);
        const entries: VoucherEntry[] = [];
        for (const r of validRows) {
          const ledger = allLedgers.find((l) => l.id === r.ledger);
          if (entryKind === 'payment') {
            entries.push({ ledger: r.ledger, ledgerName: ledger?.name || '', ledgerGroup: ledger?.group, debit: num(r.amount), credit: 0, date: r.date });
          } else {
            entries.push({ ledger: r.ledger, ledgerName: ledger?.name || '', ledgerGroup: ledger?.group, debit: 0, credit: num(r.amount), date: r.date });
          }
        }
        entries.push({
          ledger: bankCashLedgerId,
          ledgerName: bcLedger?.name || '',
          ledgerGroup: 'Assets',
          debit: entryKind === 'receipt' ? bankCashTotal : 0,
          credit: entryKind === 'payment' ? bankCashTotal : 0,
          date: String(form.get('date') || today),
        });
        const values = {
          date: String(form.get('date') || today),
          type,
          reference: String(form.get('reference') || '').trim(),
          counterparty: bcLedger?.name || '',
          notes: String(form.get('notes') || '').trim(),
          entries,
          total: bankCashTotal,
          entry_kind: entryKind,
          bank_cash_ledger: bankCashLedgerId,
        };
        if (voucher) await pb.collection('vouchers').update(voucher.id, values);
        else await pb.collection('vouchers').create({ ...values, owner: pb.authStore.record?.id });
      } else {
        const validRows = rows.filter((r) => r.ledger);
        const entries: VoucherEntry[] = validRows.map((r) => {
          const ledger = allLedgers.find((l) => l.id === r.ledger);
          return { ledger: r.ledger, ledgerName: ledger?.name || '', ledgerGroup: ledger?.group, debit: num(r.debit), credit: num(r.credit) };
        });
        if (entries.length < 2) { setError('A voucher needs at least two ledger lines.'); setBusy(false); return; }
        if (!balanced) { setError('Total debits and credits must be equal.'); setBusy(false); return; }
        const values = {
          date: String(form.get('date') || today),
          type,
          reference: String(form.get('reference') || '').trim(),
          counterparty: String(form.get('counterparty') || '').trim(),
          notes: String(form.get('notes') || '').trim(),
          project: String(form.get('project') || '').trim(),
          entries,
          total: totalDebit,
        };
        if (voucher) await pb.collection('vouchers').update(voucher.id, values);
        else await pb.collection('vouchers').create({ ...values, owner: pb.authStore.record?.id });
      }
      setOpen(false);
      reset();
      onSaved?.();
    } catch {
      setError('This voucher couldn’t be saved. Try again.');
    } finally {
      setBusy(false);
    }
  }

  const typeLabel = useMemo(() => {
    const labels: Record<string, string> = {
      Sales: 'sales invoice', Purchase: 'purchase entry', Expense: 'expense voucher',
      Bank: 'bank voucher', Cash: 'cash voucher', Journal: 'journal', Transfer: 'transfer',
    };
    return labels[type] || 'voucher';
  }, [type]);

  const partyLabel = isSales ? 'Client name' : isPurchase ? 'Supplier / creditor name' : 'Counterparty';
  const canSave = isInvoice
    ? !!(counterpartyId && itemRows.some((r) => r.item_ledger))
    : isExpense
      ? !!(expenseLedgerId && creditLedgerId && num(expenseAmount) > 0)
      : isBankCash
        ? !!(bankCashLedgerId && bankCashRows.some((r) => r.ledger && num(r.amount) > 0))
        : balanced;

  return (
    <>
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!busy && !creating && !creatingSubgroup && !justSavedLedgerRef.current) {
            setOpen(value);
            if (value) reset();
            else onClose?.();
          }
        }}
      >
        <button
          onClick={() => setOpen(true)}
          className={voucher ? 'icon-button table-edit' : 'button button-primary'}
          aria-label={voucher ? `Edit ${typeLabel}` : `Record ${typeLabel}`}
          style={hideTrigger ? { display: 'none' } : undefined}
        >
          {voucher ? <Pencil size={15} /> : (
            <>
              {isBankCash ? <ArrowRightLeft size={17} /> : <Plus size={17} />}
              {defaultType ? `Record ${typeLabel}` : 'New voucher'}
            </>
          )}
        </button>
        <DialogContent
          className="record-dialog payroll-details-dialog invoice-dialog"
          onInteractOutside={(e) => { if (creating || creatingSubgroup || justSavedLedgerRef.current) e.preventDefault(); }}
          onEscapeKeyDown={(e) => { if (creating || creatingSubgroup || justSavedLedgerRef.current) e.preventDefault(); }}
        >
          <DialogTitle>
            {voucher ? 'Edit' : 'Record'} {typeLabel}<span className="accent-dot">.</span>
          </DialogTitle>
          <DialogDescription>
            {isSales && 'Double-entry sales invoice — debits the client, credits each item’s income ledger and output GST.'}
            {isPurchase && 'Double-entry purchase entry — debits each item and input GST, credits the supplier.'}
            {isExpense && 'Double-entry expense voucher — debits the expense ledger, credits the bank / cash / supplier / client ledger.'}
            {isBankCash && 'Double-entry bank / cash voucher — payment debits ledgers and credits the bank/cash ledger; receipt is the reverse.'}
            {!isInvoice && !isExpense && !isBankCash && 'Double-entry voucher — every debit has a matching credit.'}
          </DialogDescription>
          <form onSubmit={save}>
            <div className="record-fields">
              {choices.length > 1 && (
                <label>
                  Voucher type<span className="required"> *</span>
                  <select name="type" value={type} onChange={(e) => setType(e.target.value)}>
                    {choices.map((t) => (<option key={t} value={t}>{t}</option>))}
                  </select>
                </label>
              )}
              <label>
                Date<span className="required"> *</span>
                <input name="date" type="date" defaultValue={voucher?.date || today} required />
              </label>
              <label>
                Reference / invoice no.
                <input name="reference" defaultValue={voucher?.reference || ''} maxLength={200} />
              </label>
              {isInvoice && (
                <label>
                  Credit period (days)
                  <input name="credit_days" type="number" min={0} value={creditDays} onChange={(e) => setCreditDays(e.target.value)} placeholder="0" />
                </label>
              )}
              {!isInvoice && !isExpense && !isBankCash && (
                <label>
                  Counterparty
                  <input name="counterparty" defaultValue={voucher?.counterparty || ''} maxLength={200} placeholder="Customer / supplier" />
                </label>
              )}
            </div>

            {isInvoice && (
              <>
                <div className="record-fields">
                  <label className="field-wide">
                    {partyLabel}<span className="required"> *</span>
                    <select
                      value={counterpartyId}
                      onChange={(e) => { if (e.target.value === '__new__') setCreating('party'); else setCounterpartyId(e.target.value); }}
                    >
                      <option value="">Select {isSales ? 'client' : 'supplier'}…</option>
                      {(isSales ? clients : suppliers).map((p) => (
                        <option key={p.id} value={p.id}>{p.name}{p.gstin ? ` · ${p.gstin}` : ''}</option>
                      ))}
                      <option value="__new__">+ Create new {isSales ? 'client' : 'supplier'}</option>
                    </select>
                  </label>
                  <label className="field-wide">
                    Project / section
                    <select
                      value={projectId}
                      onChange={(e) => { if (e.target.value === '__new__') setCreating('project'); else setProjectId(e.target.value); }}
                    >
                      <option value="">Select project (optional)…</option>
                      {projects.map((p) => (<option key={p.id} value={p.id}>{p.name}</option>))}
                      <option value="__new__">+ Create new project</option>
                    </select>
                  </label>
                </div>

                {isSales && (
                  <div className="sale-type-toggle">
                    <span className="sale-type-label">Sale type</span>
                    <div className="sale-type-options">
                      <button type="button" className={saleType === 'goods' ? 'active' : ''} onClick={() => setSaleType('goods')}>Goods sale</button>
                      <button type="button" className={saleType === 'service' ? 'active' : ''} onClick={() => setSaleType('service')}>Service sale</button>
                    </div>
                  </div>
                )}
                {isPurchase && (
                  <div className="sale-type-toggle">
                    <span className="sale-type-label">Purchase type</span>
                    <div className="sale-type-options">
                      <button type="button" className="active">Goods purchase</button>
                    </div>
                  </div>
                )}
                {isPurchase && (
                  <div className="sale-type-toggle">
                    <span className="sale-type-label">Post purchase to<span className="required"> *</span></span>
                    <div className="sale-type-options">
                      <button type="button" className={purchasePostTo === 'inventory' ? 'active' : ''} onClick={() => setPurchasePostTo('inventory')}>Post to Inventory</button>
                      <button type="button" className={purchasePostTo === 'expense' ? 'active' : ''} onClick={() => setPurchasePostTo('expense')}>Post as Expense</button>
                    </div>
                    <span className="small-note" style={{ marginLeft: 'auto' }}>{purchasePostTo === 'inventory' ? 'Increases stock & inventory value — not a P&L expense.' : 'Posts directly to the item expense ledger & P&L.'}</span>
                  </div>
                )}

                <div className="invoice-items">
                  <div className={`invoice-items-head ${isPurchase || saleType === 'goods' ? 'goods' : 'service'}`}>
                    {isPurchase || saleType === 'goods' ? (
                      <>
                        <span>Item</span><span>Code</span><span>HSN</span><span>Qty</span><span>Rate</span><span>Disc %</span><span>GST %</span><span className="align-right">Amount</span><span />
                      </>
                    ) : (
                      <>
                        <span>Service</span><span>Code</span><span>HSN</span><span>Qty / Nos</span><span>Rate</span><span className="align-right">Amount</span><span>GST %</span><span className="align-right">GST</span><span />
                      </>
                    )}
                  </div>
                  {itemRows.map((row, index) => (
                    <div className={`invoice-item-row ${isPurchase || saleType === 'goods' ? 'goods' : 'service'}`} key={index}>
                      <select value={row.item_ledger} onChange={(e) => pickItem(index, e.target.value)}>
                        <option value="">Select {isPurchase || saleType === 'goods' ? 'item' : 'service'}…</option>
                        {items.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
                        <option value="__new__">+ Create new {isPurchase || saleType === 'goods' ? 'item' : 'service'}</option>
                      </select>
                      <input value={row.item_code} onChange={(e) => updateItem(index, { item_code: e.target.value })} placeholder="Code" />
                      <input value={row.hsn} onChange={(e) => updateItem(index, { hsn: e.target.value })} placeholder="HSN" />
                      {isPurchase || saleType === 'goods' ? (
                        <>
                          <input type="number" step="0.01" min={0} value={row.qty} onChange={(e) => updateItem(index, { qty: e.target.value })} placeholder="Qty" />
                          <input type="number" step="0.01" min={0} value={row.rate} onChange={(e) => updateItem(index, { rate: e.target.value })} placeholder="Rate" />
                          <input type="number" step="0.01" min={0} value={row.discount} onChange={(e) => updateItem(index, { discount: e.target.value })} placeholder="0" />
                          <input type="number" step="0.01" min={0} value={row.gst_rate} onChange={(e) => updateItem(index, { gst_rate: e.target.value })} placeholder="0" />
                          <span className="invoice-cell-amount">{money(computedItems[index].amount)}</span>
                        </>
                      ) : (
                        <>
                          <input value={row.qtyText} onChange={(e) => updateItem(index, { qtyText: e.target.value })} placeholder="e.g. Monthly / 1" />
                          <input type="number" step="0.01" min={0} value={row.rate} onChange={(e) => updateItem(index, { rate: e.target.value })} placeholder="Rate (opt)" />
                          <input type="number" step="0.01" min={0} value={row.amount} onChange={(e) => updateItem(index, { amount: e.target.value })} placeholder="Amount" />
                          <input type="number" step="0.01" min={0} value={row.gst_rate} onChange={(e) => updateItem(index, { gst_rate: e.target.value })} placeholder="0" />
                          <span className="invoice-cell-amount">{money(computedItems[index].gst)}</span>
                        </>
                      )}
                      <button type="button" className="icon-button table-delete" onClick={() => removeItem(index)} aria-label="Remove line"><Trash2 size={14} /></button>
                    </div>
                  ))}
                  <button type="button" className="button button-quiet button-small voucher-add-row" onClick={addItem}>
                    <Plus size={14} />Add {isPurchase || saleType === 'goods' ? 'item' : 'service'} line
                  </button>
                  <div className="invoice-totals">
                    <span>Subtotal <strong>{money(subtotal)}</strong></span>
                    <span>GST <strong>{money(totalGst)}</strong></span>
                    <span className="invoice-grand">Grand total <strong>{money(grandTotal)}</strong></span>
                  </div>
                </div>
              </>
            )}

            {isExpense && (
              <div className="record-fields" style={{ marginTop: 18 }}>
                <label className="field-wide">
                  Project / section
                  <select value={expenseProjectId} onChange={(e) => { if (e.target.value === '__new__') setCreating('project'); else setExpenseProjectId(e.target.value); }}>
                    <option value="">Select project (optional)…</option>
                    {projects.map((p) => (<option key={p.id} value={p.id}>{p.name}</option>))}
                    <option value="__new__">+ Create new project</option>
                  </select>
                </label>
                <label className="field-wide">
                  Expense ledger<span className="required"> *</span>
                  <select value={expenseLedgerId} onChange={(e) => { if (e.target.value === '__new__') setCreating('account'); else setExpenseLedgerId(e.target.value); }}>
                    <option value="">Select expense ledger…</option>
                    {expenseLedgers.map((l) => (<option key={l.id} value={l.id}>{l.name} · {l.subgroup}</option>))}
                    <option value="__new__">+ Create new expense ledger</option>
                  </select>
                </label>
                <label>
                  Amount<span className="required"> *</span>
                  <input type="number" step="0.01" min={0.01} value={expenseAmount} onChange={(e) => setExpenseAmount(e.target.value)} placeholder="0.00" />
                </label>
                <label className="field-wide">
                  Credit ledger (bank / cash / supplier / client)<span className="required"> *</span>
                  <select value={creditLedgerId} onChange={(e) => { if (e.target.value === '__new__') setCreating('party'); else setCreditLedgerId(e.target.value); }}>
                    <option value="">Select credit ledger…</option>
                    {creditLedgerOptions.map((l) => (<option key={l.id} value={l.id}>{l.name} · {l.subgroup}</option>))}
                    <option value="__new__">+ Create new ledger</option>
                  </select>
                </label>
                <label>
                  TDS section
                  <select value={tdsSection} onChange={(e) => setTdsSection(e.target.value)}>
                    <option value="">No TDS</option>
                    <option value="194C">194C — Contract</option>
                    <option value="194J">194J — Professional services</option>
                    <option value="194I">194I — Rent</option>
                    <option value="194H">194H — Commission</option>
                    <option value="194Q">194Q — Purchase of goods</option>
                  </select>
                </label>
                <label>
                  TDS rate (%)
                  <input type="number" step="0.01" min={0} value={tdsRate} onChange={(e) => setTdsRate(e.target.value)} placeholder="0" />
                </label>
              </div>
            )}

            {isBankCash && (
              <>
                <div className="sale-type-toggle">
                  <span className="sale-type-label">Voucher</span>
                  <div className="sale-type-options">
                    <button type="button" className={type === 'Bank' ? 'active' : ''} onClick={() => setType('Bank')}>Bank voucher</button>
                    <button type="button" className={type === 'Cash' ? 'active' : ''} onClick={() => setType('Cash')}>Cash voucher</button>
                  </div>
                </div>
                <div className="sale-type-toggle">
                  <span className="sale-type-label">Entry type</span>
                  <div className="sale-type-options">
                    <button type="button" className={entryKind === 'payment' ? 'active' : ''} onClick={() => setEntryKind('payment')}>Payment entry</button>
                    <button type="button" className={entryKind === 'receipt' ? 'active' : ''} onClick={() => setEntryKind('receipt')}>Receipt entry</button>
                  </div>
                </div>
                <div className="record-fields" style={{ marginTop: 18 }}>
                  <label className="field-wide">
                    {type === 'Bank' ? 'Bank' : 'Cash'} ledger<span className="required"> *</span>
                    <select value={bankCashLedgerId} onChange={(e) => { if (e.target.value === '__new__') setCreating('account'); else setBankCashLedgerId(e.target.value); }}>
                      <option value="">Select {type === 'Bank' ? 'bank' : 'cash'} ledger…</option>
                      {bankCashLedgers.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
                      <option value="__new__">+ Create new {type === 'Bank' ? 'bank' : 'cash'} ledger</option>
                    </select>
                  </label>
                </div>

                <div className="voucher-entries" style={{ marginTop: 16 }}>
                  <div className="voucher-entries-head bankcash-head">
                    <span>Posting date</span><span>Ledger name</span><span>Amount (₹)</span><span />
                  </div>
                  {bankCashRows.map((row, index) => (
                    <div className="voucher-entry-row bankcash-row" key={index}>
                      <input type="date" value={row.date} onChange={(e) => updateBankRow(index, { date: e.target.value })} />
                      <select value={row.ledger} onChange={(e) => { if (e.target.value === '__new__') setCreating('account'); else updateBankRow(index, { ledger: e.target.value }); }}>
                        <option value="">Select ledger…</option>
                        {allLedgers.filter((l) => l.kind !== 'project' && l.kind !== 'item' && l.id !== bankCashLedgerId).map((l) => (
                          <option key={l.id} value={l.id}>{l.name} · {l.group}</option>
                        ))}
                        <option value="__new__">+ Create new ledger</option>
                      </select>
                      <input type="number" step="0.01" min={0} value={row.amount} onChange={(e) => updateBankRow(index, { amount: e.target.value })} placeholder="0" />
                      <button type="button" className="icon-button table-delete" onClick={() => removeBankRow(index)} aria-label="Remove row"><Trash2 size={14} /></button>
                    </div>
                  ))}
                  <button type="button" className="button button-quiet button-small voucher-add-row" onClick={addBankRow}><Plus size={14} />Add row</button>
                  <div className="voucher-totals">
                    <span>Total <strong>{money(bankCashTotal)}</strong></span>
                    {bankCashLedger && (
                      <>
                        <span>Opening <strong>{money(bankOpening)}</strong></span>
                        <span>Closing <strong>{money(bankClosing)}</strong></span>
                      </>
                    )}
                  </div>
                </div>
              </>
            )}

            {!isInvoice && !isExpense && !isBankCash && (
              <>
                <div className="voucher-entries">
                  <div className="voucher-entries-head">
                    <span>Ledger</span><span>Debit (₹)</span><span>Credit (₹)</span><span />
                  </div>
                  {rows.map((row, index) => (
                    <div className="voucher-entry-row" key={index}>
                      <select value={row.ledger} onChange={(e) => updateRow(index, { ledger: e.target.value })}>
                        <option value="">Select ledger…</option>
                        {allLedgers.filter(isPostingLedger).map((l) => (
                          <option key={l.id} value={l.id}>{l.name} · {l.group}</option>
                        ))}
                      </select>
                      <input type="number" step="0.01" min={0} value={row.debit} onChange={(e) => updateRow(index, { debit: e.target.value, credit: '' })} placeholder="0" />
                      <input type="number" step="0.01" min={0} value={row.credit} onChange={(e) => updateRow(index, { credit: e.target.value, debit: '' })} placeholder="0" />
                      <button type="button" className="icon-button table-delete" onClick={() => removeRow(index)} aria-label="Remove line"><Trash2 size={14} /></button>
                    </div>
                  ))}
                  <button type="button" className="button button-quiet button-small voucher-add-row" onClick={addRow}><Plus size={14} />Add line</button>
                  <div className="voucher-totals">
                    <span>Total debit <strong>{money(totalDebit)}</strong></span>
                    <span>Total credit <strong>{money(totalCredit)}</strong></span>
                    <span className={balanced ? 'voucher-balanced' : 'voucher-unbalanced'}>
                      {balanced ? 'Balanced' : `Difference ${money(Math.abs(totalDebit - totalCredit))}`}
                    </span>
                  </div>
                </div>
              </>
            )}

            <div className="record-fields" style={{ marginTop: 18 }}>
              <label className="field-wide">
                Narration / notes
                <input name="notes" defaultValue={voucher?.notes || ''} maxLength={2000} placeholder="Optional notes" />
              </label>
            </div>

            {error && <p className="form-error" role="alert">{error}</p>}
            <div className="dialog-actions">
              <button className="button button-quiet" type="button" disabled={busy} onClick={() => setOpen(false)}><X size={16} />Close voucher</button>
              <button className="button button-primary" disabled={busy || !canSave}>
                {busy ? 'Saving…' : 'Save voucher'}<ArrowUpRight size={17} />
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {creating && creating !== 'account' && (
        <EntityEditor
          kind={creating}
          subgroupOverride={creating === 'party' && isPurchase ? 'Supplier Outstanding' : undefined}
          open={!!creating}
          onOpenChange={(v) => { if (!v) setCreating(null); }}
          onSaved={(ledger) => {
            setExtraLedgers((prev) => [...prev, ledger]);
            if (creating === 'party') {
              if (isExpense) setCreditLedgerId(ledger.id);
              else setCounterpartyId(ledger.id);
            } else if (creating === 'project') {
              setProjectId(ledger.id);
            } else if (creating === 'item') {
              setItemRows((prev) => {
                const next = [...prev];
                const emptyIdx = next.findIndex((r) => !r.item_ledger);
                const idx = emptyIdx >= 0 ? emptyIdx : (next.push(emptyItem()) - 1);
                next[idx] = { ...next[idx], item_ledger: ledger.id, item_code: ledger.item_code || '', hsn: ledger.hsn_code || '', gst_rate: ledger.gst_rate != null ? String(ledger.gst_rate) : '' };
                return next;
              });
            }
            flagJustSavedLedger();
            setCreating(null);
          }}
        />
      )}
      {creating === 'account' && (
        <LedgerEditor
          ledger={undefined}
          forcedOpen
          hideTrigger
          defaultGroup={isExpense ? 'Expenses' : isBankCash ? 'Assets' : undefined}
          defaultSubgroup={isExpense ? 'Indirect Expenses' : isBankCash ? 'Bank & Cash' : undefined}
          onSaved={(ledger) => {
            setExtraLedgers((prev) => [...prev, ledger]);
            if (isExpense) setExpenseLedgerId(ledger.id);
            else if (isBankCash) setBankCashLedgerId(ledger.id);
            else setCreditLedgerId(ledger.id);
            flagJustSavedLedger();
            setCreating(null);
          }}
        />
      )}
    </>
  );
}
