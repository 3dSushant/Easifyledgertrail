import { useState } from 'react';
import { Package, Search, Download, ArrowUpRight, Plus } from 'lucide-react';
import { Link } from 'react-router';
import type { Ledger, Voucher } from '@/lib/accounts';
import { money, exportCsv } from '@/lib/accounts';
import { inventoryAnalysis } from '@/lib/receivables';
import { SummaryCards } from '@/components/workspace/summary-cards';
import { VoucherMenu } from './voucher-menu';

export function Inventory({
  ledgers, vouchers, today,
}: { ledgers: Ledger[]; vouchers: Voucher[]; today: string }) {
  const [query, setQuery] = useState('');
  const [stockFilter, setStockFilter] = useState('all');
  const analysis = inventoryAnalysis(ledgers, vouchers);

  const filtered = analysis.rows.filter((r) => {
    if (query) {
      const q = query.toLowerCase();
      if (!`${r.ledger.name} ${r.ledger.item_code || ''} ${r.ledger.hsn_code || ''}`.toLowerCase().includes(q)) return false;
    }
    if (stockFilter === 'in') return r.balanceQty > 0;
    if (stockFilter === 'out') return r.balanceQty <= 0;
    return true;
  });

  function download() {
    exportCsv(
      'ledgerly-inventory.csv',
      ['Item', 'Code', 'Purchased qty', 'Purchased value (INR)', 'Sold qty', 'Sold value (INR)', 'Balance qty', 'Avg rate (INR)', 'Stock value (INR)'],
      filtered.map((r) => [r.ledger.name, r.ledger.item_code || '', r.purchasedQty, r.purchasedValue, r.soldQty, r.soldValue, r.balanceQty, r.avgRate, r.stockValue]),
    );
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">STOCK & INVENTORY</span>
          <h1>Inventory<span>.</span></h1>
          <p>Item-wise stock from purchase (Post to Inventory) and sales vouchers.</p>
        </div>
        <div className="heading-actions">
          <VoucherMenu section="Purchase" ledgers={ledgers} vouchers={vouchers} today={today} onSaved={() => {}} />
        </div>
      </div>

      <SummaryCards items={[
        { label: 'Total purchased', value: money(analysis.totalPurchasedValue), detail: 'Value of inventory-posted purchases' },
        { label: 'Total used / sold', value: money(analysis.totalSoldValue), detail: 'Sold quantity valued at cost' },
        { label: 'Current balance', value: String(analysis.totalBalanceQty), detail: 'Units in stock across all items' },
        { label: 'Total inventory value', value: money(analysis.totalStockValue), detail: 'Balance quantity × average cost', highlight: true },
      ]} />

      <section className="dashboard-panel">
        <div className="panel-heading">
          <div>
            <h2>Item-wise stock <span className="count-label">{filtered.length}</span></h2>
            <p>Purchase adds stock; sales reduces it. Create a sales invoice from the Record Transaction tab.</p>
          </div>
          <button className="button button-quiet button-small" onClick={download} disabled={!filtered.length}><Download size={15} />Export CSV</button>
        </div>

        <div className="table-filters">
          <label className="search-control">
            <Search size={16} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search item, code or HSN…" aria-label="Search inventory" />
          </label>
          <select value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} aria-label="Stock status">
            <option value="all">All items</option>
            <option value="in">In stock</option>
            <option value="out">Out of stock</option>
          </select>
        </div>

        {filtered.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Item</th><th>Code</th><th className="align-right">Purchased qty</th><th className="align-right">Purchased value</th><th className="align-right">Sold qty</th><th className="align-right">Balance qty</th><th className="align-right">Avg rate</th><th className="align-right">Stock value</th><th className="align-right">Sell</th></tr></thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.ledger.id}>
                    <td><strong>{r.ledger.name}</strong><small>{r.ledger.hsn_code || '—'}</small></td>
                    <td>{r.ledger.item_code || '—'}</td>
                    <td className="align-right">{r.purchasedQty}</td>
                    <td className="align-right">{money(r.purchasedValue)}</td>
                    <td className="align-right">{r.soldQty}</td>
                    <td className="align-right amount-cell">{r.balanceQty}</td>
                    <td className="align-right">{money(r.avgRate)}</td>
                    <td className="align-right amount-cell">{money(r.stockValue)}</td>
                    <td className="align-right"><Link className="icon-button table-edit" to="/app/accounts" aria-label="Record sale"><ArrowUpRight size={16} /></Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="large-empty">
            <Package size={42} strokeWidth={1.3} />
            <h3>{analysis.rows.length ? 'No matching items.' : 'Your inventory starts here.'}</h3>
            <p>{analysis.rows.length ? 'Try another search or stock filter.' : 'Create item ledgers and post purchases to inventory to track stock, value and movement.'}</p>
            <Link to="/app/accounts" className="button button-primary button-small"><Plus size={15} />Record a purchase</Link>
          </div>
        )}
      </section>

      <div className="workspace-help">
        <Package size={17} />
        <span>Stock is derived from purchase vouchers marked “Post to Inventory” and reduced by sales. Post as Expense purchases do not affect stock.</span>
      </div>
    </>
  );
}
