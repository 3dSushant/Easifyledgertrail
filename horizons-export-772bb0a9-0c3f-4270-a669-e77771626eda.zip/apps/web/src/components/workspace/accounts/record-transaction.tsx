import { useState } from 'react';
import { Form, useSearchParams } from 'react-router';
import { Search, Download, Receipt, ShoppingCart, Wallet, Banknote, BookText, ArrowUpRight, FileSpreadsheet } from 'lucide-react';
import type { Ledger, Voucher } from '@/lib/accounts';
import { money, dateLabel, exportCsv } from '@/lib/accounts';
import { VoucherDetail } from './voucher-detail';
import { VoucherMenu, type MenuSection } from './voucher-menu';
import { LedgerEditor, SubgroupEditor } from './ledger-editor';
import { BulkImport } from './bulk-import';

const SECTIONS = [
  { id: 'Sales', label: 'Sales Invoice', icon: Receipt, types: ['Sales'], defaultType: 'Sales', typeChoices: ['Sales'], menu: 'Sales' as MenuSection },
  { id: 'Purchase', label: 'Purchase Entry', icon: ShoppingCart, types: ['Purchase'], defaultType: 'Purchase', typeChoices: ['Purchase'], menu: 'Purchase' as MenuSection },
  { id: 'Expense', label: 'Expenses', icon: Wallet, types: ['Expense'], defaultType: 'Expense', typeChoices: ['Expense'], menu: 'Expense' as MenuSection },
  { id: 'BankCash', label: 'Bank & Cash', icon: Banknote, types: ['Bank', 'Cash', 'Transfer'], defaultType: 'Bank', typeChoices: ['Bank', 'Cash', 'Transfer'], menu: 'BankCash' as MenuSection },
] as const;

type SectionId = (typeof SECTIONS)[number]['id'];

export function RecordTransaction({
  ledgers, vouchers, today,
}: { ledgers: Ledger[]; vouchers: Voucher[]; today: string }) {
  const [section, setSection] = useState<SectionId>('Sales');
  const [params] = useSearchParams();
  const [openVoucher, setOpenVoucher] = useState<Voucher | null>(null);

  const query = params.get('q') || '';
  const period = params.get('period') || 'all';
  const from = params.get('from') || '';
  const to = params.get('to') || '';

  const activeSection = SECTIONS.find((s) => s.id === section)!;

  if (openVoucher) {
    return (
      <VoucherDetail
        voucher={openVoucher}
        ledgers={ledgers}
        today={today}
        onBack={() => setOpenVoucher(null)}
      />
    );
  }

  const list = vouchers
    .filter((v) => (activeSection.types as readonly string[]).includes(v.type))
    .filter((v) => `${v.reference || ''} ${v.counterparty || ''} ${v.notes || ''} ${v.project || ''} ${v.total || 0}`.toLowerCase().includes(query.toLowerCase()))
    .filter((v) => {
      if (period === 'all' && !from && !to) return true;
      const d = v.date || '';
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (period === 'daily' && d !== today) return false;
      if (period === 'monthly' && !d.startsWith(today.slice(0, 7))) return false;
      if (period === 'yearly' && !d.startsWith(today.slice(0, 4))) return false;
      return true;
    });

  function download() {
    exportCsv(
      `ledgerly-${section.toLowerCase()}.csv`,
      ['Date', 'Reference', 'Counterparty', 'Project', 'Amount (INR)', 'Notes'],
      list.map((v) => [v.date || '', v.reference || '', v.counterparty || '', v.project || '', v.total || 0, v.notes || '']),
    );
  }

  function downloadTemplate() {
    const templates: Record<SectionId, { name: string; headers: string[]; sample: (string | number)[] }> = {
      Sales: { name: 'sales-invoices', headers: ['Date', 'Reference', 'Client', 'Item', 'HSN', 'Qty', 'Rate', 'Discount%', 'GST%', 'Credit days'], sample: ['2026-01-15', 'INV-001', 'Acme Client', 'Product A', '9911', '10', '500', '0', '18', '30'] },
      Purchase: { name: 'purchase-invoices', headers: ['Date', 'Reference', 'Supplier', 'Item', 'HSN', 'Qty', 'Rate', 'Discount%', 'GST%', 'Post to (Inventory/Expense)'], sample: ['2026-01-15', 'BILL-001', 'Acme Supplier', 'Product A', '9911', '10', '400', '0', '18', 'Inventory'] },
      Expense: { name: 'expenses', headers: ['Date', 'Reference', 'Expense ledger', 'Amount (INR)', 'Credit ledger', 'Project'], sample: ['2026-01-15', 'EXP-001', 'Rent Expense', '15000', 'Bank Account', ''] },
      BankCash: { name: 'bank-cash', headers: ['Date', 'Bank/Cash ledger', 'Entry type (Payment/Receipt)', 'Ledger', 'Amount (INR)'], sample: ['2026-01-15', 'Bank Account', 'Payment', 'Rent Expense', '15000'] },
    };
    const t = templates[section];
    exportCsv(`ledgerly-${t.name}-template.csv`, t.headers, [t.sample]);
  }

  const total = list.reduce((s, v) => s + Number(v.total || 0), 0);

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">RECORD TRANSACTION</span>
          <h1>Record & review entries<span>.</span></h1>
          <p>Sales, purchases, expenses, bank and cash — all double-entry. Search, filter and drill into any voucher.</p>
        </div>
        <div className="heading-actions">
          <BulkImport ledgers={ledgers} today={today} onSaved={() => setOpenVoucher(null)} />
          <LedgerEditor small />
          <SubgroupEditor />
        </div>
      </div>

      <div className="workspace-tabs">
        {SECTIONS.map((s) => (
          <button key={s.id} className={section === s.id ? 'active' : ''} onClick={() => setSection(s.id)}>
            <s.icon size={15} /> {s.label}
          </button>
        ))}
      </div>

      <section className="dashboard-panel">
        <div className="panel-heading">
          <div>
            <h2>{activeSection.label} <span className="count-label">{list.length}</span></h2>
            <p>Total value: <strong>{money(total)}</strong></p>
          </div>
          <div className="heading-actions">
            <VoucherMenu section={activeSection.menu} ledgers={ledgers} vouchers={vouchers} today={today} onSaved={() => setOpenVoucher(null)} />
            <button className="button button-quiet button-small" onClick={download} disabled={!list.length}><Download size={15} />Export CSV</button>
            <button className="button button-quiet button-small" onClick={downloadTemplate}><FileSpreadsheet size={15} />Template</button>
          </div>
        </div>

        <Form method="get" className="table-filters" key={params.toString()}>
          <label className="search-control">
            <Search size={16} />
            <input name="q" defaultValue={query} placeholder="Search by invoice no, name, amount…" aria-label="Search" />
          </label>
          <select name="period" defaultValue={period} aria-label="Period">
            <option value="all">All time</option>
            <option value="daily">Today</option>
            <option value="monthly">This month</option>
            <option value="yearly">This year</option>
          </select>
          <label className="date-filter"><span>From</span><input type="date" name="from" defaultValue={from} aria-label="From date" /></label>
          <label className="date-filter"><span>To</span><input type="date" name="to" defaultValue={to} min={from || undefined} aria-label="To date" /></label>
          <button className="button button-dark button-small" type="submit">Apply</button>
          {params.toString() && <a className="filter-reset" href="/app/accounts">Reset</a>}
        </Form>

        {list.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Date</th><th>Reference</th><th>Counterparty</th><th>Project</th><th className="align-right">Amount</th><th className="align-right">Open</th></tr></thead>
              <tbody>
                {list.map((v) => (
                  <tr key={v.id} className="drill-row">
                    <td className="nowrap">{dateLabel(v.date)}</td>
                    <td><strong>{v.reference || '—'}</strong></td>
                    <td>{v.counterparty || '—'}</td>
                    <td>{v.project || '—'}</td>
                    <td className="align-right amount-cell">{money(v.total || 0)}</td>
                    <td className="align-right"><button className="icon-button table-edit" onClick={() => setOpenVoucher(v)} aria-label="Open voucher"><ArrowUpRight size={16} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="large-empty">
            <activeSection.icon size={42} strokeWidth={1.3} />
            <h3>No {activeSection.label.toLowerCase()} entries yet.</h3>
            <p>Record your first {activeSection.label.toLowerCase()} entry to see it here. Use the Create menu to set up ledgers, parties, projects and items first.</p>
          </div>
        )}
      </section>

      <div className="workspace-help">
        <BookText size={16} />
        <span>Double-entry system: every voucher debits one ledger and credits another. Create ledgers for every account — like Tally — before recording entries.</span>
      </div>
    </>
  );
}
