import { useState } from 'react';
import { Upload, Download, Check, X, ArrowUpRight, FileSpreadsheet, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { Ledger, Voucher, VoucherEntry, InvoiceItem } from '@/lib/accounts';
import { money, exportCsv } from '@/lib/accounts';

type ImportRow = {
  date: string;
  reference: string;
  clientName: string;
  itemName: string;
  hsn: string;
  qty: string;
  rate: string;
  discount: string;
  gstRate: string;
  creditDays: string;
};

type UnmatchedItem = { name: string; type: 'client' | 'item'; count: number; create: boolean };
type ImportError = { row: ImportRow; error: string };

const num = (s: string) => parseFloat(s) || 0;

function parseCsv(text: string): string[][] {
  return text.split(/\r?\n/).filter((l) => l.trim()).map((l) => l.split(',').map((c) => c.trim().replace(/^"|"$/g, '')));
}

export function BulkImport({ ledgers, today, onSaved }: { ledgers: Ledger[]; today: string; onSaved?: () => void }) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<'upload' | 'review' | 'results'>('upload');
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [unmatched, setUnmatched] = useState<UnmatchedItem[]>([]);
  const [errors, setErrors] = useState<ImportError[]>([]);
  const [successCount, setSuccessCount] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const parties = ledgers.filter((l) => l.kind === 'party');
  const items = ledgers.filter((l) => l.kind === 'item');

  function reset() {
    setStep('upload'); setRows([]); setUnmatched([]); setErrors([]); setSuccessCount(0); setError('');
  }

  function handleUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setError('');
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = parseCsv(String(reader.result || ''));
        if (data.length < 2) { setError('The file has no data rows.'); return; }
        const header = data[0].map((h) => h.toLowerCase().trim());
        const idx = (keys: string[]) => header.findIndex((h) => keys.some((k) => h.includes(k)));
        const iDate = idx(['date']);
        const iRef = idx(['reference', 'invoice']);
        const iClient = idx(['client', 'customer', 'party']);
        const iItem = idx(['item', 'service', 'product']);
        const iHsn = idx(['hsn']);
        const iQty = idx(['qty', 'quantity']);
        const iRate = idx(['rate', 'price']);
        const iDisc = idx(['disc']);
        const iGst = idx(['gst']);
        const iCredit = idx(['credit']);

        const parsed: ImportRow[] = data.slice(1).map((r) => ({
          date: iDate >= 0 ? r[iDate] : today,
          reference: iRef >= 0 ? r[iRef] : '',
          clientName: iClient >= 0 ? r[iClient] : '',
          itemName: iItem >= 0 ? r[iItem] : '',
          hsn: iHsn >= 0 ? r[iHsn] : '',
          qty: iQty >= 0 ? r[iQty] : '',
          rate: iRate >= 0 ? r[iRate] : '',
          discount: iDisc >= 0 ? r[iDisc] : '0',
          gstRate: iGst >= 0 ? r[iGst] : '0',
          creditDays: iCredit >= 0 ? r[iCredit] : '0',
        }));

        // Find unmatched names
        const clientCounts = new Map<string, number>();
        const itemCounts = new Map<string, number>();
        for (const r of parsed) {
          if (r.clientName && !parties.find((p) => p.name.toLowerCase() === r.clientName.toLowerCase())) {
            clientCounts.set(r.clientName, (clientCounts.get(r.clientName) || 0) + 1);
          }
          if (r.itemName && !items.find((i) => i.name.toLowerCase() === r.itemName.toLowerCase())) {
            itemCounts.set(r.itemName, (itemCounts.get(r.itemName) || 0) + 1);
          }
        }
        const um: UnmatchedItem[] = [
          ...Array.from(clientCounts.entries()).map(([name, count]) => ({ name, type: 'client' as const, count, create: false })),
          ...Array.from(itemCounts.entries()).map(([name, count]) => ({ name, type: 'item' as const, count, create: false })),
        ];
        setRows(parsed);
        setUnmatched(um);
        setStep('review');
      } catch {
        setError('Could not read the file. Please use the template CSV format.');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  }

  function toggleCreate(name: string) {
    setUnmatched((prev) => prev.map((u) => (u.name === name ? { ...u, create: !u.create } : u)));
  }

  // Compute review stats
  const validRows = rows.filter((r) => r.clientName && r.itemName && r.date);
  const invalidRows = rows.length - validRows.length;
  const unmatchedUnresolved = unmatched.filter((u) => !u.create);
  const toCreate = unmatched.filter((u) => u.create);

  // Compute totals
  const computed = validRows.map((r) => {
    const amount = num(r.qty) * num(r.rate) * (1 - num(r.discount) / 100);
    const gst = amount * (num(r.gstRate) / 100);
    return { ...r, amount, gst, grandTotal: amount + gst };
  });
  const totalDebit = computed.reduce((s, r) => s + r.grandTotal, 0);
  const totalCredit = totalDebit;

  async function ensureLedger(name: string, type: 'client' | 'item'): Promise<Ledger> {
    const existing = (type === 'client' ? parties : items).find((l) => l.name.toLowerCase() === name.toLowerCase());
    if (existing) return existing;
    const values = type === 'client'
      ? { name, group: 'Assets', subgroup: 'Receivables', kind: 'party', opening_balance: 0, owner: pb.authStore.record?.id }
      : { name, group: 'Income', subgroup: 'Sales', kind: 'item', opening_balance: 0, owner: pb.authStore.record?.id };
    const rec = await pb.collection('ledgers').create(values);
    return rec as Ledger;
  }

  async function ensureGstLedger(): Promise<Ledger | null> {
    const existing = ledgers.find((l) => l.name.toLowerCase() === 'output gst');
    if (existing) return existing;
    const rec = await pb.collection('ledgers').create({ name: 'Output GST', group: 'Liabilities', subgroup: 'Other Current Liabilities', kind: 'account', opening_balance: 0, owner: pb.authStore.record?.id });
    return rec as Ledger;
  }

  async function confirm() {
    setBusy(true); setError('');
    const errs: ImportError[] = [];
    let success = 0;

    try {
      // Create missing ledgers
      const ledgerCache = new Map<string, Ledger>();
      for (const u of toCreate) {
        const ledger = await ensureLedger(u.name, u.type);
        ledgerCache.set(`${u.type}:${u.name.toLowerCase()}`, ledger);
      }
      const gstLedger = await ensureGstLedger();

      // Group by reference
      type ComputedRow = ImportRow & { amount: number; gst: number; grandTotal: number };
      const groups = new Map<string, ComputedRow[]>();
      for (const r of computed) {
        const key = r.reference || `${r.date}-${r.clientName}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(r);
      }

      for (const [ref, groupRows] of groups) {
        try {
          const clientName = groupRows[0].clientName;
          const clientLedger = ledgerCache.get(`client:${clientName.toLowerCase()}`)
            || parties.find((p) => p.name.toLowerCase() === clientName.toLowerCase());
          if (!clientLedger) { groupRows.forEach((r) => errs.push({ row: r, error: 'Client ledger not found' })); continue; }

          const invoiceItems: InvoiceItem[] = [];
          let subtotal = 0;
          let totalGst = 0;

          for (const r of groupRows) {
            const itemLedger = ledgerCache.get(`item:${r.itemName.toLowerCase()}`)
              || items.find((i) => i.name.toLowerCase() === r.itemName.toLowerCase());
            if (!itemLedger) { errs.push({ row: r, error: 'Item ledger not found' }); continue; }
            invoiceItems.push({
              item_ledger: itemLedger.id,
              itemName: itemLedger.name,
              item_code: itemLedger.item_code || '',
              hsn: r.hsn,
              qty: num(r.qty),
              rate: num(r.rate),
              discount: num(r.discount),
              gst_rate: num(r.gstRate),
              amount: r.amount,
              gst_amount: r.gst,
            });
            subtotal += r.amount;
            totalGst += r.gst;
          }

          if (!invoiceItems.length) continue;

          const grandTotal = subtotal + totalGst;
          const entries: VoucherEntry[] = [
            { ledger: clientLedger.id, ledgerName: clientLedger.name, ledgerGroup: 'Assets', debit: grandTotal, credit: 0 },
          ];
          for (const it of invoiceItems) {
            entries.push({ ledger: it.item_ledger, ledgerName: it.itemName, ledgerGroup: 'Income', debit: 0, credit: it.amount });
          }
          if (gstLedger && totalGst > 0) {
            entries.push({ ledger: gstLedger.id, ledgerName: 'Output GST', ledgerGroup: 'Liabilities', debit: 0, credit: totalGst });
          }

          await pb.collection('vouchers').create({
            date: groupRows[0].date,
            type: 'Sales',
            reference: ref,
            counterparty: clientLedger.name,
            entries,
            total: grandTotal,
            counterparty_ledger: clientLedger.id,
            credit_days: num(groupRows[0].creditDays),
            sale_type: 'goods',
            items: invoiceItems,
            owner: pb.authStore.record?.id,
          }, { requestKey: `bulk-${ref}` });
          success++;
        } catch (e) {
          groupRows.forEach((r) => errs.push({ row: r, error: 'Failed to create voucher' }));
        }
      }

      setErrors(errs);
      setSuccessCount(success);
      setStep('results');
      if (errs.length === 0) onSaved?.();
    } catch {
      setError('The import failed. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function downloadErrors() {
    exportCsv('import-errors.csv', ['Date', 'Reference', 'Client', 'Item', 'Error'], errors.map((e) => [e.row.date, e.row.reference, e.row.clientName, e.row.itemName, e.error]));
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!busy) { setOpen(v); if (!v) reset(); } }}>
      <button className="button button-quiet button-small" onClick={() => setOpen(true)}>
        <Upload size={15} />Bulk import
      </button>
      <DialogContent className="record-dialog payroll-details-dialog" onInteractOutside={(e) => { if (busy) e.preventDefault(); }}>
        <DialogTitle>Bulk import — Sales invoices<span className="accent-dot">.</span></DialogTitle>
        <DialogDescription>Upload a CSV of sales invoices. Match client and item names, create missing records, review, then post as double-entry vouchers.</DialogDescription>

        {error && <p className="form-error" role="alert">{error}</p>}

        {step === 'upload' && (
          <div className="large-empty" style={{ minHeight: 280 }}>
            <Upload size={42} strokeWidth={1.3} />
            <h3>Upload your sales invoice CSV</h3>
            <p>Use the template format: Date, Reference, Client Name, Item Name, HSN, Qty, Rate, Discount%, GST%, Credit Days.</p>
            <label className="button button-primary">
              <Upload size={16} />Choose CSV file
              <input type="file" accept=".csv,text/csv" onChange={handleUpload} hidden />
            </label>
          </div>
        )}

        {step === 'review' && (
          <>
            <div className="summary-cards" style={{ marginBottom: 16 }}>
              <div className="summary-card"><div><FileSpreadsheet size={17} />Total rows</div><strong>{rows.length}</strong></div>
              <div className="summary-card"><div><Check size={17} />Valid rows</div><strong>{validRows.length}</strong></div>
              <div className="summary-card"><div><X size={17} />Invalid rows</div><strong>{invalidRows}</strong></div>
              <div className="summary-card summary-highlight"><div><ArrowUpRight size={17} />Total debit/credit</div><strong>{money(totalDebit)}</strong></div>
            </div>

            {unmatched.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <h3 style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>Unmatched names ({unmatched.length})</h3>
                {unmatchedUnresolved.length > 0 && (
                  <div className="error-banner" role="alert" style={{ marginBottom: 10 }}>
                    {unmatchedUnresolved.length} unmatched name(s) have no “Create automatically” selection. Check the box to create them, or fix the names in your file.
                  </div>
                )}
                <div className="table-scroll">
                  <table>
                    <thead><tr><th>Name</th><th>Type</th><th className="align-right">Appearances</th><th className="align-right">Create?</th></tr></thead>
                    <tbody>
                      {unmatched.map((u) => (
                        <tr key={`${u.type}-${u.name}`}>
                          <td><strong>{u.name}</strong></td>
                          <td><span className="type-label">{u.type}</span></td>
                          <td className="align-right">{u.count}</td>
                          <td className="align-right">
                            <label style={{ display: 'inline-flex', gap: 6, alignItems: 'center', fontWeight: 400 }}>
                              <input type="checkbox" checked={u.create} onChange={() => toggleCreate(u.name)} style={{ width: 'auto', minHeight: 'auto' }} />
                              Create
                            </label>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="dialog-actions">
              <button className="button button-quiet" onClick={() => { reset(); setOpen(false); }} disabled={busy}><X size={16} />Cancel</button>
              <button className="button button-primary" onClick={confirm} disabled={busy || unmatchedUnresolved.length > 0 || validRows.length === 0}>
                {busy ? 'Posting…' : `Post ${validRows.length} rows`}<ArrowUpRight size={17} />
              </button>
            </div>
          </>
        )}

        {step === 'results' && (
          <>
            <div className="summary-cards" style={{ marginBottom: 16 }}>
              <div className="summary-card summary-highlight"><div><Check size={17} />Vouchers posted</div><strong>{successCount}</strong></div>
              <div className="summary-card"><div><AlertCircle size={17} />Errors</div><strong>{errors.length}</strong></div>
            </div>
            {errors.length > 0 && (
              <>
                <div className="error-banner" role="alert">{errors.length} row(s) failed to post. Download the error report for details.</div>
                <button className="button button-quiet button-small" onClick={downloadErrors}><Download size={15} />Download error report</button>
              </>
            )}
            <div className="dialog-actions">
              <button className="button button-primary" onClick={() => { reset(); setOpen(false); }}><Check size={16} />Done</button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
