import { useCallback, useEffect, useState } from 'react';
import { useRevalidator } from 'react-router';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { Ledger, Voucher } from '@/lib/accounts';

export type AccountsData = {
  ledgers: Ledger[];
  vouchers: Voucher[];
  loading: boolean;
  error: string;
  reload: () => void;
};

/** Loads the owner's chart of accounts and all vouchers, kept fresh via realtime. */
export function useAccounts(): AccountsData {
  const revalidator = useRevalidator();
  const [ledgers, setLedgers] = useState<Ledger[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async (showLoading = true) => {
    // Realtime-triggered refreshes must NOT flip `loading` to true — doing so
    // unmounts the whole accounts UI (AccountsTabs shows the loading screen)
    // and discards any voucher the user has open mid-entry. Only the initial
    // load and explicit reloads show the loading state.
    if (showLoading) setLoading(true);
    setError('');
    try {
      const [l, v] = await Promise.all([
        pb.collection('ledgers').getFullList<Ledger>({ sort: 'name' }),
        pb.collection('vouchers').getFullList<Voucher>({ sort: '-date,-created' }),
      ]);
      setLedgers(l);
      setVouchers(v);
    } catch {
      setError('Your accounts couldn’t be loaded. Please refresh to try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(true);
  }, [load]);

  // Realtime: keep lists in sync without a full reload (no loading state, so
  // an open voucher editor is never unmounted by a background refresh).
  useEffect(() => {
    let cancelled = false;
    const apply = () => {
      if (cancelled) return;
      void load(false);
    };
    void pb.collection('ledgers').subscribe('*', apply).catch(() => {});
    void pb.collection('vouchers').subscribe('*', apply).catch(() => {});
    return () => {
      cancelled = true;
      void pb.collection('ledgers').unsubscribe('*').catch(() => {});
      void pb.collection('vouchers').unsubscribe('*').catch(() => {});
    };
  }, [load]);

  return {
    ledgers,
    vouchers,
    loading,
    error,
    reload: () => {
      void load();
      revalidator.revalidate();
    },
  };
}
