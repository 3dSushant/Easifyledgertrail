import { useState } from 'react';
import { Landmark, Scale, PiggyBank, ArrowRight, ChevronLeft, ArrowUpRight } from 'lucide-react';
import type { Ledger, Voucher } from '@/lib/accounts';
import {
  groupTotal, subgroupTotal, ledgerBalance, netWorth, money,
  vouchersForLedger, movementInVoucher, dateLabel,
} from '@/lib/accounts';
import { ASSET_SUBGROUPS, LIABILITY_SUBGROUPS } from '@/data/accounts';
import { VoucherDetail } from './voucher-detail';

export function BalanceSheet({
  ledgers, vouchers, today,
}: { ledgers: Ledger[]; vouchers: Voucher[]; today: string }) {
  const [view, setView] = useState<'summary' | 'ledger' | 'voucher'>('summary');
  const [activeLedger, setActiveLedger] = useState<Ledger | null>(null);
  const [activeVoucher, setActiveVoucher] = useState<Voucher | null>(null);

  const assets = groupTotal('Assets', ledgers, vouchers);
  const liabilities = groupTotal('Liabilities', ledgers, vouchers);
  const equity = groupTotal('Equity', ledgers, vouchers);
  const worth = netWorth(ledgers, vouchers);

  if (view === 'voucher' && activeVoucher) {
    return (
      <VoucherDetail
        voucher={activeVoucher}
        ledgers={ledgers}
        today={today}
        onBack={() => { setView('ledger'); setActiveVoucher(null); }}
      />
    );
  }

  if (view === 'ledger' && activeLedger) {
    const list = vouchersForLedger(activeLedger.id, vouchers);
    return (
      <>
        <div className="page-heading">
          <div>
            <button className="text-link" onClick={() => { setView('summary'); setActiveLedger(null); }}>
              <ChevronLeft size={15} />Back to balance sheet
            </button>
            <h1 style={{ marginTop: 12 }}>{activeLedger.name}<span>.</span></h1>
            <p>{activeLedger.group} · {activeLedger.subgroup} · Balance {money(ledgerBalance(activeLedger, vouchers))}</p>
          </div>
        </div>
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2>Vouchers in this ledger <span className="count-label">{list.length}</span></h2></div></div>
          {list.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Counterparty</th><th className="align-right">Movement</th><th className="align-right">Open</th></tr></thead>
                <tbody>
                  {list.map((v) => {
                    const move = movementInVoucher(activeLedger.id, v);
                    return (
                      <tr key={v.id}>
                        <td className="nowrap">{dateLabel(v.date)}</td>
                        <td><span className="type-label">{v.type}</span></td>
                        <td><strong>{v.reference || '—'}</strong></td>
                        <td>{v.counterparty || '—'}</td>
                        <td className={`align-right amount-cell ${move >= 0 ? 'income-amount' : ''}`}>{move >= 0 ? '+' : '−'}{money(Math.abs(move))}</td>
                        <td className="align-right"><button className="icon-button table-edit" onClick={() => setActiveVoucher(v)} aria-label="Open voucher"><ArrowUpRight size={16} /></button></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="large-empty"><h3>No vouchers yet.</h3><p>Record a transaction that uses this ledger to see entries here.</p></div>
          )}
        </section>
      </>
    );
  }

  function renderSubgroup(subgroup: string) {
    const list = ledgers
      .filter((l) => l.subgroup === subgroup)
      .map((l) => ({ ledger: l, balance: ledgerBalance(l, vouchers) }))
      .filter((x) => x.balance !== 0)
      .sort((a, b) => b.balance - a.balance);
    if (!list.length) return null;
    const total = subgroupTotal(subgroup, ledgers, vouchers);
    return (
      <div className="bs-group" key={subgroup}>
        <div className="bs-group-head">
          <span>{subgroup}</span>
          <strong>{money(total)}</strong>
        </div>
        <div className="bs-ledgers">
          {list.map(({ ledger, balance }) => (
            <button className="bs-ledger" key={ledger.id} onClick={() => { setActiveLedger(ledger); setView('ledger'); }}>
              <span>{ledger.name}</span>
              <span className="bs-ledger-amount">{money(balance)}</span>
              <ArrowRight size={14} />
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">BALANCE SHEET</span>
          <h1>Assets, liabilities & net worth<span>.</span></h1>
          <p>What your business owns, what it owes, and what it’s worth.</p>
        </div>
      </div>

      <div className="summary-cards">
        <div className="summary-card">
          <div><Landmark size={17} />Total assets</div>
          <strong>{money(assets)}</strong>
          <p>Everything the business owns</p>
        </div>
        <div className="summary-card">
          <div><Scale size={17} />Total liabilities</div>
          <strong>{money(liabilities)}</strong>
          <p>Everything the business owes</p>
        </div>
        <div className="summary-card summary-highlight">
          <div><PiggyBank size={17} />Business net worth</div>
          <strong>{money(worth)}</strong>
          <p>Assets minus liabilities</p>
        </div>
        <div className="summary-card">
          <div><PiggyBank size={17} />Capital & reserves</div>
          <strong>{money(equity)}</strong>
          <p>Owner’s equity in the business</p>
        </div>
      </div>

      <div className="overview-lower">
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2>Assets</h2><p>Click any ledger to see its vouchers.</p></div></div>
          <div className="bs-body">
            {ASSET_SUBGROUPS.map(renderSubgroup)}
            {!ASSET_SUBGROUPS.some((s) => ledgers.some((l) => l.subgroup === s && ledgerBalance(l, vouchers) !== 0)) && (
              <div className="compact-empty"><Landmark size={30} strokeWidth={1.4} /><strong>No assets recorded.</strong><p>Create asset ledgers and record transactions to build your balance sheet.</p></div>
            )}
          </div>
        </section>
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2>Liabilities</h2><p>Click any ledger to see its vouchers.</p></div></div>
          <div className="bs-body">
            {LIABILITY_SUBGROUPS.map(renderSubgroup)}
            {!LIABILITY_SUBGROUPS.some((s) => ledgers.some((l) => l.subgroup === s && ledgerBalance(l, vouchers) !== 0)) && (
              <div className="compact-empty"><Scale size={30} strokeWidth={1.4} /><strong>No liabilities recorded.</strong><p>Create liability ledgers to track loans and supplier dues.</p></div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
