import { ArrowUpRight } from 'lucide-react';
export function SummaryCards({ items }: { items: { label: string; value: string; detail: string; highlight?: boolean }[] }) {
  return <div className="summary-cards">{items.map(item => <article className={item.highlight ? 'summary-card summary-highlight' : 'summary-card'} key={item.label}><div><span>{item.label}</span><ArrowUpRight size={18} /></div><strong>{item.value}</strong><p>{item.detail}</p></article>)}</div>;
}
