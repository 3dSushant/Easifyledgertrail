export function StatusBadge({ status, overdue = false }: { status?: string; overdue?: boolean }) {
  const text = overdue ? 'Overdue' : status || 'Pending';
  return <span className={`status-badge ${['Paid', 'Filed', 'Active'].includes(text) ? 'status-complete' : text === 'Overdue' ? 'status-overdue' : text === 'Inactive' ? 'status-inactive' : 'status-pending'}`}><i />{text}</span>;
}
