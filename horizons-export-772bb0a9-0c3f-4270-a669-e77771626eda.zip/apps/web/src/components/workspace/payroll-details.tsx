import { useState } from 'react';
import { useOutletContext } from 'react-router';
import { Eye, Download, FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { money, exportCsv, type BusinessRecord, type CompanyProfile, type WorkspaceData } from '@/lib/business';
import { StatusBadge } from '@/components/workspace/status-badge';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { downloadSalarySlipPdf, downloadSalarySlipsBulk } from '@/lib/salary-slip-pdf';
import { downloadReportPdf } from '@/lib/report-pdf';

export function PayrollDetails({ run }: { run: BusinessRecord }) {
  const [open, setOpen] = useState(false);
  const [slipBusy, setSlipBusy] = useState(false);
  const { user } = useOutletContext<WorkspaceData>();

  const logoFilename = (user as { logo?: string }).logo;
  const profile: CompanyProfile = {
    business_name: user.business_name,
    business_address: user.business_address,
    gstin: user.gstin,
    pan: (user as { pan?: string }).pan,
    email: user.email,
    phone: (user as { phone?: string }).phone,
    logo: logoFilename ? pb.files.getUrl(user, logoFilename) : undefined,
  };

  async function downloadSlip(employee: { name: string; designation?: string; basic: number; allowances: number; deductions: number; net: number }) {
    setSlipBusy(true);
    try {
      await downloadSalarySlipPdf(employee, run.period || '', profile);
    } finally {
      setSlipBusy(false);
    }
  }

  async function downloadAllSlips() {
    setSlipBusy(true);
    try {
      await downloadSalarySlipsBulk(run.snapshot || [], run.period || '', profile);
    } finally {
      setSlipBusy(false);
    }
  }

  async function downloadRegisterPdf() {
    const rows = (run.snapshot || []).map((e) => [e.name, e.designation || '', e.basic, e.allowances, e.deductions, e.net]);
    await downloadReportPdf(`Payroll Register — ${run.period}`, ['Employee', 'Designation', 'Basic', 'Allowances', 'Deductions', 'Net pay'], rows, profile, `payroll-register-${run.period}.pdf`);
  }

  return <Dialog open={open} onOpenChange={setOpen}><button className="icon-button" onClick={() => setOpen(true)} aria-label={`View payroll for ${run.period}`}><Eye size={16} /></button><DialogContent className="record-dialog payroll-details-dialog"><DialogTitle>Payroll · {run.period}</DialogTitle><DialogDescription>This is the saved salary snapshot for this run. Changes to your employee directory do not change this record.</DialogDescription><div className="payroll-details-header"><StatusBadge status={run.status} /><div className="heading-actions"><button className="button button-quiet button-small" onClick={downloadRegisterPdf} disabled={!run.snapshot?.length}><FileText size={15} />Register PDF</button><button className="button button-quiet button-small" onClick={downloadAllSlips} disabled={slipBusy || !run.snapshot?.length}><FileText size={15} />{slipBusy ? 'Preparing…' : 'Download all slips'}</button><button className="button button-quiet button-small" onClick={() => exportCsv(`ledgerly-payroll-${run.period}.csv`, ['Employee', 'Designation', 'Basic (INR)', 'Allowances (INR)', 'Deductions (INR)', 'Net pay (INR)'], (run.snapshot || []).map(e => [e.name, e.designation, e.basic, e.allowances, e.deductions, e.net]))}><Download size={15} />Export salary register</button></div></div><div className="table-scroll"><table><thead><tr><th>Employee</th><th>Basic</th><th>Allowances</th><th>Deductions</th><th className="align-right">Net pay</th><th className="align-right">Slip</th></tr></thead><tbody>{(run.snapshot || []).map((employee, i) => <tr key={i}><td><strong>{employee.name}</strong><small>{employee.designation}</small></td><td>{money(employee.basic)}</td><td>{money(employee.allowances)}</td><td>{money(employee.deductions)}</td><td className="align-right amount-cell">{money(employee.net)}</td><td className="align-right"><button className="icon-button" onClick={() => downloadSlip(employee)} disabled={slipBusy} aria-label={`Download salary slip for ${employee.name}`}><FileText size={16} /></button></td></tr>)}</tbody></table></div><div className="payroll-run-summary"><span>Gross salary<strong>{money(run.gross || 0)}</strong></span><span>Total deductions<strong>{money(run.deductions || 0)}</strong></span><span>Net payable<strong>{money(run.net || 0)}</strong></span></div><p className="small-note">Payments are handled outside Ledgerly. “Paid” indicates a payment you have confirmed in your records. Salary slips include the company logo and bank details.</p></DialogContent></Dialog>;
}
