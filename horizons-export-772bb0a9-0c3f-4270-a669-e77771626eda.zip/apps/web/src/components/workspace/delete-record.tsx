import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
export function DeleteRecord({ collection, id, label }: { collection: string; id: string; label: string }) {
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const revalidator = useRevalidator();
  async function remove() { setBusy(true); setError(''); try { await pb.collection(collection).delete(id); setOpen(false); revalidator.revalidate(); } catch { setError('Couldn’t delete this record. Please try again.'); } finally { setBusy(false); } }
  return <Dialog open={open} onOpenChange={value => !busy && setOpen(value)}><button className="icon-button table-delete" aria-label={`Delete ${label}`} onClick={() => setOpen(true)}><Trash2 size={15} /></button><DialogContent className="record-dialog delete-dialog"><DialogTitle>Delete this record?</DialogTitle><DialogDescription>“{label}” will be permanently removed. This action cannot be undone.</DialogDescription>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" disabled={busy} onClick={() => setOpen(false)}>Keep record</button><button className="button button-primary" disabled={busy} onClick={remove}>{busy ? 'Deleting…' : 'Delete record'}</button></div></DialogContent></Dialog>;
}
