import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Plus, Pencil, ArrowUpRight, Paperclip } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { BusinessRecord } from '@/lib/business';
import type { FieldConfig } from '@/data/workspace';

export function RecordEditor({ collection, fields, title, record, defaults = {}, compact = false }: { collection: string; fields: FieldConfig[]; title: string; record?: BusinessRecord; defaults?: Record<string, string | number>; compact?: boolean }) {
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const revalidator = useRevalidator();
  const hasFile = fields.some(f => f.type === 'file');

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    const form = new FormData(event.currentTarget);

    if (collection === 'employees' && Number(form.get('deductions') || 0) > Number(form.get('basic') || 0) + Number(form.get('allowances') || 0)) {
      setError('Deductions cannot exceed basic salary and allowances.'); setBusy(false); return;
    }

    try {
      if (hasFile) {
        // Send multipart FormData so file fields upload correctly. Text/number
        // values are appended as strings (PocketBase coerces them). On edit, a
        // file field with no newly-selected file is omitted so the existing
        // file is preserved.
        const fd = new FormData();
        for (const field of fields) {
          if (field.type === 'file') {
            const files = form.getAll(field.name).filter(f => f instanceof File && (f as File).size > 0);
            for (const file of files) fd.append(field.name, file as File);
          } else if (field.type === 'number') {
            fd.append(field.name, String(form.get(field.name) || 0));
          } else {
            fd.append(field.name, String(form.get(field.name) || '').trim());
          }
        }
        if (record) await pb.collection(collection).update(record.id, fd);
        else { fd.append('owner', pb.authStore.record?.id || ''); await pb.collection(collection).create(fd); }
      } else {
        const values: Record<string, unknown> = {};
        fields.forEach(field => { values[field.name] = field.type === 'number' ? Number(form.get(field.name) || 0) : String(form.get(field.name) || '').trim(); });
        if (record) await pb.collection(collection).update(record.id, values);
        else await pb.collection(collection).create({ ...values, owner: pb.authStore.record?.id });
      }
      setOpen(false); revalidator.revalidate();
    } catch { setError('This record couldn’t be saved. Check the fields and try again.'); }
    finally { setBusy(false); }
  }

  return <Dialog open={open} onOpenChange={value => { if (!busy) { setOpen(value); setError(''); } }}><button onClick={() => setOpen(true)} className={record ? 'icon-button table-edit' : compact ? 'button button-small button-dark' : 'button button-primary'} aria-label={record ? `Edit ${record.description || record.title || record.name}` : title}>{record ? <Pencil size={15} /> : <><Plus size={17} />{title}</>}</button><DialogContent className="record-dialog"><DialogTitle>{record ? 'Edit' : 'New'} {title.replace(/^Add /, '').toLowerCase()}<span className="accent-dot">.</span></DialogTitle><DialogDescription>{collection === 'employees' ? 'Enter monthly salary components. Statutory deductions must be verified for your business.' : 'Keep your business information accurate and organised.'}</DialogDescription><form onSubmit={save}><div className="record-fields">{fields.map(field => {
    const value = record?.[field.name] ?? defaults[field.name] ?? (field.options ? field.options[0] : field.type === 'number' ? 0 : '');
    const existingFiles = field.type === 'file' && record ? (Array.isArray(record[field.name]) ? record[field.name] : record[field.name] ? [record[field.name]] : []) : [];
    return <label key={field.name} className={field.wide ? 'field-wide' : ''}>{field.label}{field.required && <span className="required"> *</span>}{field.options ? <select name={field.name} required={field.required} defaultValue={String(value)}>{field.options.map(option => <option key={option}>{option}</option>)}</select> : field.type === 'textarea' ? <textarea name={field.name} defaultValue={String(value)} maxLength={field.max} rows={3} /> : field.type === 'file' ? <><input name={field.name} type="file" multiple={field.multiple} accept={field.accept} />{existingFiles.length > 0 && <small className="small-note" style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 6 }}><Paperclip size={12} />{existingFiles.length} file(s) on record — leave empty to keep.</small>}</> : <input name={field.name} type={field.type || 'text'} defaultValue={String(value)} required={field.required} min={field.min} maxLength={field.type !== 'number' ? field.max : undefined} step={field.type === 'number' ? '0.01' : undefined} placeholder={field.placeholder} />}</label>;
  })}</div>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button className="button button-quiet" type="button" disabled={busy} onClick={() => setOpen(false)}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save record'}<ArrowUpRight size={17} /></button></div></form></DialogContent></Dialog>;
}
