import { useState } from 'react';
import { useOutletContext, useRevalidator } from 'react-router';
import { CalendarCheck, Upload, Download, FileSpreadsheet, Check, X, ArrowUpRight, Clock } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { money, exportCsv, type WorkspaceData, type BusinessRecord } from '@/lib/business';

type ParsedRow = { employeeName: string; date: string; inTime: string; outTime: string; status: string; remarks: string };
type CalculatedRow = ParsedRow & {
  employee?: BusinessRecord;
  matched: boolean;
  late: boolean;
  lateMinutes: number;
  earlyLeaving: boolean;
  workingHours: number;
  overtimeHours: number;
  computedStatus: string;
};

function parseTime(t: string): number {
  if (!t || !/^\d{2}:\d{2}$/.test(t)) return -1;
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

function parseCsv(text: string): string[][] {
  return text
    .split(/\r?\n/)
    .filter((line) => line.trim())
    .map((line) => line.split(',').map((cell) => cell.trim().replace(/^"|"$/g, '')));
}

export function Attendance() {
  const { employees, today } = useOutletContext<WorkspaceData>();
  const revalidator = useRevalidator();
  const [step, setStep] = useState<'upload' | 'review'>('upload');
  const [rows, setRows] = useState<CalculatedRow[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const active = employees.filter((e) => e.status === 'Active');

  function downloadTemplate() {
    exportCsv(
      'attendance-template.csv',
      ['Employee Name', 'Date', 'In Time', 'Out Time', 'Status', 'Remarks'],
      active.map((e) => [e.name || '', today, e.office_start_time || '10:00', e.office_end_time || '19:00', 'Present', '']),
    );
  }

  function handleUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setError('');
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result || '');
        const data = parseCsv(text);
        if (data.length < 2) { setError('The file has no data rows.'); return; }
        const header = data[0].map((h) => h.toLowerCase().trim());
        const nameIdx = header.findIndex((h) => h.includes('employee') || h.includes('name'));
        const dateIdx = header.findIndex((h) => h.includes('date'));
        const inIdx = header.findIndex((h) => h.includes('in'));
        const outIdx = header.findIndex((h) => h.includes('out'));
        const statusIdx = header.findIndex((h) => h.includes('status'));
        const remarksIdx = header.findIndex((h) => h.includes('remarks'));

        const parsed: ParsedRow[] = data.slice(1).map((r) => ({
          employeeName: nameIdx >= 0 ? r[nameIdx] : '',
          date: dateIdx >= 0 ? r[dateIdx] : today,
          inTime: inIdx >= 0 ? r[inIdx] : '',
          outTime: outIdx >= 0 ? r[outIdx] : '',
          status: statusIdx >= 0 ? r[statusIdx] : 'Present',
          remarks: remarksIdx >= 0 ? r[remarksIdx] : '',
        }));

        const calculated: CalculatedRow[] = parsed.map((row) => {
          const employee = active.find((e) => (e.name || '').toLowerCase() === row.employeeName.toLowerCase());
          let late = false;
          let lateMinutes = 0;
          let earlyLeaving = false;
          let workingHours = 0;
          let overtimeHours = 0;
          let computedStatus = row.status || 'Present';

          if (employee) {
            const startTime = parseTime(employee.office_start_time || '10:00');
            const endTime = parseTime(employee.office_end_time || '19:00');
            const grace = Number(employee.grace_period || 0);
            const inTime = parseTime(row.inTime);
            const outTime = parseTime(row.outTime);

            if (inTime >= 0 && startTime >= 0) {
              if (inTime > startTime + grace) {
                late = true;
                lateMinutes = inTime - startTime;
              }
            }
            if (outTime >= 0 && endTime >= 0) {
              if (outTime < endTime) earlyLeaving = true;
            }
            if (inTime >= 0 && outTime >= 0 && outTime > inTime) {
              workingHours = Math.round(((outTime - inTime) / 60) * 100) / 100;
              const standardHours = endTime >= 0 && startTime >= 0 ? (endTime - startTime) / 60 : 0;
              overtimeHours = Math.max(0, Math.round((workingHours - standardHours) * 100) / 100);
            }
            // Auto-detect weekly off
            const dayName = new Date(`${row.date}T00:00:00Z`).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
            if (employee.weekly_off === dayName && row.status === 'Present') {
              computedStatus = 'Weekly Off';
            }
          }

          return { ...row, employee, matched: !!employee, late, lateMinutes, earlyLeaving, workingHours, overtimeHours, computedStatus };
        });

        setRows(calculated);
        setStep('review');
      } catch {
        setError('Could not read the file. Please use the template CSV format.');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  }

  async function save() {
    setBusy(true); setError('');
    try {
      const valid = rows.filter((r) => r.employee);
      for (const r of valid) {
        await pb.collection('attendance_records').create({
          owner: pb.authStore.record?.id,
          employee: r.employee!.id,
          date: r.date,
          in_time: r.inTime,
          out_time: r.outTime,
          status: r.computedStatus,
          late: r.late,
          late_minutes: r.lateMinutes,
          early_leaving: r.earlyLeaving,
          working_hours: r.workingHours,
          overtime_hours: r.overtimeHours,
          remarks: r.remarks,
        }, { requestKey: `att-${r.employee!.id}-${r.date}` });
      }
      setStep('upload');
      setRows([]);
      revalidator.revalidate();
    } catch {
      setError('Some attendance records couldn’t be saved. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function exportProcessed() {
    exportCsv(
      'attendance-processed.csv',
      ['Employee', 'Date', 'In Time', 'Out Time', 'Status', 'Late', 'Late (min)', 'Early Leaving', 'Working Hours', 'Overtime Hours', 'Remarks'],
      rows.map((r) => [r.employeeName, r.date, r.inTime, r.outTime, r.computedStatus, r.late ? 'Yes' : 'No', r.lateMinutes, r.earlyLeaving ? 'Yes' : 'No', r.workingHours, r.overtimeHours, r.remarks]),
    );
  }

  const unmatched = rows.filter((r) => !r.matched);
  const matched = rows.filter((r) => r.matched);
  const presentCount = matched.filter((r) => r.computedStatus === 'Present').length;
  const absentCount = matched.filter((r) => r.computedStatus === 'Absent').length;
  const lateCount = matched.filter((r) => r.late).length;

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">ATTENDANCE PROCESSING</span>
          <h1>Employee attendance<span>.</span></h1>
          <p>Upload attendance, apply office-time rules, review and save processed records.</p>
        </div>
        <div className="heading-actions">
          <button className="button button-quiet button-small" onClick={downloadTemplate} disabled={!active.length}><FileSpreadsheet size={15} />Download template</button>
        </div>
      </div>

      {step === 'upload' && (
        <section className="dashboard-panel">
          <div className="panel-heading"><div><h2><CalendarCheck size={16} /> Upload attendance</h2><p>Download the template, fill in attendance data, then upload the CSV file.</p></div></div>
          <div className="large-empty">
            <Upload size={42} strokeWidth={1.3} />
            <h3>Upload your attendance CSV</h3>
            <p>The template includes all active employees with their configured office times. Fill in dates, in/out times and status, then upload.</p>
            <label className="button button-primary">
              <Upload size={16} />Choose CSV file
              <input type="file" accept=".csv,text/csv" onChange={handleUpload} hidden />
            </label>
            {error && <p className="form-error" role="alert" style={{ marginTop: 16 }}>{error}</p>}
          </div>
        </section>
      )}

      {step === 'review' && (
        <>
          <div className="summary-cards">
            <div className="summary-card"><div><Check size={17} />Matched rows</div><strong>{matched.length}</strong><p>Employees found in directory</p></div>
            <div className="summary-card"><div><X size={17} />Unmatched rows</div><strong>{unmatched.length}</strong><p>Employee names not found</p></div>
            <div className="summary-card"><div><CalendarCheck size={17} />Present</div><strong>{presentCount}</strong><p>Marked present</p></div>
            <div className="summary-card summary-highlight"><div><Clock size={17} />Late marks</div><strong>{lateCount}</strong><p>Arrived after grace period</p></div>
          </div>

          {unmatched.length > 0 && (
            <div className="error-banner" role="alert">
              {unmatched.length} row(s) have unmatched employee names: {Array.from(new Set(unmatched.map((r) => r.employeeName))).join(', ')}. Fix the names to match your employee directory, or remove those rows.
            </div>
          )}

          <section className="dashboard-panel">
            <div className="panel-heading">
              <div><h2>Review attendance <span className="count-label">{rows.length}</span></h2><p>Verify computed late marks, early leaving, working hours and overtime before saving.</p></div>
              <div className="heading-actions">
                <button className="button button-quiet button-small" onClick={exportProcessed}><Download size={15} />Export CSV</button>
                <button className="button button-quiet button-small" onClick={() => { setStep('upload'); setRows([]); }} disabled={busy}><X size={15} />Cancel</button>
                <button className="button button-primary button-small" onClick={save} disabled={busy || unmatched.length > 0}><Check size={15} />{busy ? 'Saving…' : 'Confirm & save'}<ArrowUpRight size={15} /></button>
              </div>
            </div>
            <div className="table-scroll">
              <table>
                <thead><tr><th>Employee</th><th>Date</th><th>In</th><th>Out</th><th>Status</th><th>Late</th><th>Early</th><th className="align-right">Hrs</th><th className="align-right">OT</th><th>Remarks</th></tr></thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i} style={!r.matched ? { opacity: 0.5 } : undefined}>
                      <td><strong>{r.employeeName}</strong>{!r.matched && <small style={{ color: 'var(--signal)' }}>Unmatched</small>}</td>
                      <td className="nowrap">{r.date}</td>
                      <td>{r.inTime || '—'}</td>
                      <td>{r.outTime || '—'}</td>
                      <td><span className="type-label">{r.computedStatus}</span></td>
                      <td>{r.late ? <span className="status-badge status-overdue"><i />Yes</span> : '—'}</td>
                      <td>{r.earlyLeaving ? <span className="status-badge status-pending"><i />Yes</span> : '—'}</td>
                      <td className="align-right">{r.workingHours || '—'}</td>
                      <td className="align-right">{r.overtimeHours || '—'}</td>
                      <td>{r.remarks || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      <div className="workspace-help">
        <CalendarCheck size={17} />
        <span>Attendance is calculated using each employee’s configured office start/end time, grace period and weekly off. Late marks and half-day rules apply automatically. Verify PF, PT and ESIC deductions with your advisor.</span>
      </div>
    </>
  );
}
