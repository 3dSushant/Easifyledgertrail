import { useCallback, useEffect, useState } from 'react';
import { useOutletContext, useRevalidator } from 'react-router';
import { Plus, Briefcase, Users, Eye, Download, Pencil, Trash2, X, ArrowUpRight, FileText, Phone, Mail } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { SummaryCards } from '@/components/workspace/summary-cards';
import { dateLabel } from '@/lib/business';
import type { WorkspaceData } from '@/lib/business';

type JD = {
  id: string; created: string; updated: string;
  job_title: string; department?: string; positions?: number; skills?: string;
  experience?: string; qualification?: string; salary?: string; location?: string;
  employment_type?: string; description?: string; requirements?: string; status: string;
};

type Candidate = {
  id: string; created: string; jd: string; name: string; email?: string; phone?: string;
  resume?: string; experience?: string; skills?: string; status: string; interview_notes?: string;
};

const STATUSES = ['Shortlisted', 'Rejected', 'Pending Interview', 'Selected', 'Hired'] as const;

const emptyJD: Partial<JD> = { status: 'Open', positions: 1, employment_type: 'Full-time' };

export function HireTalent() {
  const { user } = useOutletContext<WorkspaceData>();
  const revalidator = useRevalidator();
  const [jds, setJds] = useState<JD[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [jdDialog, setJdDialog] = useState(false);
  const [editingJD, setEditingJD] = useState<JD | null>(null);
  const [viewingJD, setViewingJD] = useState<JD | null>(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [jdList, candList] = await Promise.all([
        pb.collection('hire_jds').getFullList<JD>({ sort: '-created' }),
        pb.collection('hire_candidates').getFullList<Candidate>({ sort: '-created' }),
      ]);
      setJds(jdList);
      setCandidates(candList);
    } catch {
      setError('Your hiring records couldn’t be loaded. Please refresh to try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function saveJD(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setFormError('');
    const form = new FormData(event.currentTarget);
    const values = {
      job_title: String(form.get('job_title') || '').trim(),
      department: String(form.get('department') || '').trim(),
      positions: Number(form.get('positions') || 1),
      skills: String(form.get('skills') || '').trim(),
      experience: String(form.get('experience') || '').trim(),
      qualification: String(form.get('qualification') || '').trim(),
      salary: String(form.get('salary') || '').trim(),
      location: String(form.get('location') || '').trim(),
      employment_type: String(form.get('employment_type') || 'Full-time'),
      description: String(form.get('description') || '').trim(),
      requirements: String(form.get('requirements') || '').trim(),
      status: String(form.get('status') || 'Open'),
    };
    if (!values.job_title) { setFormError('Enter a job title.'); setBusy(false); return; }
    try {
      if (editingJD) {
        await pb.collection('hire_jds').update(editingJD.id, values);
      } else {
        await pb.collection('hire_jds').create({ ...values, owner: pb.authStore.record?.id });
      }
      setJdDialog(false); setEditingJD(null);
      void load();
    } catch { setFormError('Couldn’t save the job description. Try again.'); }
    finally { setBusy(false); }
  }

  async function removeJD(id: string) {
    if (!confirm('Delete this job description and its candidates? This cannot be undone.')) return;
    try { await pb.collection('hire_jds').delete(id); void load(); } catch { alert('Could not delete.'); }
  }

  async function changeStatus(c: Candidate, status: string) {
    try { await pb.collection('hire_candidates').update(c.id, { status }); revalidator.revalidate(); void load(); } catch { alert('Could not update status.'); }
  }

  async function saveNotes(c: Candidate, notes: string) {
    try { await pb.collection('hire_candidates').update(c.id, { interview_notes: notes }); void load(); } catch { alert('Could not save notes.'); }
  }

  async function openResume(c: Candidate) {
    if (!c.resume) return;
    try {
      const url = pb.files.getURL(c as never, c.resume);
      const res = await fetch(url, { headers: { Authorization: pb.authStore.token ? `Bearer ${pb.authStore.token}` : '' } });
      if (!res.ok) throw new Error('fetch failed');
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, '_blank');
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } catch { alert('Could not load the resume. Please try again.'); }
  }

  if (loading) {
    return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading your hiring pipeline…</p></div>;
  }

  const openJDs = jds.filter((j) => j.status === 'Open');
  const shortlisted = candidates.filter((c) => c.status === 'Shortlisted').length;
  const rejected = candidates.filter((c) => c.status === 'Rejected').length;
  const pending = candidates.filter((c) => c.status === 'Pending Interview').length;
  const selected = candidates.filter((c) => c.status === 'Selected' || c.status === 'Hired').length;

  const jdCandidates = viewingJD ? candidates.filter((c) => c.jd === viewingJD.id) : [];

  return (
    <>
      {error && <div className="error-banner" role="alert">{error} <button onClick={() => load()}>Try again</button></div>}

      <div className="page-heading">
        <div>
          <span className="eyebrow">PEOPLE FIRST. HIRING SORTED.</span>
          <h1>Hire Talent<span>.</span></h1>
          <p>Post job descriptions, review candidates assigned by your account manager, and track every interview.</p>
        </div>
        <button className="button button-primary" onClick={() => { setEditingJD(null); setJdDialog(true); }}><Plus size={16} />Post job description</button>
      </div>

      <SummaryCards items={[
        { label: 'Open positions', value: String(openJDs.length), detail: `${jds.length} job descriptions posted` },
        { label: 'Candidates received', value: String(candidates.length), detail: 'Profiles assigned across all JDs' },
        { label: 'Shortlisted', value: String(shortlisted), detail: 'Candidates you shortlisted' },
        { label: 'Pending interview', value: String(pending), detail: 'Awaiting interview' },
        { label: 'Selected / Hired', value: String(selected), detail: 'Selected or hired', highlight: true },
      ]} />

      <section className="dashboard-panel">
        <div className="panel-heading">
          <div><h2>Job descriptions <span className="count-label">{jds.length}</span></h2><p>Your account manager assigns candidate profiles and resumes to each open role.</p></div>
        </div>
        {jds.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Role</th><th>Department</th><th>Positions</th><th>Type</th><th>Candidates</th><th>Status</th><th className="align-right">Actions</th></tr></thead>
              <tbody>
                {jds.map((j) => {
                  const count = candidates.filter((c) => c.jd === j.id).length;
                  return (
                    <tr key={j.id}>
                      <td><strong>{j.job_title}</strong><small>{j.location || '—'}</small></td>
                      <td>{j.department || '—'}</td>
                      <td>{j.positions || 1}</td>
                      <td><span className="type-label">{j.employment_type || '—'}</span></td>
                      <td>{count}</td>
                      <td><span className={`status-badge ${j.status === 'Open' ? 'status-complete' : 'status-inactive'}`}><i />{j.status}</span></td>
                      <td>
                        <div className="table-actions">
                          <button className="icon-button table-edit" aria-label="View candidates" onClick={() => setViewingJD(j)}><Eye size={15} /></button>
                          <button className="icon-button table-edit" aria-label="Edit" onClick={() => { setEditingJD(j); setJdDialog(true); }}><Pencil size={15} /></button>
                          <button className="icon-button table-delete" aria-label="Delete" onClick={() => removeJD(j.id)}><Trash2 size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="large-empty"><Briefcase size={42} strokeWidth={1.3} /><h3>Post your first job description.</h3><p>Share the role, skills and budget. Your account manager will assign matching candidates.</p><button className="button button-primary button-small" onClick={() => { setEditingJD(null); setJdDialog(true); }}><Plus size={15} />Post job description</button></div>
        )}
      </section>

      {/* JD create/edit dialog */}
      <Dialog open={jdDialog} onOpenChange={(v) => { if (!busy) { setJdDialog(v); if (!v) setEditingJD(null); setFormError(''); } }}>
        <DialogContent className="record-dialog payroll-details-dialog">
          <DialogTitle>{editingJD ? 'Edit' : 'New'} job description<span className="accent-dot">.</span></DialogTitle>
          <DialogDescription>Describe the role so your account manager can source the right candidates.</DialogDescription>
          <form onSubmit={saveJD}>
            <div className="record-fields">
              <label className="field-wide">Job title<span className="required"> *</span><input name="job_title" defaultValue={editingJD?.job_title || ''} maxLength={200} required /></label>
              <label>Department<input name="department" defaultValue={editingJD?.department || ''} maxLength={200} /></label>
              <label>Number of positions<input name="positions" type="number" min={1} defaultValue={String(editingJD?.positions ?? 1)} /></label>
              <label>Required skills<input name="skills" defaultValue={editingJD?.skills || ''} maxLength={2000} placeholder="e.g. Tally, GST filing, Excel" /></label>
              <label>Experience<input name="experience" defaultValue={editingJD?.experience || ''} maxLength={200} placeholder="e.g. 2–4 years" /></label>
              <label>Qualification<input name="qualification" defaultValue={editingJD?.qualification || ''} maxLength={500} /></label>
              <label>Salary / budget<input name="salary" defaultValue={editingJD?.salary || ''} maxLength={200} /></label>
              <label>Location<input name="location" defaultValue={editingJD?.location || ''} maxLength={200} /></label>
              <label>Employment type<select name="employment_type" defaultValue={editingJD?.employment_type || 'Full-time'}><option>Full-time</option><option>Part-time</option><option>Contract</option><option>Internship</option></select></label>
              <label>Status<select name="status" defaultValue={editingJD?.status || 'Open'}><option>Open</option><option>Closed</option></select></label>
              <label className="field-wide">Job description<textarea name="description" defaultValue={editingJD?.description || ''} rows={3} maxLength={5000} /></label>
              <label className="field-wide">Additional requirements<textarea name="requirements" defaultValue={editingJD?.requirements || ''} rows={2} maxLength={5000} /></label>
            </div>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <div className="dialog-actions">
              <button className="button button-quiet" type="button" disabled={busy} onClick={() => { setJdDialog(false); setEditingJD(null); }}><X size={16} />Cancel</button>
              <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save job description'}<ArrowUpRight size={17} /></button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Candidates for a JD */}
      <Dialog open={!!viewingJD} onOpenChange={(v) => { if (!v) setViewingJD(null); }}>
        <DialogContent className="record-dialog payroll-details-dialog">
          {viewingJD && (
            <>
              <DialogTitle>{viewingJD.job_title}<span className="accent-dot">.</span></DialogTitle>
              <DialogDescription>{viewingJD.department || '—'} · {viewingJD.experience || 'Any experience'} · {viewingJD.location || 'Any location'}</DialogDescription>
              <CandidateList candidates={jdCandidates} onChangeStatus={changeStatus} onSaveNotes={saveNotes} onOpenResume={openResume} />
              <div className="dialog-actions"><button className="button button-quiet" onClick={() => setViewingJD(null)}>Close</button></div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function CandidateList({ candidates, onChangeStatus, onSaveNotes, onOpenResume }: {
  candidates: Candidate[];
  onChangeStatus: (c: Candidate, status: string) => void;
  onSaveNotes: (c: Candidate, notes: string) => void;
  onOpenResume: (c: Candidate) => void;
}) {
  if (!candidates.length) return <div className="compact-empty" style={{ minHeight: 160 }}><Users size={30} strokeWidth={1.4} /><strong>No candidates assigned yet.</strong><p>Your account manager will assign candidate profiles and resumes here.</p></div>;
  return (
    <div className="table-scroll" style={{ marginTop: 16 }}>
      <table>
        <thead><tr><th>Candidate</th><th>Experience</th><th>Status</th><th>Resume</th><th>Notes</th></tr></thead>
        <tbody>
          {candidates.map((c) => (
            <tr key={c.id}>
              <td>
                <strong>{c.name}</strong>
                <small>{c.email && <><Mail size={11} /> {c.email}</>} {c.phone && <><Phone size={11} /> {c.phone}</>}</small>
              </td>
              <td>{c.experience || '—'}<small>{c.skills}</small></td>
              <td>
                <select className="status-select" value={c.status} onChange={(e) => onChangeStatus(c, e.target.value)}>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </td>
              <td>{c.resume ? <button className="icon-button table-edit" aria-label="View resume" onClick={() => onOpenResume(c)}><Download size={15} /></button> : '—'}</td>
              <td><NotesEditor notes={c.interview_notes || ''} onSave={(n) => onSaveNotes(c, n)} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function NotesEditor({ notes, onSave }: { notes: string; onSave: (notes: string) => void }) {
  const [value, setValue] = useState(notes);
  const [editing, setEditing] = useState(false);
  useEffect(() => setValue(notes), [notes]);
  if (!editing) {
    return <button className="icon-button table-edit" aria-label="Edit notes" onClick={() => setEditing(true)}><FileText size={15} /></button>;
  }
  return (
    <div style={{ display: 'flex', gap: 6 }}>
      <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Interview notes…" style={{ minHeight: 34 }} />
      <button className="button button-dark button-small" onClick={() => { onSave(value); setEditing(false); }}>Save</button>
    </div>
  );
}
