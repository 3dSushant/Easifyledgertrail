import { useState } from 'react';
import { Link, useOutletContext } from 'react-router';
import { Receipt, Search, Download, MessageCircle, Mail, ArrowUpRight, Plus, TrendingUp } from 'lucide-react';
import type { WorkspaceData } from '@/lib/business';
import { money, dateLabel, exportCsv } from '@/lib/business';
import { receivablesAnalysis, type InvoiceReceivable } from '@/lib/receivables';
import { useAccounts } from '@/components/workspace/accounts/use-accounts';
import { SummaryCards } from '@/components/workspace/summary-cards';
import { VoucherMenu } from '@/components/workspace/accounts/voucher-menu';

const STATUS_LABEL: Record<InvoiceReceivable['status'], string> = {
  paid: 'Paid',
  partial: 'Partial',
  unpaid: 'Unpaid',
  overdue: 'Overdue',
  'due-soon': 'Due soon',
};

const STATUS_CLASS: Record<InvoiceReceivable['status'], string> = {
  paid: 'status-complete',
  partial: 'status-pending',
  unpaid: 'status-pending',
  overdue: 'status-overdue',
  'due-soon': 'status-pending',
};

export function Sales() {
  const { today } = useOutletContext<WorkspaceData>();
  const { ledgers, vouchers, loading, error, reload } = useAccounts();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');

  const analysis = receivablesAnalysis(ledgers, vouchers, today);

  const invoices = analysis.invoices.filter((inv) => {
    if (query) {
      const q = query.toLowerCase();
      if (!`${inv.voucher.reference || ''} ${inv.counterparty?.name || ''} ${inv.voucher.counterparty || ''}`.toLowerCase().includes(q)) return false;
    }
    if (status !== 'all' && inv.status !== status) return false;
    return true;
  });

  function downloadInvoices() {
    exportCsv(
      'ledgerly-sales-receivables.csv',
      ['Invoice date', 'Due date', 'Reference', 'Client', 'Invoiced (INR)', 'Received (INR)', 'Outstanding (INR)', 'Remaining days', 'Status'],
      invoices.map((inv) => [inv.invoiceDate, inv.dueDate, inv.voucher.reference || '', inv.counterparty?.name || '', inv.invoiced, inv.received, inv.outstanding, inv.remainingDays, STATUS_LABEL[inv.status]]),
    );
  }

  function downloadDebtors() {
    exportCsv(
      'ledgerly-debtor-ledger.csv',
      ['Client', 'Invoiced (INR)', 'Received (INR)', 'Outstanding (INR)', 'Overdue (INR)', 'Due soon (INR)', 'Invoices'],
      analysis.debtors.map((d) => [d.ledger.name, d.invoiced, d.received, d.outstanding, d.overdue, d.dueSoon, d.invoiceCount]),
    );
  }

  function waLink(phone: string, inv: InvoiceReceivable) {
    const clean = (phone || '').replace(/[^0-9]/g, '');
    if (!clean) return null;
    const text = `Hello ${inv.counterparty?.name || ''}, invoice ${inv.voucher.reference || ''} dated ${dateLabel(inv.invoiceDate)} for ${money(inv.invoiced)} is ${inv.outstanding > 0 ? `outstanding ${money(inv.outstanding)}` : 'paid'}. Due ${dateLabel(inv.dueDate)}. — Easify Ledger`;
    return `https://wa.me/${clean}?text=${encodeURIComponent(text)}`;
  }

  function mailLink(inv: InvoiceReceivable) {
    const email = inv.counterparty?.email || '';
    if (!email) return null;
    const subject = `Invoice ${inv.voucher.reference || ''} — ${money(inv.invoiced)}`;
    const body = `Hello ${inv.counterparty?.name || ''},\n\nInvoice ${inv.voucher.reference || ''} dated ${dateLabel(inv.invoiceDate)} for ${money(inv.invoiced)}.\n${inv.outstanding > 0 ? `Outstanding: ${money(inv.outstanding)}, due ${dateLabel(inv.dueDate)}.` : 'Payment received. Thank you.'}\n\nRegards,\nEasify Ledger`;
    return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  if (loading) {
    return <div className="workspace-loading"><span className="loading-mark">l.</span><p>Loading your sales…</p></div>;
  }

  const maxMonth = Math.max(1, ...analysis.monthly.map((m) => m.total));

  return (
    <>
      {error && <div className="error-banner" role="alert">{error} <button onClick={reload}>Try again</button></div>}

      <div className="page-heading">
        <div>
          <span className="eyebrow">SALES & RECEIVABLES</span>
          <h1>Sales<span>.</span></h1>
          <p>Every sales invoice, its payment status, due date and outstanding receivable — by client and period.</p>
        </div>
        <div className="heading-actions">
          <VoucherMenu section="Sales" ledgers={ledgers} vouchers={vouchers} today={today} onSaved={() => {}} />
        </div>
      </div>

      <SummaryCards items={[
        { label: 'Total sales', value: money(analysis.totalSales), detail: 'All sales invoices recorded' },
        { label: 'Amount received', value: money(analysis.amountReceived), detail: 'Payments allocated to invoices (FIFO)' },
        { label: 'Outstanding receivables', value: money(analysis.outstanding), detail: 'Unpaid invoice balances', highlight: true },
        { label: 'Overdue receivables', value: money(analysis.overdue), detail: 'Past their due date' },
        { label: 'Amount due soon', value: money(analysis.dueSoon), detail: 'Due within 7 days' },
      ]} />

      <div className="overview-panels">
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div><h2>Monthly sales</h2><p>Total invoiced sales by month</p></div>
          </div>
          {analysis.monthly.length ? (
            <div className="cashflow-chart">
              {analysis.monthly.map((m) => (
                <div className="cashflow-column" key={m.month}>
                  <div className="cashflow-values">
                    <span style={{ height: `${(m.total / maxMonth) * 100}%` }} title={`${m.label}: ${money(m.total)}`} />
                  </div>
                  <small>{m.label}</small>
                </div>
              ))}
            </div>
          ) : (
            <div className="chart-empty"><TrendingUp size={30} strokeWidth={1.4} /><strong>No sales recorded yet.</strong><p>Record a sales invoice to see your monthly trend.</p></div>
          )}
        </section>
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div><h2>Client-wise receivables</h2><p>Debtor ledger with outstanding and overdue</p></div>
            <button className="button button-quiet button-small" onClick={downloadDebtors} disabled={!analysis.debtors.length}><Download size={15} />Export CSV</button>
          </div>
          {analysis.debtors.length ? (
            <div className="table-scroll">
              <table>
                <thead><tr><th>Client</th><th className="align-right">Invoiced</th><th className="align-right">Received</th><th className="align-right">Outstanding</th><th className="align-right">Overdue</th></tr></thead>
                <tbody>
                  {analysis.debtors.map((d) => (
                    <tr key={d.ledger.id}>
                      <td><strong>{d.ledger.name}</strong><small>{d.invoiceCount} invoice{d.invoiceCount === 1 ? '' : 's'}</small></td>
                      <td className="align-right">{money(d.invoiced)}</td>
                      <td className="align-right income-amount">{money(d.received)}</td>
                      <td className="align-right amount-cell">{money(d.outstanding)}</td>
                      <td className="align-right">{d.overdue > 0 ? money(d.overdue) : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="compact-empty"><Receipt size={30} strokeWidth={1.4} /><strong>No client receivables.</strong><p>Create client ledgers and sales invoices to track receivables.</p></div>
          )}
        </section>
      </div>

      <section className="dashboard-panel" style={{ marginTop: 21 }}>
        <div className="panel-heading">
          <div><h2>Invoices <span className="count-label">{invoices.length}</span></h2><p>Due dates and payment status calculated from invoice date and credit period.</p></div>
          <button className="button button-quiet button-small" onClick={downloadInvoices} disabled={!invoices.length}><Download size={15} />Export CSV</button>
        </div>
        <div className="table-filters">
          <label className="search-control">
            <Search size={16} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search invoice no or client…" aria-label="Search invoices" />
          </label>
          <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Payment status">
            <option value="all">All statuses</option>
            <option value="paid">Paid</option>
            <option value="partial">Partial</option>
            <option value="unpaid">Unpaid</option>
            <option value="due-soon">Due soon</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>
        {invoices.length ? (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Date</th><th>Reference</th><th>Client</th><th>Due date</th><th>Remaining</th><th>Status</th><th className="align-right">Invoiced</th><th className="align-right">Outstanding</th><th className="align-right">Share</th></tr></thead>
              <tbody>
                {invoices.map((inv) => {
                  const wa = waLink(inv.counterparty?.phone || '', inv);
                  const mail = mailLink(inv);
                  return (
                    <tr key={inv.voucher.id}>
                      <td className="nowrap">{dateLabel(inv.invoiceDate)}</td>
                      <td><strong>{inv.voucher.reference || '—'}</strong></td>
                      <td>{inv.counterparty?.name || inv.voucher.counterparty || '—'}</td>
                      <td className="nowrap">{dateLabel(inv.dueDate)}</td>
                      <td className="nowrap">{inv.remainingDays < 0 ? `${Math.abs(inv.remainingDays)}d overdue` : `${inv.remainingDays}d`}</td>
                      <td><span className={`status-badge ${STATUS_CLASS[inv.status]}`}><i />{STATUS_LABEL[inv.status]}</span></td>
                      <td className="align-right amount-cell">{money(inv.invoiced)}</td>
                      <td className="align-right amount-cell">{inv.outstanding > 0 ? money(inv.outstanding) : '—'}</td>
                      <td>
                        <div className="table-actions">
                          {wa && <a className="icon-button table-edit" href={wa} target="_blank" rel="noreferrer" aria-label="WhatsApp invoice"><MessageCircle size={15} /></a>}
                          {mail && <a className="icon-button table-edit" href={mail} aria-label="Email invoice"><Mail size={15} /></a>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="large-empty">
            <Receipt size={42} strokeWidth={1.3} />
            <h3>{analysis.invoices.length ? 'No matching invoices.' : 'Your sales ledger starts here.'}</h3>
            <p>{analysis.invoices.length ? 'Try another search or status.' : 'Record a sales invoice with a client and credit period to track receivables, due dates and payment status.'}</p>
            <Link to="/app/accounts" className="button button-primary button-small"><Plus size={15} />Record sales invoice</Link>
          </div>
        )}
      </section>

      <div className="workspace-help">
        <ArrowUpRight size={17} />
        <span>Payment status uses FIFO allocation of received payments against each client’s invoices. Open an invoice from Record Transaction to view, edit or export its PDF.</span>
      </div>
    </>
  );
}
