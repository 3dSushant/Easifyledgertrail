import { useState } from 'react';
import { useOutletContext, useRevalidator } from 'react-router';
import { Download, TrendingUp, TrendingDown, Wallet, ShieldCheck, ArrowUpRight, X, FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { Ledger, Voucher } from '@/lib/accounts';
import { money, dateLabel, exportCsv } from '@/lib/accounts';
import { gstDashboard, taxDashboards, tdsLedgerBalance, type GstDashboard, type TaxDashboard } from '@/lib/tax-dashboard';
import type { CompanyProfile, WorkspaceData } from '@/lib/business';
import { downloadReportPdf } from '@/lib/report-pdf';

export function TaxDashboards({ ledgers, vouchers }: { ledgers: Ledger[]; vouchers: Voucher[] }) {
  const { compliance, today, user } = useOutletContext<WorkspaceData>();
  const revalidator = useRevalidator();
  const [payTarget, setPayTarget] = useState<{ type: string; amount: number; itemId?: string; ledgerId?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const logoFilename = (user as { logo?: string }).logo;
  const profile: CompanyProfile = {
    business_name: user.business_name,
    business_address: user.business_address,
    gstin: user.gstin,
    email: user.email,
    logo: logoFilename ? pb.files.getUrl(user, logoFilename) : undefined,
  };

  const gst = gstDashboard(ledgers, vouchers);
  const dashboards = taxDashboards(compliance);
  const tdsFromVouchers = tdsLedgerBalance(ledgers, vouchers);

  const bankCashLedgers = ledgers.filter((l) => l.subgroup === 'Bank & Cash');

  function downloadTaxReport() {
    const rows: (string | number)[][] = [];
    rows.push(['GST Output GST', gst.outputGst]);
    rows.push(['GST Input GST (ITC)', gst.inputGst]);
    rows.push(['GST Net Payable', gst.netPayable]);
    rows.push(['GST Credit Balance', gst.creditBalance]);
    rows.push(['', '']);
    for (const d of dashboards) {
      rows.push([`${d.type} Payable`, d.payable]);
      rows.push([`${d.type} Paid`, d.paid]);
      rows.push([`${d.type} Outstanding`, d.outstanding]);
    }
    exportCsv('tax-dashboards.csv', ['Particulars', 'Amount (INR)'], rows);
  }

  async function downloadTaxPdf() {
    const rows: (string | number)[][] = [
      ['GST Output GST', gst.outputGst],
      ['GST Input GST (ITC)', gst.inputGst],
      ['GST Net Payable', gst.netPayable],
      ['GST Credit Balance', gst.creditBalance],
      ['', ''],
    ];
    for (const d of dashboards) {
      rows.push([`${d.type} Payable`, d.payable]);
      rows.push([`${d.type} Paid`, d.paid]);
      rows.push([`${d.type} Outstanding`, d.outstanding]);
    }
    await downloadReportPdf('Tax Dashboards', ['Particulars', 'Amount (INR)'], rows, profile, 'tax-dashboards.pdf');
  }

  async function recordPayment(form: FormData) {
    if (!payTarget) return;
    setBusy(true); setError('');
    try {
      const bankLedgerId = String(form.get('bank_ledger') || '');
      const date = String(form.get('date') || today);
      const reference = String(form.get('reference') || '');
      const notes = String(form.get('notes') || '');
      if (!bankLedgerId) { setError('Select a bank or cash ledger.'); setBusy(false); return; }

      const bankLedger = ledgers.find((l) => l.id === bankLedgerId);
      const amount = payTarget.amount;
      const entries = [
        { ledger: payTarget.ledgerId || '', ledgerName: payTarget.type, ledgerGroup: 'Liabilities' as const, debit: amount, credit: 0 },
        { ledger: bankLedgerId, ledgerName: bankLedger?.name || '', ledgerGroup: 'Assets' as const, debit: 0, credit: amount },
      ].filter((e) => e.ledger);

      const voucherValues: Record<string, unknown> = {
        date, type: 'Bank', reference, counterparty: bankLedger?.name || '',
        notes: notes || `Tax payment — ${payTarget.type}`, entries, total: amount,
        entry_kind: 'payment', bank_cash_ledger: bankLedgerId, owner: pb.authStore.record?.id,
      };
      // If no tax ledger exists, post as a simple bank payment with the tax type as counterparty.
      if (!payTarget.ledgerId) {
        voucherValues.entries = [
          { ledger: bankLedgerId, ledgerName: bankLedger?.name || '', ledgerGroup: 'Assets', debit: 0, credit: amount },
        ];
        voucherValues.counterparty = payTarget.type;
      }
      await pb.collection('vouchers').create(voucherValues);

      // Mark the compliance item as Filed if this was tied to one.
      if (payTarget.itemId) {
        await pb.collection('compliance_items').update(payTarget.itemId, { status: 'Filed', reference: reference || undefined });
      }
      setPayTarget(null);
      revalidator.revalidate();
    } catch {
      setError('The tax payment couldn’t be recorded. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">TAX DASHBOARDS</span>
          <h1>GST, TDS, PF, ESIC &amp; PT<span>.</span></h1>
          <p>Payable, paid and outstanding amounts across every statutory tax — with one-click payment recording.</p>
        </div>
        <div className="heading-actions">
          <button className="button button-quiet button-small" onClick={downloadTaxPdf}><FileText size={15} />Export PDF</button>
          <button className="button button-quiet button-small" onClick={downloadTaxReport}><Download size={15} />Export CSV</button>
        </div>
      </div>

      {/* GST Dashboard */}
      <div className="summary-cards">
        <div className="summary-card">
          <div><TrendingUp size={17} />Output GST (liability)</div>
          <strong>{money(gst.outputGst)}</strong>
          <p>Total GST collected on sales</p>
        </div>
        <div className="summary-card">
          <div><TrendingDown size={17} />Input Tax Credit</div>
          <strong>{money(gst.inputGst)}</strong>
          <p>GST paid on purchases</p>
        </div>
        <div className={`summary-card ${gst.netPayable > 0 ? 'summary-highlight' : ''}`}>
          <div><Wallet size={17} />Net GST payable</div>
          <strong>{money(gst.netPayable)}</strong>
          <p>Output GST minus Input GST</p>
        </div>
        <div className="summary-card">
          <div><ShieldCheck size={17} />GST credit balance</div>
          <strong>{money(gst.creditBalance)}</strong>
          <p>Excess input credit carried forward</p>
        </div>
      </div>

      {gst.netPayable > 0 && (
        <section className="dashboard-panel" style={{ marginBottom: 21 }}>
          <div className="panel-heading">
            <div><h2>GST payment</h2><p>Record the net GST payable as a bank payment voucher.</p></div>
            <button className="button button-primary button-small" onClick={() => setPayTarget({ type: 'GST', amount: gst.netPayable, ledgerId: ledgers.find((l) => l.name.toLowerCase().includes('output gst'))?.id })}>
              Record GST payment<ArrowUpRight size={15} />
            </button>
          </div>
        </section>
      )}

      {tdsFromVouchers > 0 && (
        <section className="dashboard-panel" style={{ marginBottom: 21 }}>
          <div className="panel-heading">
            <div><h2>TDS deducted from vouchers</h2><p>TDS Payable ledger balance from expense vouchers with TDS applied.</p></div>
            <button className="button button-primary button-small" onClick={() => setPayTarget({ type: 'TDS', amount: tdsFromVouchers, ledgerId: ledgers.find((l) => l.name.toLowerCase().includes('tds payable'))?.id })}>
              Record TDS payment<ArrowUpRight size={15} />
            </button>
          </div>
          <div style={{ padding: '0 22px 18px' }}>
            <div className="summary-card" style={{ maxWidth: 320 }}>
              <div><Wallet size={17} />TDS Payable balance</div>
              <strong>{money(tdsFromVouchers)}</strong>
              <p>Total TDS deducted on expense vouchers, not yet paid</p>
            </div>
          </div>
        </section>
      )}

      {/* TDS / PF / ESIC / PT Dashboards */}
      <section className="dashboard-panel">
        <div className="panel-heading">
          <div><h2>Tax obligations summary</h2><p>Payable, paid and outstanding for each statutory tax.</p></div>
        </div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>Tax</th><th className="align-right">Payable</th><th className="align-right">Paid</th><th className="align-right">Outstanding</th><th className="align-right">Open items</th></tr></thead>
            <tbody>
              {dashboards.map((d) => (
                <tr key={d.type}>
                  <td><strong>{d.type}</strong><small>{d.full}</small></td>
                  <td className="align-right amount-cell">{money(d.payable)}</td>
                  <td className="align-right income-amount">{money(d.paid)}</td>
                  <td className={`align-right amount-cell ${d.outstanding > 0 ? 'summary-loss-text' : ''}`}>{money(d.outstanding)}</td>
                  <td className="align-right">{d.items.filter((i) => i.status !== 'Filed').length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Open compliance items with Mark as Paid */}
      {compliance.filter((c) => c.status !== 'Filed').length > 0 && (
        <section className="dashboard-panel" style={{ marginTop: 21 }}>
          <div className="panel-heading">
            <div><h2>Open obligations <span className="count-label">{compliance.filter((c) => c.status !== 'Filed').length}</span></h2><p>Record a payment to mark an obligation as filed.</p></div>
          </div>
          <div className="table-scroll">
            <table>
              <thead><tr><th>Obligation</th><th>Type</th><th>Period</th><th>Due date</th><th className="align-right">Amount</th><th className="align-right">Pay</th></tr></thead>
              <tbody>
                {compliance.filter((c) => c.status !== 'Filed').map((c) => (
                  <tr key={c.id}>
                    <td><strong>{c.title}</strong></td>
                    <td><span className="type-label">{c.type}</span></td>
                    <td>{c.period}</td>
                    <td className="nowrap">{dateLabel(c.due_date)}</td>
                    <td className="align-right amount-cell">{money(c.amount || 0)}</td>
                    <td className="align-right">
                      <button className="button button-quiet button-small" onClick={() => setPayTarget({ type: c.type || 'TAX', amount: Number(c.amount || 0), itemId: c.id })}>
                        Mark as paid<ArrowUpRight size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Payment dialog */}
      <Dialog open={!!payTarget} onOpenChange={(v) => { if (!busy && !v) setPayTarget(null); }}>
        <DialogContent className="record-dialog" onInteractOutside={(e) => { if (busy) e.preventDefault(); }}>
          <DialogTitle>Record {payTarget?.type} payment<span className="accent-dot">.</span></DialogTitle>
          <DialogDescription>This creates a Bank payment voucher and marks the obligation as filed.</DialogDescription>
          {error && <p className="form-error" role="alert">{error}</p>}
          <form onSubmit={(e) => { e.preventDefault(); recordPayment(new FormData(e.currentTarget)); }}>
            <div className="record-fields">
              <label>Payment amount<input type="number" value={payTarget?.amount || 0} readOnly /></label>
              <label>Date<input name="date" type="date" defaultValue={today} required /></label>
              <label className="field-wide">Bank / cash ledger<span className="required"> *</span>
                <select name="bank_ledger" required>
                  <option value="">Select bank or cash ledger…</option>
                  {bankCashLedgers.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
              </label>
              <label className="field-wide">Reference / challan no.<input name="reference" maxLength={200} placeholder="e.g. CPN-12345" /></label>
              <label className="field-wide">Narration<input name="notes" maxLength={2000} placeholder="Optional notes" /></label>
            </div>
            <div className="dialog-actions">
              <button type="button" className="button button-quiet" onClick={() => setPayTarget(null)} disabled={busy}><X size={16} />Cancel</button>
              <button type="submit" className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save payment'}<ArrowUpRight size={17} /></button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
