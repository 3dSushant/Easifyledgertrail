import { useState } from 'react';
import { useRevalidator } from 'react-router';
import { Play, ArrowUpRight } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import { money, netPay, type BusinessRecord } from '@/lib/business';
export function PayrollRun({ employees, runs, today }: { employees: BusinessRecord[]; runs: BusinessRecord[]; today: string }) {
  const [open, setOpen] = useState(false); const [period, setPeriod] = useState(today.slice(0, 7)); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const revalidator = useRevalidator();
  const active = employees.filter(e => e.status === 'Active');
  const gross = active.reduce((s, e) => s + (e.basic || 0) + (e.allowances || 0), 0); const deductions = active.reduce((s, e) => s + (e.deductions || 0), 0); const net = active.reduce((s, e) => s + netPay(e), 0);
  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (runs.some(r => r.period === period)) { setError('A payroll run already exists for this month. Review it in Payroll runs.'); return; }
    if (!active.length) { setError('Add an active employee before creating a payroll run.'); return; }
    setBusy(true);
    try { await pb.collection('payroll_runs').create({ owner: pb.authStore.record?.id, period, gross, deductions, net, employee_count: active.length, status: 'Draft', snapshot: active.map(e => ({ name: e.name || '', designation: e.designation || '', basic: e.basic || 0, allowances: e.allowances || 0, deductions: e.deductions || 0, net: netPay(e) })) }); setOpen(false); revalidator.revalidate(); }
    catch { setError('Couldn’t create this payroll run. Please try again.'); } finally { setBusy(false); }
  }
  return <Dialog open={open} onOpenChange={value => { if (!busy) { setOpen(value); setError(''); } }}><button className="button button-primary" onClick={() => setOpen(true)}><Play size={16} />Create payroll run</button><DialogContent className="record-dialog"><DialogTitle>Let’s run payroll<span className="accent-dot">.</span></DialogTitle><DialogDescription>Create a monthly salary snapshot for your active employees. No payments are transferred by Ledgerly.</DialogDescription><form onSubmit={save}><label>Payroll month<input type="month" required value={period} onChange={e => setPeriod(e.target.value)} /></label><div className="payroll-run-summary"><span>Active employees<strong>{active.length}</strong></span><span>Gross salary<strong>{money(gross)}</strong></span><span>Deductions<strong>{money(deductions)}</strong></span><span>Net payable<strong>{money(net)}</strong></span></div><p className="small-note">Review salary components and statutory deductions before saving. This run is stored as a draft for your review.</p>{error && <p className="form-error" role="alert">{error}</p>}<div className="dialog-actions"><button type="button" className="button button-quiet" onClick={() => setOpen(false)} disabled={busy}>Cancel</button><button className="button button-primary" disabled={busy}>{busy ? 'Creating…' : 'Create draft run'}<ArrowUpRight size={17} /></button></div></form></DialogContent></Dialog>;
}
