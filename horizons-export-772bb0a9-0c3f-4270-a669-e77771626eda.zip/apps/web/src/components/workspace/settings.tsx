import { useState } from 'react';
import { useOutletContext, useRevalidator } from 'react-router';
import { Building2, ShieldCheck, ArrowUpRight, CheckCircle2, Receipt, ImagePlus, Trash2, Upload } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { WorkspaceData } from '@/lib/business';

export function Settings() {
  const { user } = useOutletContext<WorkspaceData>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [reset, setReset] = useState(false);
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoError, setLogoError] = useState('');
  const [logoSaved, setLogoSaved] = useState(false);
  const revalidator = useRevalidator();

  const logoFilename = (user as { logo?: string }).logo;
  const logoUrl = logoFilename ? pb.files.getUrl(user, logoFilename) : '';

  async function uploadLogo(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setLogoBusy(true); setLogoError(''); setLogoSaved(false);
    try {
      const fd = new FormData();
      fd.append('logo', file);
      const updated = await pb.collection('users').update(user.id, fd);
      pb.authStore.save(pb.authStore.token, updated);
      setLogoSaved(true);
      revalidator.revalidate();
    } catch {
      setLogoError('The logo couldn’t be uploaded. Use a JPG, PNG, WebP or SVG under 2 MB.');
    } finally {
      setLogoBusy(false);
      event.target.value = '';
    }
  }

  async function removeLogo() {
    setLogoBusy(true); setLogoError(''); setLogoSaved(false);
    try {
      const updated = await pb.collection('users').update(user.id, { logo: null });
      pb.authStore.save(pb.authStore.token, updated);
      revalidator.revalidate();
    } catch {
      setLogoError('The logo couldn’t be removed. Please try again.');
    } finally {
      setLogoBusy(false);
    }
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setSaved(false);
    const form = new FormData(event.currentTarget);
    try {
      const updated = await pb.collection('users').update(user.id, {
        name: String(form.get('name')).trim(),
        business_name: String(form.get('business_name')).trim(),
        gstin: String(form.get('gstin')).trim().toUpperCase(),
        pan: String(form.get('pan')).trim().toUpperCase(),
        bank_name: String(form.get('bank_name')).trim(),
        account_number: String(form.get('account_number')).trim(),
        ifsc: String(form.get('ifsc')).trim().toUpperCase(),
        upi_id: String(form.get('upi_id')).trim(),
        licenses: String(form.get('licenses')).trim(),
        business_address: String(form.get('business_address')).trim(),
      });
      pb.authStore.save(pb.authStore.token, updated);
      setSaved(true);
      revalidator.revalidate();
    } catch {
      setError('Your settings couldn’t be saved. Please check the fields and try again.');
    } finally {
      setBusy(false);
    }
  }

  async function passwordReset() {
    setBusy(true);
    setError('');
    try {
      await pb.collection('users').requestPasswordReset(user.email);
      setReset(true);
    } catch {
      setError('Couldn’t send the password reset email. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">MAKE IT YOURS</span>
          <h1>Business settings<span>.</span></h1>
          <p>Your business details, invoice information and account security.</p>
        </div>
      </div>

      <div className="settings-grid">
        <section className="dashboard-panel">
          <div className="panel-heading">
            <div>
              <h2><Building2 size={21} />Business profile</h2>
              <p>Keep your workspace and business information up to date.</p>
            </div>
          </div>
          <form className="settings-form" onSubmit={save}>
            <div className="logo-uploader">
              <div className="logo-preview">
                {logoUrl ? <img src={logoUrl} alt="Company logo" /> : <ImagePlus size={26} strokeWidth={1.4} />}
              </div>
              <div className="logo-controls">
                <h3>Company logo</h3>
                <p className="small-note">Shown on sales invoices, salary slips and exported PDFs. JPG, PNG, WebP or SVG up to 2 MB.</p>
                <div className="logo-actions">
                  <label className="button button-quiet button-small">
                    <Upload size={14} />{logoUrl ? 'Replace logo' : 'Upload logo'}
                    <input type="file" accept="image/jpeg,image/png,image/webp,image/svg+xml" onChange={uploadLogo} disabled={logoBusy} hidden />
                  </label>
                  {logoUrl && <button type="button" className="button button-quiet button-small" onClick={removeLogo} disabled={logoBusy}><Trash2 size={14} />Remove</button>}
                </div>
                {logoSaved && <p className="form-success" role="status"><CheckCircle2 size={15} />Logo updated.</p>}
                {logoError && <p className="form-error" role="alert">{logoError}</p>}
              </div>
            </div>
            <div className="record-fields">
              <label>Your name
                <input name="name" defaultValue={user.name || ''} maxLength={200} autoComplete="name" required />
              </label>
              <label>Business name
                <input name="business_name" defaultValue={user.business_name || ''} maxLength={200} autoComplete="organization" required />
              </label>
              <label>GSTIN (optional)
                <input name="gstin" defaultValue={user.gstin || ''} maxLength={15} minLength={15} pattern="[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z][1-9A-Za-z]Z[0-9A-Za-z]" placeholder="15-character GSTIN" />
              </label>
              <label>PAN (optional)
                <input name="pan" defaultValue={(user as { pan?: string }).pan || ''} maxLength={10} pattern="[A-Za-z]{5}[0-9]{4}[A-Za-z]" placeholder="10-character PAN" />
              </label>
              <label>Account email
                <input type="email" value={user.email} readOnly />
                <small className="small-note">Your registered sign-in email.</small>
              </label>
              <label>UPI ID (optional)
                <input name="upi_id" defaultValue={(user as { upi_id?: string }).upi_id || ''} maxLength={100} placeholder="business@upi" />
              </label>
              <label className="field-wide">Business address
                <textarea name="business_address" defaultValue={user.business_address || ''} maxLength={1000} rows={3} autoComplete="street-address" />
              </label>
            </div>

            <div className="invoice-bank-section">
              <h3><Receipt size={16} /> Bank details for invoices</h3>
              <p className="small-note">These appear on every sales invoice you export as a PDF.</p>
              <div className="record-fields">
                <label>Bank name
                  <input name="bank_name" defaultValue={(user as { bank_name?: string }).bank_name || ''} maxLength={200} />
                </label>
                <label>Account number
                  <input name="account_number" defaultValue={(user as { account_number?: string }).account_number || ''} maxLength={40} />
                </label>
                <label>IFSC code
                  <input name="ifsc" defaultValue={(user as { ifsc?: string }).ifsc || ''} maxLength={11} />
                </label>
                <label className="field-wide">Other licence / registration nos (optional)
                  <input name="licenses" defaultValue={(user as { licenses?: string }).licenses || ''} maxLength={2000} placeholder="e.g. Shop Act, FSSAI, MSME" />
                </label>
              </div>
            </div>

            {saved && <p className="form-success" role="status"><CheckCircle2 size={17} />Business settings saved.</p>}
            {error && <p className="form-error" role="alert">{error}</p>}
            <div className="dialog-actions">
              <button className="button button-primary" disabled={busy}>
                {busy ? 'Please wait…' : 'Save changes'}<ArrowUpRight size={17} />
              </button>
            </div>
          </form>
        </section>

        <section className="dashboard-panel security-panel">
          <ShieldCheck size={30} strokeWidth={1.5} />
          <h2>Your access, protected.</h2>
          <p>Your accounting, employee and compliance records are accessible only through your business account.</p>
          <div>
            <h3>Password security</h3>
            <p>Update your password using a secure link sent to your registered email address.</p>
            <button className="button button-quiet" onClick={passwordReset} disabled={busy || reset}>
              {reset ? 'Reset email sent' : 'Send password reset link'}<ArrowUpRight size={16} />
            </button>
            {reset && <p className="form-success" role="status">Check your inbox for the secure reset link.</p>}
          </div>
          <span className="small-note">Keep your login credentials private. Sign out when using a shared device.</span>
        </section>
      </div>
    </>
  );
}
