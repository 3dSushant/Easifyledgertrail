import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router';
import { ArrowUpRight, ArrowLeft, ShieldCheck, Eye, EyeOff, CheckCircle2, LockKeyhole } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
export function LoginPanel() {
  const [params] = useSearchParams();
  const [mode, setMode] = useState(params.get('mode') === 'request' ? 'request' : 'login');
  const [show, setShow] = useState(false); const [busy, setBusy] = useState(false);
  const [error, setError] = useState(''); const [success, setSuccess] = useState(false);
  const { login } = useAuth(); const navigate = useNavigate();
  function changeMode(value: string) { setMode(value); setError(''); setSuccess(false); }
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    const form = new FormData(event.currentTarget); const email = String(form.get('email') || '').trim();
    try {
      if (mode === 'login') { await login(email, String(form.get('password'))); const role = (pb.authStore.record as { role?: string } | null)?.role; navigate(role === 'admin' ? '/admin' : '/app'); }
      else if (mode === 'reset') { await pb.collection('users').requestPasswordReset(email); setSuccess(true); }
      else {
        const phone = String(form.get('phone') || '').trim();
        if (phone && !/^[0-9+\-\s]{7,15}$/.test(phone)) { setError('Please enter a valid mobile number (7–15 digits).'); setBusy(false); return; }
        await pb.collection('access_requests').create({ name: String(form.get('name')).trim(), business: String(form.get('business')).trim(), email, phone, status: 'pending' });
        setSuccess(true);
      }
    } catch { setError(mode === 'login' ? 'We couldn’t sign you in. Check your email and password and try again.' : 'Your request could not be sent. Please try again.'); }
    finally { setBusy(false); }
  }
  return <main className="login-page"><section className="login-story"><span className="eyebrow">YOUR PRIVATE BUSINESS WORKSPACE</span><h1>A clear head.<br /><span>A clear ledger.</span></h1><p>Everything you need to manage your books, your people and your obligations. Right where you left it.</p><div className="login-graphic" aria-hidden="true"><span /><span /><span /><span /></div><div className="login-assurance"><ShieldCheck size={22} /><div><strong>Your data stays your business.</strong><p>Account-specific access. Private financial records.</p></div></div></section><section className="login-form-panel"><Link to="/" className="text-link"><ArrowLeft size={16} /> Back to home</Link><div className="login-form-inner"><span className="login-lock"><LockKeyhole size={25} /></span><span className="eyebrow">LET’S GET TO WORK</span><h2>{mode === 'request' ? 'Request client access.' : mode === 'reset' ? 'Reset your password.' : 'Welcome back.'}</h2><p>{mode === 'request' ? 'Tell us about your business. Your request will be saved for the workspace owner.' : mode === 'reset' ? 'We’ll send a secure reset link to your registered email.' : 'Sign in to your secure business workspace.'}</p>{success ? <div className="success-panel" role="status"><CheckCircle2 size={28} /><h3>{mode === 'request' ? 'Request received.' : 'Check your inbox.'}</h3><p>{mode === 'request' ? 'Your access request has been saved. The workspace owner can review it and provision your business account.' : 'If this email is registered, a password reset link will arrive shortly.'}</p><button className="button button-dark" onClick={() => changeMode('login')}>Back to sign in <ArrowUpRight size={16} /></button></div> : <form onSubmit={submit} className="auth-form">{mode === 'request' && <><label>Your name<input name="name" required maxLength={200} autoComplete="name" placeholder="Full name" /></label><label>Business name<input name="business" required maxLength={200} autoComplete="organization" placeholder="Your business" /></label><label>Mobile number<input name="phone" type="tel" maxLength={15} autoComplete="tel" placeholder="10-digit mobile number" pattern="[0-9+\-\s]{7,15}" /></label></>}<label>Business email<input name="email" type="email" autoComplete="email" required placeholder="you@business.com" /></label>{mode === 'login' && <><label>Password<div className="password-field"><input name="password" type={show ? 'text' : 'password'} autoComplete="current-password" required placeholder="Enter your password" /><button type="button" className="icon-button" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label><button type="button" className="forgot-password" onClick={() => changeMode('reset')}>Forgot password?</button></>}{error && <p className="form-error" role="alert">{error}</p>}<button type="submit" disabled={busy} className="button button-primary">{busy ? 'Please wait…' : mode === 'request' ? 'Send access request' : mode === 'reset' ? 'Send reset link' : 'Sign in to workspace'}<ArrowUpRight size={18} /></button></form>}<div className="auth-switch">{mode === 'login' ? <>New to Ledgerly? <button onClick={() => changeMode('request')}>Request client access <ArrowUpRight size={13} /></button></> : <button onClick={() => changeMode('login')}><ArrowLeft size={13} /> Return to sign in</button>}</div><span className="auth-safe"><ShieldCheck size={14} /> Secure access. Just for your business.</span></div></section></main>;
}
