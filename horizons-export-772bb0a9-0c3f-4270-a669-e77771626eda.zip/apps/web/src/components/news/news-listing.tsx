import { Link } from 'react-router';
import { ArrowUpRight, Calendar, Tag } from 'lucide-react';
import type { NewsArticle } from '@/lib/content';
import { newsCategories, articleImageUrl } from '@/lib/content';
import { dateLabel } from '@/lib/business';

export function NewsListing({ articles, activeCategory }: { articles: NewsArticle[]; activeCategory?: string }) {
  const filtered = activeCategory
    ? articles.filter((a) => a.category === activeCategory)
    : articles;

  return (
    <main className="services-page">
      <section className="services-hero">
        <span className="eyebrow"><i className="red-square" /> INSIGHTS</span>
        <h1>News &amp; Finance<br />Updates<span>.</span></h1>
        <p>The latest in finance, GST, tax compliance, accounting and business — curated by the Easify Ledger team to keep you informed and ahead.</p>
      </section>

      <div className="news-filter-row">
        <Link to="/news" className={activeCategory ? 'news-chip' : 'news-chip active'}>All</Link>
        {newsCategories.map((cat) => (
          <Link key={cat} to={`/news?category=${encodeURIComponent(cat)}`} className={activeCategory === cat ? 'news-chip active' : 'news-chip'}>{cat}</Link>
        ))}
      </div>

      <section className="news-grid">
        {filtered.length ? (
          filtered.map((a) => (
            <article className="service-card news-card" key={a.id}>
              <Link to={`/news/${a.slug}`} className="service-card-image">
                {articleImageUrl(a) ? <img src={articleImageUrl(a)} alt={a.headline} loading="lazy" /> : <div className="news-card-fallback" />}
              </Link>
              <div className="service-card-body">
                <div className="news-meta">
                  <span className="news-category"><Tag size={11} /> {a.category}</span>
                  <span className="news-date"><Calendar size={11} /> {dateLabel(a.published_at || a.created)}</span>
                </div>
                <h3>{a.headline}</h3>
                <p>{a.summary}</p>
                <Link to={`/news/${a.slug}`} className="text-link">Read more <ArrowUpRight size={15} /></Link>
              </div>
            </article>
          ))
        ) : (
          <div className="large-empty">
            <ArrowUpRight size={42} strokeWidth={1.3} />
            <h3>No articles yet.</h3>
            <p>New finance and business updates will appear here as soon as they’re published.</p>
          </div>
        )}
      </section>
    </main>
  );
}
