import { useState } from 'react';
import { Link } from 'react-router';
import { ThumbsUp, ThumbsDown, MessageSquare, Send, Calendar, Tag, User, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { pocketbaseClient as pb } from '@/lib/pocketbase-client';
import type { NewsArticle, ArticleComment } from '@/lib/content';
import { sessionId, articleImageUrl } from '@/lib/content';
import { dateLabel } from '@/lib/business';

export function ArticleDetail({
  article,
  comments,
  reaction,
  likes: initialLikes,
  dislikes: initialDislikes,
}: {
  article: NewsArticle;
  comments: ArticleComment[];
  reaction: 'like' | 'dislike' | null;
  likes: number;
  dislikes: number;
}) {
  const [busy, setBusy] = useState(false);
  const [myReaction, setMyReaction] = useState<'like' | 'dislike' | null>(reaction);
  const [likes, setLikes] = useState(initialLikes);
  const [dislikes, setDislikes] = useState(initialDislikes);
  const [commentList, setCommentList] = useState(comments);
  const [commentError, setCommentError] = useState('');
  const [commentDone, setCommentDone] = useState(false);

  async function react(type: 'like' | 'dislike') {
    if (busy) return;
    setBusy(true);
    try {
      const sid = sessionId();
      if (myReaction === type) {
        // remove reaction
        const existing = await pb.collection('article_reactions').getFirstListItem(pb.filter('article = {:articleId} && session_id = {:sid}', { articleId: article.id, sid }));
        await pb.collection('article_reactions').delete(existing.id);
        if (type === 'like') setLikes((n) => Math.max(0, n - 1));
        else setDislikes((n) => Math.max(0, n - 1));
        setMyReaction(null);
      } else {
        if (myReaction) {
          const existing = await pb.collection('article_reactions').getFirstListItem(pb.filter('article = {:articleId} && session_id = {:sid}', { articleId: article.id, sid }));
          await pb.collection('article_reactions').update(existing.id, { type });
          if (myReaction === 'like' && type === 'dislike') { setLikes((n) => Math.max(0, n - 1)); setDislikes((n) => n + 1); }
          if (myReaction === 'dislike' && type === 'like') { setDislikes((n) => Math.max(0, n - 1)); setLikes((n) => n + 1); }
        } else {
          await pb.collection('article_reactions').create({ article: article.id, session_id: sid, type });
          if (type === 'like') setLikes((n) => n + 1);
          else setDislikes((n) => n + 1);
        }
        setMyReaction(type);
      }
    } catch {
      // ignore reaction errors silently
    } finally {
      setBusy(false);
    }
  }

  async function submitComment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCommentError('');
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const email = String(form.get('email') || '').trim();
    const content = String(form.get('content') || '').trim();
    if (!name || !email || !content) {
      setCommentError('Please fill in your name, email and comment.');
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      setCommentError('Please enter a valid email address.');
      return;
    }
    setBusy(true);
    try {
      const rec = await pb.collection('article_comments').create<ArticleComment>({ article: article.id, name, email, content });
      setCommentList((prev) => [rec, ...prev]);
      setCommentDone(true);
      (event.target as HTMLFormElement).reset();
    } catch {
      setCommentError('Your comment could not be posted. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  const paragraphs = (article.content || '').split('\n').filter(Boolean);

  return (
    <main className="services-page">
      <article className="article-detail">
        <nav className="breadcrumb">
          <Link to="/">Home</Link><span>/</span>
          <Link to="/news">News &amp; Finance Updates</Link><span>/</span>
          <strong>{article.category}</strong>
        </nav>
        <div className="article-meta-bar">
          <span className="news-category"><Tag size={12} /> {article.category}</span>
          <span className="news-date"><Calendar size={12} /> {dateLabel(article.published_at || article.created)}</span>
          {article.author && <span className="news-author"><User size={12} /> {article.author}</span>}
        </div>
        <h1 className="article-headline">{article.headline}</h1>
        {articleImageUrl(article) && (
          <div className="service-detail-image" style={{ marginBottom: 28 }}>
            <img src={articleImageUrl(article)} alt={article.headline} />
          </div>
        )}
        <div className="article-content">
          {paragraphs.map((p, i) => <p key={i}>{p}</p>)}
        </div>

        <div className="article-reactions">
          <button className={`reaction-btn ${myReaction === 'like' ? 'active' : ''}`} onClick={() => react('like')} disabled={busy} aria-label="Like">
            <ThumbsUp size={16} /> <span>{likes}</span> Like
          </button>
          <button className={`reaction-btn dislike ${myReaction === 'dislike' ? 'active' : ''}`} onClick={() => react('dislike')} disabled={busy} aria-label="Dislike">
            <ThumbsDown size={16} /> <span>{dislikes}</span> Dislike
          </button>
        </div>

        <section className="article-comments">
          <h2><MessageSquare size={18} /> Comments ({commentList.length})</h2>

          {commentDone && (
            <div className="form-success" role="status"><CheckCircle2 size={16} /> Your comment has been posted.</div>
          )}

          <form onSubmit={submitComment} className="comment-form">
            <div className="record-fields">
              <label>Name<input name="name" required maxLength={100} placeholder="Your name" /></label>
              <label>Email<input name="email" type="email" required placeholder="you@email.com" /></label>
              <label className="field-wide">Comment<textarea name="content" required maxLength={2000} rows={3} placeholder="Share your thoughts…" /></label>
            </div>
            {commentError && <p className="form-error" role="alert">{commentError}</p>}
            <div className="dialog-actions">
              <button className="button button-primary" disabled={busy}>{busy ? 'Posting…' : 'Post comment'}<Send size={15} /></button>
            </div>
          </form>

          <div className="comment-list">
            {commentList.length ? commentList.map((c) => (
              <div className="comment-item" key={c.id}>
                <span className="comment-avatar">{String(c.name || 'A').slice(0, 1).toUpperCase()}</span>
                <div>
                  <strong>{c.name} <small>· {dateLabel(c.created)}</small></strong>
                  <p>{c.content}</p>
                </div>
              </div>
            )) : (
              <div className="compact-empty"><MessageSquare size={28} strokeWidth={1.4} /><strong>No comments yet.</strong><p>Be the first to share your thoughts.</p></div>
            )}
          </div>
        </section>
      </article>

      <div className="article-back"><Link to="/news" className="button button-quiet">← Back to all updates <ArrowUpRight size={15} /></Link></div>
    </main>
  );
}
